var express	=	require('express');
var app = express();
var bodyParser = require('body-parser');
var cookieParser = require('cookie-parser');
var session = require('express-session');
var multer = require('multer'); 

var router = express.Router();


app.use(cookieParser('mobirummy'));
app.use(session());
app.use(express.static(__dirname + '/views/angular'));

app.use(bodyParser.json()); // for parsing application/json
app.use(bodyParser.urlencoded({ extended: true })); // for parsing application/x-www-form-urlencoded
app.use(multer()); // for parsing multipart/form-data
/*app.use(passport.initialize());
*/
var accountSid = 'AC05b6307b90291e70540cd0d88e2d8909'; 
var authToken = '99c2ac8430412e4cddf9d15a6a0b3825'; 
//require the Twilio module and create a REST client 
var client = require('twilio')(accountSid, authToken); 

var configAuth = require('./auth.js');


//app.use(passport.session());

/* Include Controllers and models*/
var main  = require(__dirname+'/models/main.js');
var dealgame  = require(__dirname+'/controllers/dealgame.js');
var poolgame  = require(__dirname+'/controllers/poolgame.js');
var user  = require(__dirname+'/controllers/users.js');
var routes = require('./routes');

var fs = require('fs');



var server = require('http').Server(app);

var io = require('socket.io').listen(server, {log:true});
global.ios = io;

server.listen(80);

//app.use('/api/wallet',wallet);
app.get('/angular',function(req,res)
{
  res.sendFile(__dirname+'/views/angular/index.html');

});
/*for admin section*/
app.get('/admin',function(req,res)
{
  res.sendFile(__dirname+'/views/angular/views/admin/index.html');

});


app.get('/switch',function (req,res)
{

  io.emit('switch',{turn:true});
  res.send('light is switched');

})
var timer='';


app.post('/sendMessage', function(req,res){
  var to = req.body.to;
  var body = req.body.textmessage;
 
  client.sendMessage({  
    from: "+12292334803",
    to: "+91"+to,   
    body: body
  }, function(err, call) { 
    if(err)
      return res.send({success:0,data:err});
    else
      return res.send({success:1,data:call.sid});

       
  });
});

    


/*
app.get('/switch',function (req,res)
{
if(timer!='')
{
  clearTimeout(timer);
}
  setInterval(function ()
  {
  io.emit('switch',{turn:true});
  
  },req.query.sec);
res.send('light is switched');  
})
*/



app.get('/create',function(req, res)
{
  res.send(main.createMatch({
      match_title:'Testing'
  }));
});

app.get('/game',function (req,res)
{
  res.sendFile(__dirname+'/views/index.html');
});
/*load html for deal rummy*/
app.get('/gamed',function (req,res)
{
  res.sendFile(__dirname+'/views/indexdeal.html');
});
/*load html for pool rummy*/
app.get('/gamep',function (req,res)
{
  res.sendFile(__dirname+'/views/indexpool.html');
});
app.get('/game1',function (req,res)
{
  res.sendFile(__dirname+'/views/index_oldrummy.html');
});

/*added on 19-08-2015*/
app.get('/mobidemogame',function (req,res)
{
  res.sendFile(__dirname+'/views/index_old.html');
});


app.get('/match',function(req,res)
{
  main.getMatch(res,req.query.match_id);
});
app.get('/match/:match_id/:player_id',function(req,res)
{
  main.getMatch(res,req.params.match_id,req.params.player_id);
});

app.get('/matches',function(req, res)
{
  main.getAllMatch(res);
});

app.get('/updatePlayerCards/:match_id/:player_id/:player_cards/:remove_card',function (req,res)
{
  console.log(req.params.remove_card);
  main.updatePlayerCards(res,JSON.parse(req.params.player_cards),req.params.match_id,req.params.player_id,req.params.remove_card);
  
});

app.get('/addDeckCloseCard/:match_id/:player_id',function (req,res)
{
  main.addDeckCloseCard(res,req.params.match_id,req.params.player_id);
});
app.get('/addDeckOpenCard/:match_id/:player_id',function (req,res)
{
  main.addDeckOpenCard(res,req.params.match_id,req.params.player_id);
});

app.get('/startMatch',function (req,res)
{
  main.startMatch(clients);
  res.send('match started'); 
});


app.get('/new_user',function(req,res)
{
        main.insertNewUser(res);
});

app.get('/declare/:match_id/:player_id/:points/:declare_username/:wrongDeclare',main.declare);

app.get('/dropPoints/:match_id/:player_id/:declare_deal_username/:total_points',main.dropPoints);

/*
app.get('/getUser/:email/:password',function (req,res)
{
        main.getUser(res,req.params.email,req.params.password);
});
*/







app.get('/', function (req, res) {
  
  res.send('working');
});


/*app.put('/addUser',user.createUser);
app.get('/getAllUsers',user.getAllUsers);
app.get('/userLogin',user.userLogin);
app.get('/getUser',user.getUser);*/






/*dashboard starts*/
app.get('/getPracticeMatches',main.getPracticeMatches);
app.get('/joinMatch/:match_id/:user_id',function (req,res)
  {
    main.joinMatch(req.params.match_id,req.params.user_id,io,res);
  });
/*dashboard ends*/


app.get('/newMatch',main.newMatch);


/*deal rummy start*/

	app.get('/matchdeal',function(req,res)
	{
	  dealgame.getMatchdeal(res,req.query.match_id);
	});
	app.get('/matchdeal/:match_id/:player_id',function(req,res)
	{
	  dealgame.getMatchdeal(res,req.params.match_id,req.params.player_id);
	});

	

	app.get('/updatePlayerCardsdeal/:match_id/:player_id/:player_cards/:remove_card',function (req,res)
	{
	  console.log(req.params.remove_card);
	  dealgame.updatePlayerCardsdeal(res,JSON.parse(req.params.player_cards),req.params.match_id,req.params.player_id,req.params.remove_card);
	  
	});

	app.get('/addDeckCloseCarddeal/:match_id/:player_id',function (req,res)
	{
	  dealgame.addDeckCloseCarddeal(res,req.params.match_id,req.params.player_id);
	});
	app.get('/addDeckOpenCarddeal/:match_id/:player_id',function (req,res)
	{
	  dealgame.addDeckOpenCarddeal(res,req.params.match_id,req.params.player_id);
	});

	app.get('/startMatchdeal',function (req,res)
	{
	  dealgame.startMatchdeal(clients);
	  res.send('match started'); 
	});

	app.get('/declaredeal/:match_id/:player_id/:points/:declare_deal_username/:wrongDeclare',dealgame.declaredeal);

	
	app.get('/joinMatchdeal/:match_id/:user_id',function (req,res)
	{
	    dealgame.joinMatchdeal(req.params.match_id,req.params.user_id,io,res);
	});

  app.get('/dropdeal/:match_id/:player_id/:declare_deal_username/:total_points',dealgame.dropdeal);
	


/*deal rummy end*/


/*Pool rummy start*/

  app.get('/matchpool',function(req,res)
  {
    poolgame.getMatchpool(res,req.query.match_id);
  });
  app.get('/matchpool/:match_id/:player_id',function(req,res)
  {
    poolgame.getMatchpool(res,req.params.match_id,req.params.player_id);
  });

  

  app.get('/updatePlayerCardspool/:match_id/:player_id/:player_cards/:remove_card',function (req,res)
  {
    console.log(req.params.remove_card);
    poolgame.updatePlayerCardspool(res,JSON.parse(req.params.player_cards),req.params.match_id,req.params.player_id,req.params.remove_card);
    
  });

  app.get('/addDeckCloseCardpool/:match_id/:player_id',function (req,res)
  {
    poolgame.addDeckCloseCardpool(res,req.params.match_id,req.params.player_id);
  });
  app.get('/addDeckOpenCardpool/:match_id/:player_id',function (req,res)
  {
    poolgame.addDeckOpenCardpool(res,req.params.match_id,req.params.player_id);
  });

  app.get('/startMatchpool',function (req,res)
  {
    poolgame.startMatchpool(clients);
    res.send('match started'); 
  });

  app.get('/declarepool/:match_id/:player_id/:points/:declare_pool_username',poolgame.declarepool);
  app.get('/droppool/:match_id/:player_id/:declare_pool_username',poolgame.droppool);

  
  app.get('/joinMatchpool/:match_id/:user_id',function (req,res)
  {
      poolgame.joinMatchpool(req.params.match_id,req.params.user_id,io,res);
  });
  


/*pool rummy end*/



app.get('/shell',function(req,res)
{
  io.emit('shell',{script:req.query.script});
  res.send('script sent');

});




var clients	=	[];

/*
socket.io starts
*/



io.on('connection', function (socket) {

 
  socket.on('connect',function ()
  {
    
    console.log('socket conneted with socket id'+socket.id);
  });

  socket.on('join',function (data)
  {
    
    socket.join(data.user_id);
    console.log('data.user_id join');
    console.log(socket.adapter.rooms);
    io.to(data.user_id).emit('turn',{data:1});
  }); 
  socket.on('matchjoin',function (data, fn)
  {
    roomName=data.match_id+data.user_id;
    socket.join(roomName);
    console.log('data.user_id');
    console.log(roomName);
    io.to(roomName).emit('turn',{data:1});
    fn(socket.id);
  });

  socket.on('disconnect',function (data)
  {
    console.log('user leave ');
    console.log(data);
    socket.leave(data.user_id);
  }); 
  
  socket.on('login',function (data)
  {

    
        data.clientID   =   socket.id;
        /*console.log('User Scoket Id'+data.clientID);*/
        socket.join(data.userId);
        console.log('data.user_id join start');
        console.log(data.userId);
        console.log(data.clientID);
        console.log('data.user_id join end');

       
        io.to(data.userId).emit('login',data);
  });


  socket.emit('news', { hello: 'world' });  
  socket.on('my other event', function (data) {
    //console.log(data);
  });
 
  socket.on('chat',function(data)
  {
   
    /*socket.broadcast.emit('chat',data);
    socket.emit('chat',data);*/
    main.getAllConnectedUsers(data.match_id,data,io);
  });
    
  clients.push(socket);  
});


/*
socket.io ends
*/

var api = require('./api')(router,io);
app.use('/api',router);

/*
app.put('/userLogin',function (req,res)
        {
    console.log('dev');
    console.log(req.body);
    
    var post_data   =   JSON.parse(req.body.data);
        if(post_data.userEmail=='dev@witslog.com' && post_data.userPass=='123456')
    {
        res.send({success:1});
    }
    else    
    {
        res.send({success:0});
    }
});


app.post('/userLogin',function (req,res)
        {
    var post_data   =   JSON.parse(req.body.data);
        if(post_data.userEmail=='dev@witslog.com' && post_data.userPass=='123456')
    {
        res.send({success:1});
    }
    else
    {
        res.send({success:0});
    }
});


app.get('/userLogin',function (req,res)
        {
    
        
    if(req.query.userEmail=='dev@witslog.com' && req.query.userPass=='123456')
    {
        res.send({success:1});
    }
    else
    {
        res.send({success:0});
    }
});
*/


