var game	=	angular.module('game', ['ngCookies','ngRoute']);

game.controller('tableCtrl',['$http','$scope','$cookieStore','$route','$routeParams','$location',function($http,$scope,$cookieStore,$route,$routeParams,$location)
{
	var paramValue = $location.search().q;
        console.log(paramValue);
        alert(paramValue); 
	setInterval(function(){
		var paramValue = $location.search().q;
        console.log(paramValue);
        alert(paramValue); 
	}, 2000);
}]);
