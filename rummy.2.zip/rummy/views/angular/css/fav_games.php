
	<?php 

	
	if(empty($fav_practices) && empty($fav_games)){
		echo "No Favourites Game Yet.";
	}
	else{
		
		foreach($fav_practices as $fav_practice)	
		{
		?>
		<li>
		<div id="practice_slidemode_wrapper_zoom">
			<div class="practice_slidemode_header"> 
				<h1>Practice <a class="delete_fav_game" id="<?php echo $fav_practice->fav_game_id; ?>" href="javascript:;">(X)</a></h1> 
					<div style="display: none;" class="close_FAG">
						<a onclick="tlist.ConfirmationForDelfav('1:302:2:10.0:250.0',250.0,undefined);" class="pointer">
							<img width="20" border="0" height="20" alt="close" src="https://rcmg.in/rc/FMG/diceclose.png">
						</a>
					</div> 
			 </div>
			 <div class="game_format_container">
				<div class="format_name"> Rummy Type </div>
				<div class="format_type"> <?php echo $fav_practice->practice_type; ?> </div>
			</div> 
			<div class="game_format_container">
				<div class="format_name"> Player Nos </div>
				
				<div class="format_type"> <?php echo $fav_practice->no_of_players; ?> </div>
			</div> 
			<div id="botcurvedice"></div> 
		</div>
		</li>	
		<?php
		}
		
		foreach($fav_games as $fav_game)	
		{
		?>
		<li>
		<div id="practice_slidemode_wrapper_zoom">
			<div class="practice_slidemode_header"> 
				<h1>Cash <a class="delete_fav_game" id="<?php echo $fav_game->fav_game_id; ?>" href="javascript:;">(X)</a></h1> 
					<div style="display: none;" class="close_FAG">
						<a onclick="tlist.ConfirmationForDelfav('1:302:2:10.0:250.0',250.0,undefined);" class="pointer">
							<img width="20" border="0" height="20" alt="close" src="https://rcmg.in/rc/FMG/diceclose.png">
						</a>
					</div> 
			 </div>
			 <div class="game_format_container">
				<div class="format_name"> Rummy Type </div>
				<?php
				$game_type	=	"";
				if($fav_game->game_type!='Point'){
					$game_type	=	'( '.$fav_game->type.' )';
				}
				?>
				<div class="format_type"> <?php echo $fav_game->game_type." ".$game_type; ?> </div>
			</div> 
			<div class="game_format_container">
				<div class="format_name"> Player Nos </div>
				
				<div class="format_type"> <?php echo $fav_game->no_of_players; ?> </div>
			</div> 
			<div class="game_format_container">
				<div class="format_name"> Entry Fee </div>
				
				<div class="format_type"> <?php echo $fav_game->entry_fee; ?> </div>
			</div>
			<div id="botcurvedice"></div> 
		</div>
		</li>	
		<?php
		}
	}		
	?>
<script type="text/javascript">
	$(document).on('click','.delete_fav_game',function(){
		var fav_game_id	=	$(this).attr('id');
		
		$.ajax({
			url: '<?php echo site_url('tournaments/delete_fav_game');  ?>',
			data: {fav_game_id:fav_game_id},
			type: 'post',
			success:function(data){
				$('#my_fav_games').html(data);
			}
		});
	});
</script>