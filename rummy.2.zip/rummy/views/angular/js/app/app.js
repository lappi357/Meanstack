var userCokie = $.cookie('user');
var mainApp = angular.module('mainApp',['ngRoute','ngAnimate','Directives','pages','ngCookies'])
.config(['$routeProvider','$locationProvider',
  function($routeProvider,$locationProvider) {
	if($.cookie('user')){
		var default_page='../../views/dashboard/dashboard.html';
		var default_ctrl='DashboardCtrl'
		
	}else{
		var default_page='../../views/home.html';
		var default_ctrl='HomeCtrl';
	}
   $locationProvider
.html5Mode(true);
    $routeProvider.
    when('/home/', {
        templateUrl: '../../views/'+default_page,
		controller :default_ctrl
	}).
	when('/refral', {
        templateUrl: '../../views/home.html',
	}).
	when('/about/', {
		templateUrl: '../../views/about-us.html'
       
	}).
	when('/how-to-play/', {
		templateUrl	: '../../views/how-to-play.html',
		controller	:	'HowToPlay'
	}).
	when('/privacy-policy/', {
         templateUrl: '../../views/privacy-policy.html'
       
	}).when('/reset-password/', {
		templateUrl	: '../../views/reset-password.html',
		controller	:	'resetPasswordCtrl'
	}).
	when('/contact-us/', {
		templateUrl: '../../views/contact-us.html',
		controller: 'ContactUs'
       
	}).
	when('/promotions/', {
		templateUrl: '../../views/promotions.html'
		
	}).
	when('/terms-of-service/', {
		templateUrl: '../../views/terms-of-service.html'
		
	}).
	when('/rummy-lobby/', {
		templateUrl: '../../views/dashboard/dashboard.html',
		controller :'DashboardCtrl',
		resolve: {factory: checkRouting}
		
	}).
	when('/my-account/', {
		templateUrl: '../../views/dashboard/my-account.html',
		resolve: {factory: checkRouting}
	}).
	when('/profile/', {
		templateUrl: '../../views/dashboard/profile.html',
		resolve: {factory: checkRouting}
	}).
	when('/change-password/', {
		templateUrl: '../../views/dashboard/change-password.html',
		resolve: {factory: checkRouting}
	}).
	when('/change-email/', {
		templateUrl: '../../views/dashboard/change-email.html',
		resolve: {factory: checkRouting}
	}).
	when('/change-email-confirmation/', {
		templateUrl: '../../views/dashboard/change-email-confirmation.html',
		resolve: {factory: checkRouting}
	}).
	when('/change-mobile/', {
		templateUrl: '../../views/dashboard/change-mobile.html',
		resolve: {factory: checkRouting}
	}).
	when('/change-username/', {
		templateUrl: '../../views/dashboard/change-username.html',
		resolve: {factory: checkRouting}
	}).
	when('/transactions/', {
		templateUrl: '../../views/dashboard/transactions.html',
		resolve: {factory: checkRouting}
	}).
	when('/tickets/', {
		templateUrl: '../../views/dashboard/tickets.html',
		resolve: {factory: checkRouting}
	}).
	when('/bonus-list/', {
		templateUrl: '../../views/dashboard/bonus-list.html',
		resolve: {factory: checkRouting}
	}).
	when('/preferences/', {
		templateUrl: '../../views/dashboard/preferences.html',
		resolve: {factory: checkRouting}
	}).
	when('/withdraw-cash/', {
		templateUrl: '../../views/dashboard/withdraw-cash.html',
		resolve: {factory: checkRouting}
	}).
	when('/withdraw-status/', {
		templateUrl: '../../views/dashboard/withdrawcashdetails.html',
		controller :'AccountCtrl',
		resolve: {factory: checkRouting}
	}).
	when('/cash-limits/', {
		templateUrl: '../../views/dashboard/cash-limits.html',
		resolve: {factory: checkRouting}
	}).
	when('/loyalty/', {
		templateUrl: '../../views/dashboard/loyalty.html',
		resolve: {factory: checkRouting}
	}).
	when('/rewards/', {
		templateUrl: '../../views/dashboard/rewards.html',
		resolve: {factory: checkRouting}
	}).
	when('/bring-a-friend/', {
		templateUrl: '../../views/dashboard/bring_a_friend.html',
		resolve: {factory: checkRouting}
	}).
	when('/link_referral/', {
		templateUrl: '../../views/dashboard/link_referral.html',
		resolve: {factory: checkRouting}
	}).
	when('/affiliate/', {
		templateUrl: '../../views/dashboard/affiliate.html',
		resolve: {factory: checkRouting}
	}).
	when('/my-referal/', {
		templateUrl: '../../views/dashboard/my_referal.html',
		resolve: {factory: checkRouting}
	}).
	when('/term-and-condition/', {
		templateUrl: '../../views/dashboard/term-and-condition.html',
		resolve: {factory: checkRouting}
	}).
	otherwise({
		templateUrl: '../../views/'+default_page,
		controller :default_ctrl
	});
	 
      
  }]);


 window.fbAsyncInit = function() {
  FB.init({
    appId      : '478077692374888',
    cookie     : true,  // enable cookies to allow the server to access 
                        // the session
    xfbml      : true,  // parse social plugins on this page
    version    : 'v2.2' // use version 2.2
  });

 /* FB.getLoginStatus(function(response) {
  	console.log(response);
    statusChangeCallback(response);
  });
*/
  };

  // Load the SDK asynchronously
  (function(d, s, id) {
    var js, fjs = d.getElementsByTagName(s)[0];
    if (d.getElementById(id)) return;
    js = d.createElement(s); js.id = id;
    js.src = "//connect.facebook.net/en_US/sdk.js";
    fjs.parentNode.insertBefore(js, fjs);
  }(document, 'script', 'facebook-jssdk'));
 
 var checkRouting= function ($q, $rootScope, $location) {
    if (userCokie) {
        return true;
    } else {
		 $location.path("/");
       
    }
};
  /* mainApp.factory('batchLog', ['$interval', '$log', function($interval, $log) {
  var messageQueue = [];

  function log() {
    if (messageQueue.length) {
      $log.log('batchLog messages: ', messageQueue);
      messageQueue = [];
    }
  }

  // start periodic checking
  $interval(log, 10000);

  return function(message) {
    messageQueue.push(message);
  }
}]); */