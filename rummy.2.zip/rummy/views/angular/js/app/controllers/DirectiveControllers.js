var userCokie = $.cookie('user');

var drc    =   angular.module('DirectiveControllers',[]);
var base_uri = 'http://mobirummy.com/';
socket = io.connect('http://mobirummy.com/');
if(userCokie){
		var user_id = userCokie._id;          	
}

drc.controller('AuthCtrl',['$http','$scope','$cookies','$cookieStore','$location',function ($http,$scope,$cookies,$cookieStore,$location)
                            { 
                        		if($location.search().q){
                        			var paramValue = $location.search().q;
									var  queryString = paramValue.split('/');
                        		}

                            	$scope.fbLogin = function(){
                            		FB.login(function(response) {

									    if (response.authResponse) {
									     FB.api('/me?fields=id,name,email,gender,birthday,picture,permissions', function(response) {
									     	if(!response.email){
									     		alert("Kindly make your email public. Other wise you can not login to mobirummy");
									     		$.removeCookie("user");
												$.cookie("user",null);
												$.cookie("user",'');
									     		return false;
									     	}else if(response.email){
									     		//console.log(response.picture.data.url); return false;
									     		$http.post(base_uri+'api/user/matchUsers',{userEmail:response.email}).success(function(matchData){
									     		console.log(matchData.data);
									     		if(matchData.data == null){
									     			$http.post(base_uri + 'api/user/addNewUser',{username:response.name,userEmail:response.email,firstname:response.name,gender:response.gender,dob:response.birthday,profilePic:response.picture.data.url}).success(function(data){			     				
														if(data){
															socket.emit('login', { userId:data.data._id});
																$cookieStore.put('user',data.data);
																setTimeout(function(){
																	window.location=base_uri+'angular/#home';
																},2000);
														}
													});
									     		}else if(matchData.data.email == response.email){
									     			console.log(matchData.data);
									     			socket.emit('login', { userId:matchData.data._id});
													$cookieStore.put('user',matchData.data);
													console.log($cookieStore.get('user'));
													setTimeout(function(){
														window.location=base_uri+'angular/#home';
													},2000);
									     		} 
									      	});
									     	}
									     	
									       });
									     }                            			
									},{scope:'email'});
								}


							
                                $scope.login    =   function ()
                                {
									
									var validationFlag=true;
									$scope.validateMessage='';
									if(!$scope.loginEmail){
										$scope.validateMessage="Pleas enter user email.!\n";
										validationFlag=false;
									}else if(!$scope.loginPassword){
										$scope.validateMessage ="Pleas enter user password.!";
										validationFlag=false;
									}
									if(validationFlag){									
										$http.get(base_uri + 'api/user/login?userEmail='+$scope.loginEmail+'&userPass='+$scope.loginPassword).success(function (returnData){
											console.log(returnData.data);
											if(returnData.data!= null){
												//$.cookie("user", returnData.data, { expires: 7 });	
												$cookieStore.put('user',returnData.data);
												setTimeout(function(){
													window.location=base_uri+'angular/#home';
												},2000);
												console.log('__________________cookies data------------');
												console.log($cookieStore.get('user'));
												socket.emit('login', { userId:returnData.data._id});
											}
											else
											{
												console.log(returnData.data);
												$scope.validateMessage ='Invalid Email Id Or Password';
											}
											//alert($.cookie('user'));
										});
										
													
									}
									
								};
								
								
                                $scope.signUp    =   function ()
                                {
									
									var validationFlag=true;
									$scope.signupValidateMessage='';
									if(!$scope.user){
										$scope.signupValidateMessage="Please enter user name.!\n";
										validationFlag=false;
									}else if(!$scope.password){
										$scope.signupValidateMessage="Please enter user password.!\n";
										validationFlag=false;
									}else if(!$scope.email){
										$scope.signupValidateMessage="Please enter user email.!\n";
										validationFlag=false;
									}else if(!$scope.dob){
										$scope.signupValidateMessage="Please select date of birth.!\n";
										validationFlag=false;
									}
									if(queryString){
										if(validationFlag){
										 $http.post(base_uri + 'api/user/addNewUser',{username:$scope.user,userEmail:$scope.email,userPass:$scope.password,dob:$scope.dob,gender:$scope.gender,contact:$scope.contact,firstname:$scope.firstName,refral:queryString}).success(function (data){
												if(data.name=="MongoError")
												{
													$scope.signupValidateMessage=data.err;
												}
												else
												{
													
													socket.emit('login', { userId:data.data._id});
													$.cookie("user", data.data, { expires: 7 });	
													$cookieStore.put('user',data.data);
													console.log($cookieStore.get('user'));
													setTimeout(function(){
														window.location=base_uri+'angular/#home';
													},2000);
													
												}
											})
										}
									}else{
										if(validationFlag){
										 $http.post(base_uri + 'api/user/addNewUser',{username:$scope.user,userEmail:$scope.email,userPass:$scope.password,dob:$scope.dob,gender:$scope.gender,contact:$scope.contact,firstname:$scope.firstName}).success(function (data){
												if(data.name=="MongoError")
												{
													$scope.signupValidateMessage=data.err;
												}
												else
												{
													
													socket.emit('login', { userId:data.data._id});
													//$.cookie("user", data.data, { expires: 7 });	
													$cookieStore.put('user',data.data);
													console.log($cookieStore.get('user'));
													setTimeout(function(){
														window.location=base_uri+'angular/#home';
													},2000);
													
												}
											})
										}
									}
									
                                };
								
								
								$scope.forgot    =   function ()
                                {
									var validationFlag=true;
									$scope.validateMessage='';
									if(!$scope.userEmail){
										$scope.validateMessage="Pleas enter email.!\n";
										validationFlag=false;
									}
									if(validationFlag){
										$http.put(base_uri + 'api/user/forgotPassword',{email:$scope.userEmail}).success(function (data){
											$scope.userEmail = '';
											$scope.forgetvalidateMessage = 'A reset link has been sent to your email id . Please login to verify your email.';
											//console.log(data);
										});	
									}
                                };
                            }]);


	drc.controller('resetPasswordCtrl',['$http','$scope', '$location',function ($http,$scope, $location){
		var paramValue = $location.search().q;
		var  queryString = paramValue.split('/');
        console.log(paramValue.split('/'));
        $scope.resetPassword = function(){
        	console.log('hellooooooo');
        				var resetFlag = true;
						$scope.resetValidateMessage='';
							if(!$scope.new_password){
							$scope.resetValidateMessage="Please enter your new Password.!\n";
							resetFlag=false;
						}else if(!$scope.c_password){
							$scope.resetValidateMessage="Please enter your Confirm Password.!\n";
							resetFlag=false;
						}else if($scope.new_password != $scope.c_password){
							$scope.resetValidateMessage="your new password and confirm password does not match!\n";
							resetFlag=false;
						}

						if(resetFlag){
							$http.put(base_uri + 'api/user/resetPassword', {userId:queryString[0],resetToken:queryString[1], password:$scope.new_password}).success(function(data){
									$scope.new_password = "";
									$scope.c_password = "";
									$scope.resetValidateMessage = "Your Password Has Been Changed Successfully..";

								});
						}

        }

	}]);
						

	drc.controller('AccountDrcCtrl',['$http','$scope','$location',function ($http,$scope,$location){
        $('.account_sub_menu').hide();
		$('.account_menu > li > a').mouseover(function(){
			$(this).next().slideToggle();
			$('.account_menu li a').removeClass('active');
			$(this).addClass('active');
		}); 
		
		var path =$location.path();
		path = path.substring(1, path.length-1);
		$(".account_menu li a").removeClass("activ");
		$(".account_menu li a[href$='"+path+"']").addClass("activ");
	}]);




	
	drc.controller('BringFriendDrcCtrl',['$http','$scope',function ($http,$scope){
        $('.account_sub_menu').hide();
		$('.account_menu > li > a').mouseover(function(){
			$(this).next().slideToggle();
			$('.account_menu li a').removeClass('active');
			$(this).addClass('active');
		});
		
		
		
	}]);

	drc.controller('HeaderDrcCtrl',['$http','$scope','$cookies','$cookieStore',function ($http,$scope,$cookies,$cookieStore){
		var userCokie=$cookieStore.get('user');
		if(userCokie){
		
			$scope.currentUserName = userCokie.name;
			$scope.currentUserEmail = userCokie.email;
			if(!$scope.$$phase){
				$scope.apply();
			}
			console.log($scope.currentUserEmail);
		}else{
			$scope.currentUserName = '';
			$scope.currentUserEmail = '';
		}
			
							
	}]);


	drc.controller('logoutCtrl',['$http','$scope',function ($http,$scope){
		
		$scope.logoutBtn = function(){
			var userCokie=$.cookie('user');
				$scope.currentUserEmail = userCokie.email;
				$scope.currentUserEmail = null;
				var cookie_status=$.removeCookie("user");
				$.cookie("user",null);
				var remove_cookie = $.cookie("user",'');
				
				if(cookie_status || remove_cookie)
				{
					window.location = "/angular";
				}
				
				

				
		
			
		}
							
	}]);
