pagees
.controller('BringFriendCtrl',['$http','$scope','$rootScope',function ($http,$scope,$rootScope)
{	
	var userCokie = $.cookie('user');
	var base_uri = 'http://mobirummy.com/';
	/*if(!userCokie){
		window.location = "http://witsserver.in/projects/angular/home";
	}*/
	 var clientId = '520167653721-p145q36bdeo6vacdk8jnuk13q48gij96.apps.googleusercontent.com';
	 var apiKey = 'AIzaSyB2HmoA4Bsmut5Lht6BOUWiDTRQPXev8So';
	 var scopes = 'https://www.googleapis.com/auth/contacts.readonly';
	 $scope.finalRecords = [];
	 $scope.totalRecords = [];
	 $scope.showUsers = false;
	$scope.inviteFriend = function(){

		 gapi.client.setApiKey(apiKey);
         window.setTimeout(authorize);
         $scope.showUsers = true;
	}

	 function authorize() {
        gapi.auth.authorize({client_id: clientId, scope: scopes, immediate: false}, handleAuthorization);
     }
	  function handleAuthorization(authorizationResult) {
	    if (authorizationResult && !authorizationResult.error) {
	      $.get("https://www.google.com/m8/feeds/contacts/default/thin?alt=json&access_token=" + authorizationResult.access_token + "&max-results=100&v=3.0",
	        function(response){
	         $.each(response.feed.entry, function(key, value){
	         var getVal = value;
	         	 var obj = {};
	         	 $scope.Fullname = '';
	         	$.each(getVal, function(k,v){
	         		$scope.$apply(function () {
			            if( k == 'title' ){
			            	$scope.Fullname = v.$t;
			            }
			            if( k == 'gd$email' ){
			            	obj = {};
			            	obj['name'] = $scope.Fullname;
			            	obj['email'] = v[0].address;
			            	$scope.finalRecords.push(obj);
			            }
			        });
	         	});
		        $scope.$apply(function () {
		        	$scope.finalRecords;
		        	$rootScope.finalRecords = $scope.finalRecords;
		        });
	         });
	        });
	    }
	  }
	
	 $scope.checkAll = function () {
        if ($scope.selectedAll) {
            $scope.selectedAll = true;
        } else {
            $scope.selectedAll = false;
        }
        angular.forEach($rootScope.finalRecords, function (record) {
            record.Selected = $scope.selectedAll;
        });

    };

    $scope.inviteBtn = function(){
    	userId = userCokie._id;
    	var sepratedValue = '';
    	$('input[name="chkboxName[]"]').each(function(i,e) {
	        	//console.log($(this).attr('data-email'));
	        	if ($(e).is(':checked')) {
			        var comma = sepratedValue.length===0?'':',';
			        sepratedValue += (comma+e.value);
			        
			    }
		});
		var seprateArray = sepratedValue.split(',');
		$http.post(base_uri+'api/user/sendInvitation',{invitationMail:seprateArray, refral:userId}).success(function(data){
			if(data.data == 'sent'){
				 $scope.showUsers = false;
				alert('Message Sent Successfully...');

			}
		});
    }

    $scope.sendEmails = function(){
    	userId = userCokie._id;
    	var multiEmails = [];
    	$('.tag').each(function(key,value){
    		 multiEmails.push($(this).find('span').text());
    	});
       	 $http.post(base_uri+'api/user/sendEmails',{invitationMail:multiEmails, refral:userId}).success(function(data){
			if(data.data == 'Message sent successfully'){
				alert('Message Sent Successfully...');
				$('.tag').each(function(key,value){
		    		 $('.tag').remove();
		    	});

			}
		});


    }
	
	
}

]);