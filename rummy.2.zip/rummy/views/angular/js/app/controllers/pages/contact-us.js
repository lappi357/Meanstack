pagees 
.controller('ContactUs',['$http','$scope',function ($scope)
{

	$('.account_sub_menu').hide();
	$('.account_menu > li > a').mouseover(function(){
      $(this).next().slideToggle();
      $('.account_menu li a').removeClass('active');
      $(this).addClass('active');
	});

}

]);