var userCokie = $.cookie('user');
var base_uri = 'http://mobirummy.com/';
var pagees = angular.module('pages',[]);
pagees.controller('AccountCtrl',['$http','$scope', '$rootScope' ,function ($http,$scope,$rootScope)
{	
	if(userCokie){
		var user_id = userCokie._id;          	
	}
	$scope.customer = [];

	$scope.customer=$rootScope.customer;
	console.log($scope.customer);

	 $scope.allWithdrawRequestStatus = function()
        {
        	
        	$http.get(base_uri+'api/wallet/getWithdrawlStatus?userId='+user_id).success(function(data){
        			 
    			
    				if(data.data!=null)
    				{
						$rootScope.withdraw_request_status=data.data;
						console.log('$scope.withdraw_request_status start');
						console.log($rootScope.withdraw_request_status);
						console.log('$scope.withdraw_request_status end');
    				}
    		
    			
    		});
        }
	/*
	$http.get(base_uri+'api/wallet/getWalletAmountByuid?userId='+user_id).success(function(data) {
			if(data.data != null){
				$scope.walletAmount = data.data.amount;
			}
		}).error(function(data) {
			console.log('Error: ' + data);
		});*/
	
	
	/*$http.get(base_uri+'api/user/getUserInfo?userId='+user_id).success(function(data) {
			if(data.data != null){
				$scope.customer = data.data;
			
				$scope.userPoints = data.data.userPoints;
			}
		}).error(function(data) {
			console.log('Error: ' + data);
		});*/

	$http.get(base_uri+'api/user/getAllUsers').success(function(data) {
		if(data != null){
			$scope.total_users = data.length;
		}
		else
		{
			$scope.total_users = 0;
		}
	}).error(function(data) {
		console.log('Error: ' + data);
	});

	  $scope.changePassword    =   function ()
                                {
                                	var passwordFlag=true;
									$scope.passwordValidateMessage='';
									if(!$scope.old_password){
										$scope.passwordValidateMessage="Please enter Current Password.!\n";
										passwordFlag=false;
									}else if(!$scope.new_password){
										$scope.passwordValidateMessage="Please enter New Password.!\n";
										passwordFlag=false;
									}else if(!$scope.c_password){
										$scope.passwordValidateMessage="Please enter Confirm Password.!\n";
										passwordFlag=false;
									}else if($scope.new_password != $scope.c_password){
										$scope.passwordValidateMessage="New Password and Confirm Password does not match.!\n";
										passwordFlag=false;
									}

									if(passwordFlag){
										$http.put(base_uri + 'api/user/changePassword', {userId:user_id, password:$scope.old_password, newPassword: $scope.new_password}).success(function(data){
											$scope.passwordValidateMessage = "Your Password Has Been Changed Successfully...";
											$scope.old_password= "";
											$scope.new_password = "";
											$scope.c_password = "";
										});
									}
                                }
        $scope.changeEmail = function(){
        					var emailFlag = true;
        					$scope.emailValidateMessage='';
        					if(!$scope.old_email){
								$scope.emailValidateMessage="Please enter Current Email Address.!\n";
								emailFlag=false;
							}else if(!$scope.new_email){
								$scope.emailValidateMessage="Please enter New Email Address.!\n";
								emailFlag=false;
							}

							if(emailFlag){
								$http.put(base_uri + 'api/user/changeUserEmail', {userId:user_id,email:$scope.old_email, newEmail:$scope.new_email }).success(function(data){
									$scope.old_email = "";
									$scope.new_email = "";
									$scope.emailValidateMessage = "Your Email Address Has Been Changed Successfully..";

								});
							}

        }


        $scope.registerWithdraw = function(){
        				var widthDrawCash = true;
        				$scope.widthDrawCashValidateMessage='';
        				if(!$scope.firstName){
								$scope.widthDrawCashValidateMessage="Please enter your first name!\n";
								widthDrawCash=false;
							}else if(!$scope.lastName){
								$scope.widthDrawCashValidateMessage="Please enter your last name!\n";
								widthDrawCash=false;
							}else if(!$scope.dob){
								$scope.widthDrawCashValidateMessage="Please enter your dob!\n";
								widthDrawCash=false;
							}else if(!$scope.addressLine1){
								$scope.widthDrawCashValidateMessage="Please enter your First adress!\n";
								widthDrawCash=false;
							}else if(!$scope.addressLine2){
								$scope.widthDrawCashValidateMessage="Please enter your Second adress!\n";
								widthDrawCash=false;
							}else if(!$scope.city){
								$scope.widthDrawCashValidateMessage="Please enter your city!\n";
								widthDrawCash=false;
							}else if(!$scope.state){
								$scope.widthDrawCashValidateMessage="Please enter your state!\n";
								widthDrawCash=false;
							}else if(!$scope.pincode){
								$scope.widthDrawCashValidateMessage="Please enter your pincode!\n";
								widthDrawCash=false;
							}else if(!$scope.mobileno){
								$scope.widthDrawCashValidateMessage="Please enter your mobile number!\n";
								widthDrawCash=false;
							}

							if(widthDrawCash){
								$http.post(base_uri + 'api/wallet/withdrawRequestStepOne', {userId:user_id,firstName:$scope.firstName,lastName:$scope.lastName,dob:$scope.dob,addressLine1:$scope.addressLine1,addressLine2:$scope.addressLine2,city:$scope.city,state:$scope.state,pincode:$scope.pincode,mobileno:$scope.mobileno}).success(function(data){
									$scope.firstName = '';
									$scope.lastName = '';
									$scope.dob = '';
									$scope.addressLine1 = '';
									$scope.addressLine2 = '';
									$scope.city = '';
									$scope.state = '';
									$scope.pincode = '';
									$scope.mobileno = '';
 									$("#withdrawOption").css( 'pointer-events', '' );
 									$('.withdrawOptionDiv').show();	
 									$('.informationDiv').hide();	
 									$scope.addressLinneOne = data.data.addressLine1;
 									$scope.addressLinneTwo = data.data.addressLine2;
 									$scope.usercity = data.data.city;
									$scope.userstate = data.data.state;
									$scope.userpincode = data.data.pincode;
								});
							}
        }

        
        $scope.secondDiv = function(){
        	$('.withdrawOptionDiv').show();
        	$('.informationDiv').hide();
        }

        $scope.changeMobile = function(){
    					var mobileFlag = true;
						$scope.mobileValidateMessage='';
							if(!$scope.mobilenumber){
							$scope.mobileValidateMessage="Please enter your mobile number.!\n";
							mobileFlag=false;
						}
						//$rootScope.customer.contact='';
						if(mobileFlag){
							$http.put(base_uri + 'api/user/updateMobileNo', {userId:user_id,contact:$scope.mobilenumber}).success(function(data){
									if(data.data != null){
										console.log($scope.customer.contact);
										console.log($scope.mobilenumber);
										var customerScope=angular.element('.customScope').scope();
										customerScope.customer=null;
										customerScope.customer=data.data;
										
										$scope.mobilenumber = "";
									    $scope.successmobileValidateMessage = "Your Mobile Number Has Been Changed Successfully..";

									}
									

								});


						}
        }


        $scope.addCash = function(){
        			var cashFlag = true;
        			$scope.cashValidateMessage='';
							if(!$scope.addcashamount){
							$scope.cashValidateMessage="Please enter cash amount.!\n";
							cashFlag=false;
						}
						if(cashFlag){
							location.href=base_uri + 'api/paypal/create?amount='+$scope.addcashamount+'&currency=USD&packageId=1&userId='+user_id ;
						}

        }

        $scope.gettransction = function(){
        	var transction_type = $scope.transction_type;
        	console.log(transction_type);
        	if(transction_type == 'AT'){
        		$http.get(base_uri+'api/user/getWalletTnxDetailByUserId?userId='+user_id).success(function(data){
        			$scope.transctions = data.data;
        			
        		});
        	}
        	if(transction_type == 'dnw'){
        	$http.get(base_uri+'api/user/getWalletTnxDetailByUserId?userId='+user_id+'&transactionType=dnw').success(function(data){
        			$scope.transctions = data.data;
        			
        		});
        	}
        	if(transction_type == 'game_transactiom'){
        	$http.get(base_uri+'api/user/getWalletTnxDetailByUserId?userId='+user_id+'&transactionType=game_transactiom').success(function(data){
        			$scope.transctions = data.data;
        			
        		});
        	}
        	if(transction_type == 'Bonuses'){
        	$http.get(base_uri+'api/user/getWalletTnxDetailByUserId?userId='+user_id+'&transactionType=Bonuses').success(function(data){
        			$scope.transctions = data.data;
        			
        		});
        	}
        	if(transction_type == 'ot'){
        	$http.get(base_uri+'api/user/getWalletTnxDetailByUserId?userId='+user_id+'&transactionType=ot').success(function(data){
        			$scope.transctions = data.data;
        			
        		});
        	}
        }

        $scope.firstDiv = function(){
        	$('.informationDiv').show();
        	$('.withdrawOptionDiv').hide();
        }

        $scope.withdrawCash = function(){
        	$http.get(base_uri+'api/wallet/getWddetailsByuidAndSts?userId='+user_id+'&wdstatus=process').success(function(data){
        			 
        			if(data.data != null){
        			$rootScope.addressLinneOne = data.data.addressLine1;
					$rootScope.addressLinneTwo = data.data.addressLine2;
					$rootScope.usercity = data.data.city;
					$rootScope.userstate = data.data.state;
					$rootScope.userpincode = data.data.pincode;
					$rootScope.accountHolderName = data.data.firstName;
        			
        				$("#yourInfo").css( 'pointer-events', 'none' ); 
        				$('.withdrawOptionDiv').show();	
        				$('.informationDiv').hide();	

        			}else if(data.data == null){
 						$("#withdrawOption").css( 'pointer-events', 'none' );
        				$('.informationDiv').show();
        				$('.withdrawOptionDiv').hide();
        			}
        			
        		});
        	
        }

       


        $scope.chequeTransfer = function(){
        	$('.addressInfo').show();
        	$('.onlineAddressInfo').hide();
        }

        $scope.onlineTransfer = function(){
        	$('.onlineAddressInfo').show();
        	$('.addressInfo').hide();
        }

        $scope.getAmount =  function(){
        	var trackAmounts = true;
				$scope.trackAmountValidateMessage='';
				if(!$scope.trackAmount){
					$scope.trackAmountValidateMessage="Please enter the amount!\n";
					trackAmounts=false;
				}

				if(trackAmounts){
					$http.get(base_uri+'api/wallet/getWalletAmountByuid?userId='+user_id).success(function(data){
        			console.log(data.data.amount);

        			console.log('hello'+$scope.trackAmount);
        			if(data.data!=null)
        			{
        				if(data.data.amount <= $scope.trackAmount){
        				$scope.trackAmountValidateMessage="Your wallet amount is less then " + $scope.trackAmount ;
        				$scope.trackAmount = '';
	        			}else if(data.data.amount >= $scope.trackAmount){
	        				$http.get(base_uri+'api/wallet/getWddetailsByuidAndSts?userId='+user_id+'&wdstatus=process').success(function(data){
			        			if(data.data != null){	        				
				        			$http.put(base_uri+'api/wallet/withdrawRequestStepTwo', {requestId:data.data._id, withdrawType:'echeque', accountHolderName:'', accountNumber: '', MICRCode:'', IFSCCode: '', bankName:'',amount:$scope.trackAmount}).success(function(data){
		        						$scope.trackAmount = '';
		        						$scope.trackAmountValidateMessage='Withdraw request sent successfully';
		        				});

			        			}
			        			
			        		});
	        				
	        			}
        			}
        			
        			
        			
        			});
				}
        }

        $scope.transContinue = function(){
        	var transctionContinue = true;
        				$scope.transContinueValidateMessage='';
        				if(!$scope.accountHolderName){
								$scope.transContinueValidateMessage="Please enter account holder name!\n";
								transctionContinue=false;
						}else if(!$scope.accountnumber){
								$scope.transContinueValidateMessage="Please enter your account number!\n";
								transctionContinue=false;
						}else if(!$scope.micrcode){
								$scope.transContinueValidateMessage="Please enter your micr code!\n";
								transctionContinue=false;
						}else if(!$scope.ifsccode){
								$scope.transContinueValidateMessage="Please  enter your ifsc code!\n";
								transctionContinue=false;
						}else if(!$scope.bankname){
								$scope.transContinueValidateMessage="Please  enter your bankName!\n";
								transctionContinue=false;
						}else if(!$scope.branchname){
								$scope.transContinueValidateMessage="Please  enter your branchname!\n";
								transctionContinue=false;
						}else if(!$scope.enteramount){
								$scope.transContinueValidateMessage="Please  enter your amount!\n";
								transctionContinue=false;
						}
						
						if(transctionContinue){
							$http.get(base_uri+'api/wallet/getWddetailsByuidAndSts?userId='+user_id+'&wdstatus=process').success(function(data){
		        			
		        			if(data.data != null){	        				
			        			$http.put(base_uri+'api/wallet/withdrawRequestStepTwo', {requestId:data.data._id, withdrawType:'Online', accountHolderName:$scope.accountHolderName, accountNumber: $scope.accountnumber, MICRCode:$scope.micrcode, IFSCCode: $scope.ifsccode, bankName:$scope.bankname, branchName:$scope.branchname, amount:$scope.enteramount }).success(function(data){
	        						console.log(data);
	        						$scope.accountHolderName ="";
	        						$scope.accountnumber ="";
	        						$scope.micrcode ="";
	        						$scope.ifsccode ="";
	        						$scope.bankname ="";
	        						$scope.branchname ="";
	        						$scope.enteramount ="";


	        				});

		        			}
		        			
		        		});

						}
        }




 }]);

pagees.controller('HomeCtrl',['$http','$scope',function ($http,$scope)
{
	$('.bxslider').bxSlider({
	  auto: true,						
	  pagerCustom: '#bx-pager'
	});
	
	$('.teenpatti_slider').bxSlider({
		auto: true,
	   controls: true,
	   pager:false
	});	
	
	/*$('.testimonial_slider').bxSlider({
	   auto: true,
	   controls: true,
	   pager:false
  
	});*/

}

]);