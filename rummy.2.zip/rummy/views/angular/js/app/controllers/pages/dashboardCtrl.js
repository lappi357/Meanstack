var userCokie = $.cookie('user');
var base_uri = 'http://mobirummy.com/';
socket = io.connect('http://mobirummy.com/');
pagees.controller('DashboardCtrl',['$http','$scope','$rootScope',function ($http,$scope,$rootScope)
{	
	// $scope.dashwalletAmount=$rootScope.walletAmount;
	// $scope.dashwalletpoints=$rootScope.userPoints;
	
	if(userCokie){
		var user_id = userCokie._id;  
		console.log(user_id);        	
	}

	$scope.user	=	$.cookie("user");
	console.log('testing');

	$http.get(base_uri+'api/wallet/getWalletAmountByuid?userId='+user_id).success(function(data) {
			if(data.data != null){
				$scope.walletAmount = data.data.amount;
				$rootScope.walletAmount = data.data.amount;
				$scope.dashwalletAmount = data.data.amount;
				$rootScope.dashwalletAmount = data.data.amount;
				$scope.amount_message="Insufficent Balance";

			}
		}).error(function(data) {
			console.log('Error: ' + data);
		});

		$http.get(base_uri+'api/user/getUserInfo?userId='+user_id).success(function(data) {
			if(data.data != null){
				$scope.customer = data.data;
				$rootScope.customer= data.data;
				$scope.userPoints = data.data.userPoints;
				$rootScope.userPoints= data.data.userPoints;
				$scope.dashwalletpoints= data.data.userPoints;
				$scope.points_message="Insufficent Points";
			}
		}).error(function(data) {
			console.log('Error: ' + data);
		});

	

	$scope.pointsRummy = function()	{
		$http.get(base_uri+'api/table/getTblsByMtchFrmtId?matchFormatId=1&matchMethod=practice').success(function (returnData){
			$scope.practiceMatches =	returnData.data;
		});
	}

	$scope.cashPointsRummy = function(){
		$http.get(base_uri+'api/table/gatAllCashTypeMatches?matchFormatId=1&matchMethod=cash').success(function (cashPointsRummyData){
			if(cashPointsRummyData != null){
				$scope.cashPointsRummyData = cashPointsRummyData.data;	
			}else{
				$scope.cashPointRummyDataMsg = "No Records Found" ;
			}		
		});

	}

	$scope.cashPoolRummy = function(){
		$http.get(base_uri+'api/table/gatAllCashTypeMatches?matchFormatId=2&matchMethod=cash').success(function (cashPoolRummyData){
			if(cashPoolRummyData != null){
				$scope.cashPoolRummyData = cashPoolRummyData.data;
			}else{
				$scope.cashPoolRummyDataMsg = "No Records Found" ;
			}
		});

	}

	$scope.cashDealRummy = function(){
		$http.get(base_uri+'api/table/gatAllCashTypeMatches?matchFormatId=3&matchMethod=cash').success(function (cashDealRummyData){
			if(cashDealRummyData != null){
				$scope.cashDealRummyData = cashDealRummyData.data;
				var dealscope= angular.element('.dealrummycash').scope();
				console.log(cashDealRummyData.data)
			}else{
				$scope.cashDealRummyDataMsg = "No Records Found" ;
			}
		});

	}

	socket.on('addTable', function(data){
		 console.log(data);
		if(data.action == 1 && data.gameType == 'practice'){
			$('.pointsClick').trigger('click');
		}
		if(data.action == 2 && data.gameType == 'practice'){
			$('.poolClick').trigger('click');	
		}
		if(data.action == 3 && data.gameType == 'practice'){
			$('.dealClick').trigger('click');	
		}
		if(data.action == 1 && data.gameType == 'cash'){
			$('.cashpointsClick').trigger('click');
		}
		if(data.action == 2 && data.gameType == 'cash'){
			$('.cashpoolClick').trigger('click');	
		}
		if(data.action == 3 && data.gameType == 'cash'){
			$('.cashdealClick').trigger('click');	
		}
	});
	socket.on('listGame', function(data){
		console.log(data);
		if(data.action == 1 && data.gameType == 'practice'){
			$scope.practiceMatches = data.result;
			$scope.$apply();
		}
		if(data.action == 2 && data.gameType == 'practice'){
			$scope.poolMatches = data.result;
			$scope.$apply();
		}
		if(data.action == 3 && data.gameType == 'practice'){
			$scope.dealMatches = data.result;
			$scope.$apply();
		}
		if(data.action == 1 && data.gameType == 'cash'){
			$scope.cashPointsRummyData = data.result;
			$scope.$apply();
		}
		if(data.action == 2 && data.gameType == 'cash'){
			$scope.cashPoolRummyData = data.result;
			$scope.$apply();
		}
		if(data.action == 3 && data.gameType == 'cash'){
			$scope.cashDealRummyData = data.result;
			$scope.$apply();
		}
	});

	$scope.cashpointsMatchJoin =  function(){
		setTimeout(function(){
			$http.get(base_uri+'api/table/gatAllCashTypeMatches?matchFormatId=1&matchMethod=cash').success(function (returnData){
				/*$scope.practiceMatches =	returnData.data;
				scope.$apply();*/
		});
		},2000);
	}

	$scope.cashpoolsMatchJoin =  function(){
		setTimeout(function(){
			$http.get(base_uri+'api/table/gatAllCashTypeMatches?matchFormatId=2&matchMethod=cash').success(function (returnData){
				/*$scope.practiceMatches =	returnData.data;
				scope.$apply();*/
		});
		},2000);
	}

	$scope.cashdealsMatchJoin =  function(){
		setTimeout(function(){
			$http.get(base_uri+'api/table/gatAllCashTypeMatches?matchFormatId=3&matchMethod=cash').success(function (returnData){
				/*$scope.practiceMatches =	returnData.data;
				scope.$apply();*/
		});
		},2000);
	}

	$scope.pointsMatchJoin =  function(){
		setTimeout(function(){
			$http.get(base_uri+'api/table/getTblsByMtchFrmtId?matchFormatId=1&matchMethod=practice').success(function (returnData){
				/*$scope.practiceMatches =	returnData.data;
				scope.$apply();*/
		});
		},2000);
	}

	$scope.poolsMatchJoin =  function(){
		setTimeout(function(){
			$http.get(base_uri+'api/table/getTblsByMtchFrmtId?matchFormatId=2&matchMethod=practice').success(function (returnData){
				/*$scope.practiceMatches =	returnData.data;
				scope.$apply();*/
		});
		},2000);
	}

	$scope.dealsMatchJoin =  function(){
		setTimeout(function(){
			$http.get(base_uri+'api/table/getTblsByMtchFrmtId?matchFormatId=3&matchMethod=practice').success(function (returnData){
				/*$scope.practiceMatches =	returnData.data;
				scope.$apply();*/
		});
		},2000);
	}

	angular.element('.pointsVal').on('change', function(){

		var pointsLength = $('.pointsVal:checked').length;
		var queryArray = [];
		$('.pointsVal').each(function(key,val)
	 	{
	 		if($(this).is(':checked'))
	 		{
	 			var twoDeckQuery = {filterId:$(this).val()};
	 			queryArray.push(twoDeckQuery);
	 		}
	 	});
	 	var query=queryArray;
		if(pointsLength){
			$http.post(base_uri+'api/table/getTblsByFltrsnMfid',{matchFormatId:1, matchMethod:'practice',filters:query}).success(function(pointsFilterData){
				console.log(pointsFilterData);
				$scope.practiceMatches =	pointsFilterData.data;
			});
		}
	});
		
		
		angular.element('.poolsVal').on('change', function(){
			var poolsLength = $('.poolsVal:checked').length;
			var poolsArray = [];
			$('.poolsVal').each(function(key,val)
		 	{
		 		if($(this).is(':checked'))
		 		{
		 			var poolsQuery = {filterId:$(this).val()};
		 			poolsArray.push(poolsQuery);
		 		}
		 	});
		 	var poolQuery=poolsArray;
			if(poolsLength){
				$http.post(base_uri+'api/table/getTblsByFltrsnMfid',{matchFormatId:2, matchMethod:'practice',filters:poolQuery}).success(function(poolsFilterData){
					console.log(poolsFilterData);
					$scope.poolMatches =	poolsFilterData.data;
				});
			}
		});

	$scope.pooolRummy = function(){
		$http.get(base_uri+'api/table/getTblsByMtchFrmtId?matchFormatId=2&matchMethod=practice').success(function (poolData){
			$scope.poolMatches =	poolData.data;
		});
	}
	
	angular.element('.dealsVal').on('change', function(){
			var dealsLength = $('.dealsVal:checked').length;
			var dealsArray = [];
			$('.dealsVal').each(function(key,val)
		 	{
		 		if($(this).is(':checked'))
		 		{
		 			var dealsQuery = {filterId:$(this).val()};
		 			dealsArray.push(dealsQuery);
		 		}
		 	});
		 	var dealsQuery=dealsArray;
			if(dealsLength){
				$http.post(base_uri+'api/table/getTblsByFltrsnMfid',{matchFormatId:3, matchMethod:'practice',filters:dealsQuery}).success(function(dealsFilterData){
					console.log(dealsFilterData);
					$scope.dealMatches =	dealsFilterData.data;
				});
			}
		});


	$scope.dealRummy = function(){
		$http.get(base_uri+'api/table/getTblsByMtchFrmtId?matchFormatId=3&matchMethod=practice').success(function (dealData){
			$scope.dealMatches =	dealData.data;
		});	
	}

	$scope.twentyonecardRummy = function(){
		$http.get(base_uri+'api/table/getTblsByMtchFrmtId?matchFormatId=4').success(function (fourthData){
			$scope.fourthDataMatches =	fourthData.data;
		});	
	}
	
	$scope.joinMatch = function(){
		var matchId = $('#joinMatch').attr('data-matchId');
		
		var userId = userCokie._id;
		$http.get(base_uri+'api/game/joinUserMatch/'+matchId+'/'+userId).success(function(data){
			if(data=="Joined")
			{
				window.location.href=base_uri+'game#?q='+matchId+'&p='+userId;
			}
			else
			{
				alert(data);
			}
		});

	};
	

	$scope.findMeGame = function(){
		var userId = userCokie._id;
		$http.get(base_uri+'api/table/findMeAGame?userId='+ userId+'&matchMethod='+$scope.matches.matchMethod+'&matchFormatId='+  $scope.matches.matchFormatId+'&maxPlayers='+ $scope.matches.maxPlayers).success(function(data){
			console.log(data);
			if(data.data != null){
				window.location.href = base_uri+'joinMatch/'+data.data._id+'/'+userId;
			}
		});
	}

	


	/*Added by Rashmi sharma 0n 18-09-2015*/
	angular.element('.cash_pointsVal').on('change', function(){

		var pointsLength = $('.cash_pointsVal:checked').length;
		var queryArray = [];
		$('.cash_pointsVal').each(function(key,val)
	 	{
	 		if($(this).is(':checked'))
	 		{
	 			var twoDeckQuery = {filterId:$(this).val()};
	 			queryArray.push(twoDeckQuery);
	 		}
	 	});
	 	var query=queryArray;
		if(pointsLength){
			$http.post(base_uri+'api/table/getTblsByFltrsnMfid',{matchFormatId:1, matchMethod:'cash',filters:query}).success(function(pointsFilterData){
				console.log(pointsFilterData);
				$scope.cashPointsRummyData =	pointsFilterData.data;
			});
		}
	});
		
		
	angular.element('.cash_poolsVal').on('change', function(){
		var poolsLength = $('.cash_poolsVal:checked').length;
		var poolsArray = [];
		$('.cash_poolsVal').each(function(key,val)
	 	{
	 		if($(this).is(':checked'))
	 		{
	 			var poolsQuery = {filterId:$(this).val()};
	 			poolsArray.push(poolsQuery);
	 		}
	 	});
	 	var poolQuery=poolsArray;
		if(poolsLength){
			$http.post(base_uri+'api/table/getTblsByFltrsnMfid',{matchFormatId:2, matchMethod:'cash',filters:poolQuery}).success(function(poolsFilterData){
				console.log(poolsFilterData);
				$scope.cashPoolRummyData =	poolsFilterData.data;
			});
		}
	});

	angular.element('.cash_dealsVal').on('change', function(){
		var dealsLength = $('.cash_dealsVal:checked').length;
		var dealsArray = [];
		$('.cash_dealsVal').each(function(key,val)
	 	{
	 		if($(this).is(':checked'))
	 		{
	 			var dealsQuery = {filterId:$(this).val()};
	 			dealsArray.push(dealsQuery);
	 		}
	 	});
	 	var dealsQuery=dealsArray;
		if(dealsLength){
			$http.post(base_uri+'api/table/getTblsByFltrsnMfid',{matchFormatId:3, matchMethod:'cash',filters:dealsQuery}).success(function(dealsFilterData){
				console.log(dealsFilterData);
				$scope.cashDealRummyData =	dealsFilterData.data;
			});
		}
	});
	
	angular.element('.club_tournament_filter').on('change', function(){
		var tournament_Length = $('.club_tournament_filter:checked').length;
		var tournamentArray = [];
		$('.club_tournament_filter').each(function(key,val)
	 	{
	 		if($(this).is(':checked'))
	 		{
	 			var tournamentQuery = {filterId:$(this).val()};
	 			tournamentArray.push(tournamentQuery);

	 		}
	 	});
	 	var tournamentQuery=tournamentArray;
		if(tournament_Length){
			$http.post(base_uri+'api/tournament/filterClubTournaments',{filters:tournamentQuery}).success(function(tournamentFilterData){
				console.log(tournamentFilterData);
				$scope.getAllClubdata =	tournamentFilterData.data;
			});
		}
	});
	angular.element('.cash_tournament_filter').on('change', function(){
		var tournament_Length = $('.cash_tournament_filter:checked').length;
		var tournamentArray = [];
		$('.cash_tournament_filter').each(function(key,val)
	 	{
	 		if($(this).is(':checked'))
	 		{
	 			var tournamentQuery = {filterId:$(this).val()};
	 			tournamentArray.push(tournamentQuery);
	 			
	 		}
	 	});
	 	var tournamentQuery=tournamentArray;
		if(tournament_Length){
			$http.post(base_uri+'api/tournament/filterCashTournaments',{filters:tournamentQuery}).success(function(tournamentFilterData){
				console.log(tournamentFilterData);
				$scope.getAllCashdata =	tournamentFilterData.data;
			});
		}
	});
	angular.element('.special_tournament_filter').on('change', function(){
		var tournament_Length = $('.special_tournament_filter:checked').length;
		var tournamentArray = [];
		$('.special_tournament_filter').each(function(key,val)
	 	{
	 		if($(this).is(':checked'))
	 		{
	 			var tournamentQuery = {filterId:$(this).val()};
	 			tournamentArray.push(tournamentQuery);
	 			
	 		}
	 	});
	 	var tournamentQuery=tournamentArray;
		if(tournament_Length){
			$http.post(base_uri+'api/tournament/filterSpecialTournaments',{filters:tournamentQuery}).success(function(tournamentFilterData){
				console.log(tournamentFilterData);
				$scope.getAllSpecialdata =	tournamentFilterData.data;
			});
		}
	});
	angular.element('.beginner_tournament_filter').on('change', function(){

		var tournament_Length = $('.beginner_tournament_filter:checked').length;
		var tournamentArray = [];
		$('.beginner_tournament_filter').each(function(key,val)
	 	{
	 		if($(this).is(':checked'))
	 		{
	 			var tournamentQuery = {filterId:$(this).val()};
	 			tournamentArray.push(tournamentQuery);
	 			
	 		}
	 	});
	 	var tournamentQuery=tournamentArray;
		if(tournament_Length){
			$http.post(base_uri+'api/tournament/filterBeginnersTournaments',{filters:tournamentQuery}).success(function(tournamentFilterData){
				console.log(tournamentFilterData);
				$scope.getAllBeginnersdata =	tournamentFilterData.data;
			});
		}
	});
	angular.element('.weekendloot_tournament_filter').on('change', function(){
		var tournament_Length = $('.weekendloot_tournament_filter:checked').length;
		var tournamentArray = [];
		$('.weekendloot_tournament_filter').each(function(key,val)
	 	{
	 		if($(this).is(':checked'))
	 		{
	 			var tournamentQuery = {filterId:$(this).val()};
	 			tournamentArray.push(tournamentQuery);
	 			
	 		}
	 	});
	 	var tournamentQuery=tournamentArray;
		if(tournament_Length){
			$http.post(base_uri+'api/tournament/filterWeekendlootTournaments',{filters:tournamentQuery}).success(function(tournamentFilterData){
				console.log(tournamentFilterData);
				$scope.getAllWeekendlootdata =	tournamentFilterData.data;
			});
		}
	});
	angular.element('.rewardpoints_tournament_filter').on('change', function(){
		var tournament_Length = $('.rewardpoints_tournament_filter:checked').length;
		var tournamentArray = [];
		$('.rewardpoints_tournament_filter').each(function(key,val)
	 	{
	 		if($(this).is(':checked'))
	 		{
	 			var tournamentQuery = {filterId:$(this).val()};
	 			tournamentArray.push(tournamentQuery);
	 			
	 		}
	 	});
	 	var tournamentQuery=tournamentArray;
		if(tournament_Length){
			$http.post(base_uri+'api/tournament/filterRewardpointsTournaments',{filters:tournamentQuery}).success(function(tournamentFilterData){
				console.log(tournamentFilterData);
				$scope.getAllRewardlootdata =	tournamentFilterData.data;
			});
		}
	});
	angular.element('.jackpots_tournament_filter').on('change', function(){
		var tournament_Length = $('.jackpots_tournament_filter:checked').length;
		var tournamentArray = [];
		$('.jackpots_tournament_filter').each(function(key,val)
	 	{
	 		if($(this).is(':checked'))
	 		{
	 			var tournamentQuery = {filterId:$(this).val()};
	 			tournamentArray.push(tournamentQuery);
	 			
	 		}
	 	});
	 	var tournamentQuery=tournamentArray;
		if(tournament_Length){

			$http.post(base_uri+'api/tournament/filterJackpotsTournaments',{filters:tournamentQuery}).success(function(tournamentFilterData){
				console.log(tournamentFilterData);
				$scope.getAllJackpotslootdata =	tournamentFilterData.data;
			});
		}
	});



	$scope.getClubTournament = function(){
		$http.get(base_uri+'api/tournament/getAllClubTournaments').success(function(getAllClubdata){
			if(getAllClubdata != null){
				$scope.getAllClubdata = getAllClubdata.data;
			}else{
				$scope.getAllClubdata = "No Records Found" ;
			}
		});
	}

	$scope.getAllCashTournaments = function(){
		$http.get(base_uri+'api/tournament/getAllCashTournaments').success(function(getAllCashdata){
			if(getAllCashdata != null){
				$scope.getAllCashdata = getAllCashdata.data;
			}else{
				$scope.getAllCashdata = "No Records Found" ;
			}
		});
	}

	$scope.getAllSpecialTournament = function(){
		$http.get(base_uri+'api/tournament/getAllSpecialTournament').success(function(getAllSpecialdata){
			if(getAllSpecialdata != null){
				$scope.getAllSpecialdata = getAllSpecialdata.data;
			}else{
				$scope.getAllSpecialdata = "No Records Found" ;
			}
		});
	}

		$scope.getAllBeginnersTournament = function(){
		$http.get(base_uri+'api/tournament/getAllBeginnersTournament').success(function(getAllBeginnersdata){
			if(getAllBeginnersdata != null){
				$scope.getAllBeginnersdata = getAllBeginnersdata.data;
			}else{
				$scope.getAllBeginnersdata = "No Records Found" ;
			}
		});
	}

	$scope.getAllWeekendlootTournament = function(){
		$http.get(base_uri+'api/tournament/getAllWeekendlootTournament').success(function(getAllWeekendlootdata){
			if(getAllWeekendlootdata != null){
				$scope.getAllWeekendlootdata = getAllWeekendlootdata.data;
			}else{
				$scope.getAllWeekendlootdata = "No Records Found" ;
			}
		});
	}

	$scope.getAllRewardpointsTournament = function(){
		$http.get(base_uri+'api/tournament/getAllRewardpointsTournament').success(function(getAllRewardlootdata){
			if(getAllRewardlootdata != null){
				$scope.getAllRewardlootdata = getAllRewardlootdata.data;
			}else{
				$scope.getAllRewardlootdata = "No Records Found" ;
			}
		});
	}

	$scope.getAllJackpotsTournament = function(){
		$http.get(base_uri+'api/tournament/getAllJackpotsTournament').success(function(getAllJackpotslootdata){
			if(getAllJackpotslootdata != null){
				$scope.getAllJackpotslootdata = getAllJackpotslootdata.data;
			}else{
				$scope.getAllJackpotslootdata = "No Records Found" ;
			}
		});
	}




	
	$scope.disableFilter = function(){
		console.log('Hello00000');
	}


	$('#FMG_helpmask_img').hide();
	/*$('.rm_slide_gg').bxSlider({
		minSlides: 4,
		maxSlides: 2,
		slideWidth: 400,
		slideMargin: 10,
		pager:false
	
	});*/
		
	$(".open_tab1").hide(); 
	$(".tab_button ul li:first").addClass("cc_active").show();
	$(".open_tab1:first").show(); 	
		$(".tab_button ul li").click(function() {			
			$(".tab_button ul li").removeClass("cc_active"); //Remove any "active" class
			$(this).addClass("cc_active"); //Add "active" class to selected tab
			$(".open_tab1").hide(); //Hide all tab content
			var activeTab = $(this).find("a").attr("href"); //Find the rel attribute value to identify the active tab + content
			$(activeTab).fadeIn(); //Fade in the active content	
			return false;
	});
		
	$(".open_tab2").hide(); 
	$(".tab_button2 ul li:first").addClass("cc_active").show();
	$(".open_tab2:first").show(); 	
	$(".tab_button2 ul li").click(function() {			
		$(".tab_button2 ul li").removeClass("cc_active"); //Remove any "active" class
		$(this).addClass("cc_active"); //Add "active" class to selected tab
		$(".open_tab2").hide(); //Hide all tab content
		var activeTab = $(this).find("a").attr("href"); //Find the rel attribute value to identify the active tab + content
		$(activeTab).fadeIn(); //Fade in the active content	
		return false;
	});



	$(".popover-examples li a").popover('hide');   

	/* code for tournament filter */
	$('.head-click').on('click', function (e) {
		$(this).next('.nav_child').stop(true, true).slideDown();
		$(this).parent().siblings().children('.nav_child').stop(true, true).slideUp();
		return false;
	});
	$('.nav_parent').on('mouseleave', function () {
		$(this).children('.nav_child').stop(true, true).slideUp();
		return false;
	});


}

]);