var base_uri = 'http://mobirummy.com/';
var apiUrl = 'http://mobirummy.com/api';

pagees.controller('constactUsCtrl',['$http','$scope',function ($http,$scope)
{	
	$scope.user = [];
	$scope.contactUs = function()	{
			var contactFlag=true;
			$scope.contactValidateMessage='';
			if(!$scope.user.name){
				$scope.contactValidateMessage="Please enter your name.!\n";
				contactFlag=false;
			}else if(!$scope.user.email){
				$scope.contactValidateMessage="Please enter your email.!\n";
				contactFlag=false;
			}else if(!$scope.user.topic){
				$scope.contactValidateMessage="Please select your category.!\n";
				contactFlag=false;
			}else if(!$scope.user.messge){
				$scope.contactValidateMessage="Please enter your message.!\n";
				contactFlag=false;
			}
			if(contactFlag){
				$http.post(apiUrl+'/user/contactus',{name:$scope.user.name, email:$scope.user.email,topic:$scope.user.topic, messge:$scope.user.messge}).success(function(data){
					if(data.data != ''){
						$scope.contactsuccessMessage = "We will contact you soon..";
						$scope.user = {};
					}
				});
			}
	}
	
}

]);