var auth    =   angular.module('Directives', ['DirectiveControllers']);




auth.directive('authForm', function() {
  return {
      
    templateUrl: '../../../views/login.html',
    controller:'AuthCtrl'
	  
  };
});




auth.directive('forgotForm', function() {
  return {
      
    templateUrl: '../../../views/forgot-password.html',
      controller:'AuthCtrl'
	  
  };
});

auth.directive('signupForm', function() {
  return {
      
    templateUrl: '../../../views/signup.html',
	 controller:'AuthCtrl'
  };
});

auth.directive('header', function() {
  return {
    templateUrl: '../../../views/header.html',
	controller:'HeaderDrcCtrl'
  };
});


auth.directive('footer', function() {
  return {
    templateUrl: '../../../views/footer.html'
  };
});

auth.directive('accountLeftMenu', function() {
  return {
    templateUrl: '../../../views/dashboard/my-act-left-menu.html',
	controller:'AccountDrcCtrl'
  };
});
auth.directive('userDetail', function() {
  return {
    templateUrl: '../../../views/dashboard/user-detail.html',
	controller:'HeaderDrcCtrl'
  };
});
auth.directive('bringFriendLeftMenu', function() {
  return {
    templateUrl: '../../../views/dashboard/bringFriendLeftMenu.html',
	controller:'BringFriendDrcCtrl'
  };
});

auth.directive('mobileForm', function() {
  return {
      
    templateUrl: '../../../views/dashboard/change-mobile.html',
    controller:'AccountCtrl'
    
  };
});

auth.directive('addCash', function() {
  return {      
    templateUrl: '../../../views/dashboard/add-cash.html',
    controller:'AccountCtrl'
    
  };
});


