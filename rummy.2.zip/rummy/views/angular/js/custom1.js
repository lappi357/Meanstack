// JavaScript Document
$(document).ready(function() {
	
	$(function () {
	  $('[data-toggle="tooltip"]').tooltip()
	})
	/*
	var rumwidth = $('.inner_table').width();
	$('.rum_card ul').css('min-width',(rumwidth)/7);
	var ulwidth = $('.rum_card ul').width();	
	$('.rum_card ul li').css('min-width',(ulwidth)/3);
	*/
	

	if(jQuery('.main_card').length>1)
	{
		$('.main_card').removeClass('main_card').addClass('card_in');
	}
			
	var winheight = $(window).height();
	$('#rc_wrapper').css('height',winheight);
	$(window).resize(function(){
		var winheight = $(window).height();
		$('#rc_wrapper').css('height',winheight);
	});
	
	var viewport = $(window).innerWidth();
	
	if( viewport <= 767 )
	{

	  $('.rum_card ul li').css('width',(rumwidth+320)/16); 
	}


	
	
		
   // $(".DateCountdown").TimeCircles();
});



//tab start
jQuery(document).ready(function($) {	
	$(".open_tab1").hide(); 
	$(".discards_tab li:first").addClass("rc_active").show();
	$(".open_tab1:first").show(); 	
		$(".discards_tab li").click(function() {			
			$(".discards_tab li").removeClass("rc_active"); //Remove any "active" class
			$(this).addClass("rc_active"); //Add "active" class to selected tab
			$(".open_tab1").hide(); //Hide all tab content
			var activeTab = $(this).find("a").attr("href"); //Find the rel attribute value to identify the active tab + content
			$(activeTab).fadeIn(); //Fade in the active content	
			return false;
	});
});

//tab End

$(document).ready(function() { 
			$('.ca_chat_area').hide();
			 $('.ca_chat_text').hide();
			 $('.ca_send_chat').hide();
			 $('#ca_close_chat').hide();
			 $('#ca_open_chat').show();
		
	$("#ca_close_chat").click(function(){
		var position	=	$('.cs_chat_box').position();
		var left =	position.left;
		if(left==0){
			$('.ca_chat_area').hide();
			 $('.ca_chat_text').hide();
			 $('.ca_send_chat').hide();
			 $('#ca_close_chat').hide();
			 $('#ca_open_chat').show();
		  $(".cs_chat_box").css('left', function(){ return $(this).offset().left; })
             .animate({"left":"-166px"}, "fast"); 
		}
		 else {
			$(".cs_chat_box").css('left', function(){ return $(this).offset().left; })
             .animate({"left":"0px"}, "fast"); 			  	 
			 $('.ca_chat_area').show();
			 $('.ca_chat_text').show();
			 $('.ca_send_chat').show();
			 
		 }
	});
	
	$('#ca_open_chat').click(function(){
		$(".cs_chat_box").css('left', function(){ return $(this).offset().left; })
             .animate({"left":"0px"}, "slow"); 			  	 
			 $('.ca_chat_area').show();
			 $('.ca_chat_text').show();
			 $('.ca_send_chat').show();
			 $('#ca_open_chat').hide();
			 $("#ca_close_chat").show();
	})
	
	
	$(".app_table").click(function(){
		var position	=	$('.cs_chat_box').position();
		var left =	position.left;
		if(left==0){
			$('.ca_chat_area').hide();
			 $('.ca_chat_text').hide();
			 $('.ca_send_chat').hide();
			 $('#ca_close_chat').hide();
			 $('#ca_open_chat').show();
		  $(".cs_chat_box").css('left', function(){ return $(this).offset().left; })
             .animate({"left":"-166px"}, "slow"); 
		}
		
	});
	});



//=========================Right Slide ========================
$(document).ready(function(){
	
   $("#ca_button1").click(function(){
    $(".content_1").slideToggle();
	$(".content_2").slideUp();
	$(".content_4").slideUp();
  });
  
   $("#ca_button2").click(function(){
		$(".content_2").slideToggle();
		$(".content_1").slideUp();
		$(".content_4").slideUp();
   }); 
   
    $("#ca_button4").click(function(){
		$(".content_4").slideToggle();
		$(".content_1").slideUp();
		$(".content_2").slideUp();
   });
   
   
   $('.ca_button3').click(function() {  
	  $(this).find('span').toggleClass('off');	   
   });
	
$('#ca_button4').click(function(){	
  	$(".open_tab1:nth-child(1)").show();	
});
 

});


$(document).ready(function(){
   $(".rc_slide_con").hide();
   $(".rc_bottom_btn li").click(function(){
	 $(this).find(".rc_slide_con").slideToggle();
   });
   
  $('html,body').click(function(){	  
	$(".rc_slide_con").hide();  
  });
  
  $( ".rc_slide_con, .rc_bottom_btn li" ).click(function( event ) {
	event.stopPropagation();
   });
 

});

$(document).ready(function(){
   $(".rc_board_open").hide();
   $(".discard_btn").click(function(){
	 $(".rc_board_open").slideToggle();
   });
   
   $('.ca_button4').on('click', function(){
	   $('.rc_board').toggleClass('openblock');	   
   });
   
  

});