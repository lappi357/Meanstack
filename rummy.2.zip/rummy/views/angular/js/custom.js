$(document).ready(function(){
$('#FMG_helpmask_img').hide();
  $('.rm_slide_gg').bxSlider({
     minSlides: 4,
     maxSlides: 2,
     slideWidth: 400,
     slideMargin: 10,
	 pager:false
	
  });
});


/*---popup overley start----*/
function showfmgOverlay()
{
	$('#FMG_helpmask_img').show();
}
function hidefmgOverlay()
{
	$('#FMG_helpmask_img').hide();
}
/*---popup overley End----*/


$(document).ready(function(){
/* $('.bxslider').bxSlider({
  auto: true,						
  pagerCustom: '#bx-pager'
  

});	 */
});	
						   
$(document).ready(function(){
/* $('.teenpatti_slider').bxSlider({
   auto: true,
   controls: true,
   pager:false
  
});	 */
});	

$(document).ready(function(){
/* $('.testimonial_slider').bxSlider({
   auto: true,
   controls: true,
   pager:false
  
});	 */
});	

$(document).ready(function () {
  $('.account_sub_menu').hide();
  $('.account_menu > li > a').mouseover(function(){
      $(this).next().slideToggle();
      $('.account_menu li a').removeClass('active');
      $(this).addClass('active');
  });
});

$(document).ready(function () {
  $('.rewardz_sub_list').hide();
  $('.rewardz_list_dropdown > li > a').click(function(){
      $(this).next().slideToggle();
      $('.rewardz_list_dropdown li a').removeClass('active');
      $(this).addClass('active');
  });
});

//tab start
jQuery(document).ready(function($) {	
	$(".open_tab1").hide(); 
	$(".tab_button ul li:first").addClass("cc_active").show();
	$(".open_tab1:first").show(); 	
		$(".tab_button ul li").click(function() {			
			$(".tab_button ul li").removeClass("cc_active"); //Remove any "active" class
			$(this).addClass("cc_active"); //Add "active" class to selected tab
			$(".open_tab1").hide(); //Hide all tab content
			var activeTab = $(this).find("a").attr("href"); //Find the rel attribute value to identify the active tab + content
			$(activeTab).fadeIn(); //Fade in the active content	
			return false;
	});
		
	$(".open_tab2").hide(); 
	$(".tab_button2 ul li:first").addClass("cc_active").show();
	$(".open_tab2:first").show(); 	
		$(".tab_button2 ul li").click(function() {			
			$(".tab_button2 ul li").removeClass("cc_active"); //Remove any "active" class
			$(this).addClass("cc_active"); //Add "active" class to selected tab
			$(".open_tab2").hide(); //Hide all tab content
			var activeTab = $(this).find("a").attr("href"); //Find the rel attribute value to identify the active tab + content
			$(activeTab).fadeIn(); //Fade in the active content	
			return false;
	});

});

$(document).ready(function(){
	$(".popover-examples li a").popover('hide');   

});

	

//tab End

/* added by vikas start */

	$(document).on('click','.my_account_list li',function(){
		$('.my_account_list li a').removeClass('activ');
		$(this).find('a').addClass('activ');
	});
	
	/*
	$(document).on('click','.logoutBtn',function(e){
		e.preventDefault();

		$.removeCookie("user");
		setTimeout(function(){
		  window.location = "/angular";
		}, 2000);
		

	});*/
	
	/* $(document).on('click','.account_menu li',function(){
		$('.account_menu li a').removeClass('activ');
		$(this).find('a').addClass('activ');
	});
	 */
	
	
/* added by vikas start */
