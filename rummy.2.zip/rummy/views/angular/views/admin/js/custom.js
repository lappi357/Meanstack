$(document).ready(function() {
	
		$(".del_rows").on('click',function(){		 
				 $(this).parents('tr').remove();
		});
	
		$(".show_ul").hide();
			$(".show").on('click',function(){
			$(".show_ul").slideUp();
			$('.show').removeClass("active");
			$(this).find(".show_ul").slideDown();		
				if($(this).find(".show_ul").is(':visible')){
					$(this).addClass("active");
				}else {
				$(this).removeClass("active");
				}			
		});
	
	  var winHeight = $(window).height();
		  $('#ti_menu').css('height',winHeight);
		  
		  $(window).resize(function(){
		  var winHeight = $(window).height();
		  $('#ti_menu').css('height',winHeight);
	  });
	
	$('#del_rows').click(function ()
		{
			$('.checkbox1:checked').parents('tr').remove();
	});
	
	
	if (Modernizr.touch) {
            // show the close overlay button
            $(".close-overlay").removeClass("hidden");
            // handle the adding of hover class when clicked
            $(".img").click(function(e){
                if (!$(this).hasClass("hover")) {
                    $(this).addClass("hover");
                }
            });
            // handle the closing of the overlay
            $(".close-overlay").click(function(e){
                e.preventDefault();
                e.stopPropagation();
                if ($(this).closest(".img").hasClass("hover")) {
                    $(this).closest(".img").removeClass("hover");
                }
            });
        } else {
            // handle the mouseenter functionality
            $(".img").mouseenter(function(){
                $(this).addClass("hover");
            })
            // handle the mouseleave functionality
            .mouseleave(function(){
                $(this).removeClass("hover");
            });
        }
	
	 $( "div[rel='scrollcontent2']" ).customscroll( { direction: "horizontal", bounce:0 } );
	 
	 
	 
	 // Range slider
	 

                var position = 10;

                $('.ui-slider')
                    .UISlider({
                        min: 1,
                        max: 100,
                        value: position
                    })
                    .on('change thumbmove', function (event, value) {

                        var targetPath = $(event.target).data('target');

                        $(targetPath).text(value);

                    })
                    .on('start', function () {

                        $('.value').addClass('editing');

                    })
                    .on('end', function () {

                        $('.value').removeClass('editing');

                    });

                $('.value').text(position);



	 
	 
	
	 
	
});





	
	  
	  
