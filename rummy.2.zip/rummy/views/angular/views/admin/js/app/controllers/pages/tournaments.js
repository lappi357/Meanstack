var apiUrl = 'http://mobirummy.com/api/';

pages.controller('tournamentController',['$http','$scope','$rootScope',function ($http,$scope, $rootScope){
	
	$('div li a').on('click',function() {
      $('div li.activ').removeClass('activ');
      $(this).closest('li').addClass('activ');
 	 });
	
	$scope.clubTournamentss = [];
	$scope.clubTournaments =  function(){
		$('.cashdata').hide();
		$('.specialdata').hide();
		$('.beginnersdata').hide();
		$('.clubData').show();
		$('.weekendloot').hide();
		$('.rewardData').hide();
		$('.jackpots').hide();
		var clubVal = $('#clubTournaments').attr('data-clickVal');
		$scope.clubVal = clubVal;
		$http.get(apiUrl+'tournament/getAllClubTournaments').success(function(data){
			if(data.data != null){
				$scope.clubTournamentss = data.data;
			}
						
		});
	}

	$scope.clubtournamentEdit =  function(id){
		
		$http.get(apiUrl+'tournament/getClubTournaments/'+id).success(function(data){
			if(data.data != null){
				$rootScope.tournament = data.data;
				$rootScope.tournament.tournamentName = data.data.tournamentName;			
				$rootScope.matchId = data.data.matchId;	
				$rootScope.allPrizeList	=JSON.parse(data.data.allPrizeList);
				var allPrizeList_length = $rootScope.allPrizeList
				var len = Object.keys(allPrizeList_length).length;
				$rootScope.totalLength = (len);
				$rootScope.tournament.tournamentType = $scope.clubVal;

				
			}
		});
	}


	$scope.clubtournamentDelete = function(clubtournament){
		if(confirm('Are You sure..')){
			$http.get(apiUrl+'tournament/deleteClubTournament/'+clubtournament._id).success(function(deleteClubTournamentData){
			if(deleteClubTournamentData.data != null){
				 $scope.clubTournaments.splice($scope.clubTournaments.indexOf(clubtournament), 1);
			}
		});
		}
	}

	$scope.cashTournaments = function(){
		$('.clubData').hide();
		$('.specialdata').hide();
		$('.cashdata').show();
		$('.beginnersdata').hide();
		$('.weekendloot').hide();
		$('.rewardData').hide();
		$('.jackpots').hide();
		 var cashVal = $('#cashTournaments').attr('data-clickVal');
		 $scope.cashVal = cashVal;
		 alert(cashVal);
		$http.get(apiUrl+'tournament/getAllCashTournaments').success(function(getAllCashdata){
			if(getAllCashdata != null){
				$scope.getAllCashdata = getAllCashdata.data;
			}else{
				$scope.getAllCashdata = "No Records Found" ;
			}
		});
	}

	$scope.cashtournamentEdit =  function(id){
		
		$http.get(apiUrl+'tournament/getCashTournaments/'+id).success(function(data){
			if(data.data != null){
				$rootScope.tournament = data.data;
				$rootScope.tournament.tournamentName = data.data.tournamentName;			
				$rootScope.matchId = data.data.matchId;	
				$rootScope.allPrizeList	=data.data.allPrizeList;
				$rootScope.allPrizeList_length = data.data.allPrizeList.length;	
				$rootScope.tournament.tournamentType = $scope.cashVal;
			}
		});
	}

	$scope.cashtournamentDelete = function(cashtournament){
		if(confirm('Are You sure..')){
			$http.get(apiUrl+'tournament/deleteCashTournament/'+cashtournament._id).success(function(deleteCashTournamentData){
			if(deleteCashTournamentData.data != null){
				 $scope.getAllCashdata.splice($scope.getAllCashdata.indexOf(cashtournament), 1);
			}
		});
		}
	}

	$scope.specialTournaments = function(){
		$('.clubData').hide();
		$('.specialdata').show();
		$('.cashdata').hide();
		$('.weekendloot').hide();
		$('.beginnersdata').hide();
		$('.rewardData').hide();
		$('.jackpots').hide();
		$http.get(apiUrl+'tournament/getAllSpecialTournament').success(function(getAllSpecialdata){
			if(getAllSpecialdata != null){
				$scope.getAllSpecialdata = getAllSpecialdata.data;
			}else{
				$scope.getAllSpecialdata = "No Records Found" ;
			}
		});
	}

	$scope.specialTournamentEdit = function(id){
		$http.get(apiUrl+'tournament/getSpecialTournaments/'+id).success(function(data){
			if(data.data != null){
				$rootScope.tournament = data.data;
				$rootScope.tournament.tournamentName = data.data.tournamentName;			
				$rootScope.matchId = data.data.matchId;			
			}
		});
	}


	$scope.specialTournamentDelete = function(specialTournament){
		if(confirm('Are You sure..')){
			$http.get(apiUrl+'tournament/deleteSpecialTournament/'+specialTournament._id).success(function(deletespecialTournamentData){
			if(deletespecialTournamentData.data != null){
				 $scope.getAllSpecialdata.splice($scope.getAllSpecialdata.indexOf(specialTournament), 1);
			}
		});
		}
	}


	$scope.beginnersTournaments = function(){
		$('.clubData').hide();
		$('.specialdata').hide();
		$('.cashdata').hide();
		$('.weekendloot').hide();
		$('.beginnersdata').show();
		$('.rewardData').hide();
		$('.jackpots').hide();
		$http.get(apiUrl+'tournament/getAllBeginnersTournament').success(function(getAllBeginnersdata){
			if(getAllBeginnersdata != null){
				$scope.getAllBeginnersdata = getAllBeginnersdata.data;
			}else{
				$scope.getAllBeginnersdata = "No Records Found" ;
			}
		});
	}

	$scope.BeginnersTournamentEdit = function(id){
		$http.get(apiUrl+'tournament/getBeginnersTournaments/'+id).success(function(data){
			if(data.data != null){
				$rootScope.tournament = data.data;
				$rootScope.tournament.tournamentName = data.data.tournamentName;			
				$rootScope.matchId = data.data.matchId;			
			}
		});
	}

	$scope.BeginnersTournamentDelete = function(BeginnersTournament){
		if(confirm('Are You sure..')){
			$http.get(apiUrl+'tournament/deleteBeginnersTournament/'+BeginnersTournament._id).success(function(deleteBeginnersTournamentData){
			if(deleteBeginnersTournamentData.data != null){
				 $scope.getAllBeginnersdata.splice($scope.getAllBeginnersdata.indexOf(BeginnersTournament), 1);
			}
		});
		}
	}

	$scope.weekendlootTournaments =  function(){
		$('.cashdata').hide();
		$('.specialdata').hide();
		$('.beginnersdata').hide();
		$('.clubData').hide();
		$('.weekendloot').show();
		$('.rewardData').hide();
		$('.jackpots').hide();
		$http.get(apiUrl+'tournament/getAllWeekendlootTournament').success(function(getAllWeekendlootData){
			if(getAllWeekendlootData.data != null){
				$scope.getAllWeekendlootData = getAllWeekendlootData.data;
			}
						
		});
	}

	$scope.WeekendlootDataEdit = function(id){
		$http.get(apiUrl+'tournament/getWeekendlootTournaments/'+id).success(function(data){
			if(data.data != null){
				$rootScope.tournament = data.data;
				$rootScope.tournament.tournamentName = data.data.tournamentName;			
				$rootScope.matchId = data.data.matchId;			
			}
		});
	}

	$scope.WeekendlootDataDelete = function(WeekendlootData){
		if(confirm('Are You sure..')){
			$http.get(apiUrl+'tournament/deleteWeekendlootTournament/'+WeekendlootData._id).success(function(deleteWeekendTournamentData){
			if(deleteWeekendTournamentData.data != null){
				 $scope.getAllWeekendlootData.splice($scope.getAllWeekendlootData.indexOf(WeekendlootData), 1);
			}
		});
		}
	}

	$scope.rewardpointsTournaments =  function(){
		$('.cashdata').hide();
		$('.specialdata').hide();
		$('.beginnersdata').hide();
		$('.clubData').hide();
		$('.weekendloot').hide();
		$('.rewardData').show();
		$('.jackpots').hide();
		$http.get(apiUrl+'tournament/getAllRewardpointsTournament').success(function(getAllRewardpointsData){
			if(getAllRewardpointsData.data != null){
				$scope.getAllRewardpointsData = getAllRewardpointsData.data;
			}	
		});
	}
	
	$scope.RewardpointsEdit = function(id){
		$http.get(apiUrl+'tournament/getRewardpointsTournaments/'+id).success(function(data){
			if(data.data != null){
				$rootScope.tournament = data.data;
				$rootScope.tournament.tournamentName = data.data.tournamentName;			
				$rootScope.matchId = data.data.matchId;			
			}
		});
	}

	$scope.RewardpointsDelete = function(Rewardpoints){
		if(confirm('Are You sure..')){
			$http.get(apiUrl+'tournament/deleteWeekendlootTournament/'+Rewardpoints._id).success(function(RewardpointsDeleteData){
			if(RewardpointsDeleteData.data != null){
				 $scope.getAllRewardpointsData.splice($scope.getAllRewardpointsData.indexOf(Rewardpoints), 1);
			}
		});
		}
	}

	$scope.jackpotsTournaments =  function(){
		$('.cashdata').hide();
		$('.specialdata').hide();
		$('.beginnersdata').hide();
		$('.clubData').hide();
		$('.weekendloot').hide();
		$('.rewardData').hide();
		$('.jackpots').show();
		$http.get(apiUrl+'tournament/getAllJackpotsTournament').success(function(getAllJackpotsData){
			if(getAllJackpotsData.data != null){
				$scope.getAllJackpotsData = getAllJackpotsData.data;
			}	
		});
	}

	$scope.getAllJackpotsEdit = function(id){
		$http.get(apiUrl+'tournament/getJackpotsTournaments/'+id).success(function(data){
			if(data.data != null){
				$rootScope.tournament = data.data;
				$rootScope.tournament.tournamentName = data.data.tournamentName;			
				$rootScope.matchId = data.data.matchId;			
			}
		});
	}

	$scope.getAllJackpotsDelete = function(getAllJackpots){
		if(confirm('Are You sure..')){
			$http.get(apiUrl+'tournament/deleteWeekendlootTournament/'+getAllJackpots._id).success(function(JackpotsDeleteData){
			if(JackpotsDeleteData.data != null){
				 $scope.getAllJackpotsData.splice($scope.getAllJackpotsData.indexOf(getAllJackpots), 1);
			}
		});
		}
	}

	$scope.updateTournaments = function(id){

		var prizeListPosition1 = $scope.tournament.prizeListPosition1;
		var prizeListPrize1 = $scope.tournament.prizeListPrize1;
		var prizeListRound1 = $scope.tournament.prizeListRound1;
		var prizeListPlayers1 = $scope.tournament.prizeListPlayers1;

		var loopCount = parseInt($('#upNoOfPrizeList123').val());

		var query='{';
	    for(var i = 0; i < loopCount; i++){
	      var prizeListPosition=$('#prizeListPosition'+i).val();
	      var prizeListPrize=$('#prizeListPrize'+i).val();
	      var prizeListRound=$('#prizeListRound'+i).val();
	      var prizeListPlayers=$('#prizeListPlayers'+i).val();
	      if(query=='{')
	      {
	        query +='"'+(i)+'":{"position":"'+prizeListPosition+'","prize":"'+prizeListPrize+'","round_no":"'+prizeListRound+'","players":"'+prizeListPlayers+'"}';
	      }
	      else
	      {
	        query +=',"'+(i)+'":{"position":"'+prizeListPosition+'","prize":"'+prizeListPrize+'","round_no":"'+prizeListRound+'","players":"'+prizeListPlayers+'"}';
	      }
	      

	    }
	    query +='}';

		/*var query = '{' ;
		 query +='"'+0+'":{"position":"'+prizeListPosition1+'","prize":"'+prizeListPrize1+'","round_no":"'+prizeListRound1+'","players":"'+prizeListPlayers1+'"}';
   	    query +='}';	*/
		
		var tournamentType = $('#tournamentType').val();
		if(tournamentType == 'clubTournaments')	{
			$http.put(apiUrl+'tournament/updateClubTournament', {tournamentId:id, tournamentName:$scope.tournament.tournamentName, matchId: $rootScope.matchId, entryFee: $scope.tournament.entryFee, maxPlayersPerTable: $scope.tournament.maxPlayersPerTable, maxRegistartions: $scope.tournament.maxRegistartions, registrationStart: $scope.tournament.registrationStart, registrationClose: $scope.tournament.registrationClose, tournamentStart: $scope.tournament.tournamentStart, estimatedDuration: $scope.tournament.estimatedDuration, prizeType: $scope.tournament.prizeType, totalRounds : $scope.tournament.totalRounds, currency: $scope.tournament.currency, allPrizeList: query }).success(function(clubData){
			 if(clubData.data!=null){
			 	console.log(clubData.data);
			 		var tournamentScope=angular.element('.clubClass').scope();
			 		tournamentScope.clubTournamentss.splice(tournamentScope.clubTournamentss.indexOf(clubData._id), 1);
			 		tournamentScope.clubTournamentss.push(clubData.data);
			 		if(!tournamentScope.$$phase){
					tournamentScope.$apply();
						
			 		}
			 	
                $scope.clubUpdatedRecord = 'Club Tournament Updated Successfully....';
              }
			});
		}else if(tournamentType == 'cashTournaments'){
			$http.put(apiUrl+'tournament/updateCashTournament', {tournamentId:id, tournamentName:$scope.tournament.tournamentName, matchId: $rootScope.matchId, entryFee: $scope.tournament.entryFee, maxPlayersPerTable: $scope.tournament.maxPlayersPerTable, maxRegistartions: $scope.tournament.maxRegistartions, registrationStart: $scope.tournament.registrationStart, registrationClose: $scope.tournament.registrationClose, tournamentStart: $scope.tournament.tournamentStart, estimatedDuration: $scope.tournament.estimatedDuration, prizeType: $scope.tournament.prizeType, totalRounds : $scope.tournament.totalRounds, currency: $scope.tournament.currency, allPrizeList: query }).success(function(cashData){
			 if(cashData.data!=null){

                $scope.clubUpdatedRecord = 'Cash Tournament Updated Successfully....';
              }
			});
		}else if(tournamentType == 'specialTournaments'){
			$http.put(apiUrl+'tournament/updateSpecialTournament', {tournamentId:id, tournamentName:$scope.tournament.tournamentName, matchId: $rootScope.matchId, entryFee: $scope.tournament.entryFee, maxPlayersPerTable: $scope.tournament.maxPlayersPerTable, maxRegistartions: $scope.tournament.maxRegistartions, registrationStart: $scope.tournament.registrationStart, registrationClose: $scope.tournament.registrationClose, tournamentStart: $scope.tournament.tournamentStart, estimatedDuration: $scope.tournament.estimatedDuration, prizeType: $scope.tournament.prizeType, totalRounds : $scope.tournament.totalRounds, currency: $scope.tournament.currency, allPrizeList: query }).success(function(clubData){
			 if(clubData.data!=null){
                $scope.clubUpdatedRecord = 'Special Tournament Updated Successfully....';
              }
			});
		}else if(tournamentType == 'beginnersTournaments'){
			$http.put(apiUrl+'tournament/updateBeginnersTournament', {tournamentId:id, tournamentName:$scope.tournament.tournamentName, matchId: $rootScope.matchId, entryFee: $scope.tournament.entryFee, maxPlayersPerTable: $scope.tournament.maxPlayersPerTable, maxRegistartions: $scope.tournament.maxRegistartions, registrationStart: $scope.tournament.registrationStart, registrationClose: $scope.tournament.registrationClose, tournamentStart: $scope.tournament.tournamentStart, estimatedDuration: $scope.tournament.estimatedDuration, prizeType: $scope.tournament.prizeType, totalRounds : $scope.tournament.totalRounds, currency: $scope.tournament.currency, allPrizeList: query }).success(function(clubData){
			 if(clubData.data!=null){
                $scope.clubUpdatedRecord = 'Beginners Tournament Updated Successfully....';
              }
			});
		}else if(tournamentType == 'weekendlootTournaments'){
			$http.put(apiUrl+'tournament/updateWeekendlootTournament', {tournamentId:id, tournamentName:$scope.tournament.tournamentName, matchId: $rootScope.matchId, entryFee: $scope.tournament.entryFee, maxPlayersPerTable: $scope.tournament.maxPlayersPerTable, maxRegistartions: $scope.tournament.maxRegistartions, registrationStart: $scope.tournament.registrationStart, registrationClose: $scope.tournament.registrationClose, tournamentStart: $scope.tournament.tournamentStart, estimatedDuration: $scope.tournament.estimatedDuration, prizeType: $scope.tournament.prizeType, totalRounds : $scope.tournament.totalRounds, currency: $scope.tournament.currency, allPrizeList: query }).success(function(clubData){
			 if(clubData.data!=null){
                $scope.clubUpdatedRecord = 'weekendloot Tournament Updated Successfully....';
              }
			});
		}else if(tournamentType == 'rewardpointsTournaments'){
			$http.put(apiUrl+'tournament/updateRewardpointsTournament', {tournamentId:id, tournamentName:$scope.tournament.tournamentName, matchId: $rootScope.matchId, entryFee: $scope.tournament.entryFee, maxPlayersPerTable: $scope.tournament.maxPlayersPerTable, maxRegistartions: $scope.tournament.maxRegistartions, registrationStart: $scope.tournament.registrationStart, registrationClose: $scope.tournament.registrationClose, tournamentStart: $scope.tournament.tournamentStart, estimatedDuration: $scope.tournament.estimatedDuration, prizeType: $scope.tournament.prizeType, totalRounds : $scope.tournament.totalRounds, currency: $scope.tournament.currency, allPrizeList: query }).success(function(clubData){
			 if(clubData.data!=null){
                $scope.clubUpdatedRecord = 'reward point Tournament Updated Successfully....';
              }
			});
		}else if(tournamentType == 'jackpotsTournaments'){
			$http.put(apiUrl+'tournament/updateJackpotsTournament', {tournamentId:id, tournamentName:$scope.tournament.tournamentName, matchId: $rootScope.matchId, entryFee: $scope.tournament.entryFee, maxPlayersPerTable: $scope.tournament.maxPlayersPerTable, maxRegistartions: $scope.tournament.maxRegistartions, registrationStart: $scope.tournament.registrationStart, registrationClose: $scope.tournament.registrationClose, tournamentStart: $scope.tournament.tournamentStart, estimatedDuration: $scope.tournament.estimatedDuration, prizeType: $scope.tournament.prizeType, totalRounds : $scope.tournament.totalRounds, currency: $scope.tournament.currency, allPrizeList: query }).success(function(clubData){
			 if(clubData.data!=null){
                $scope.clubUpdatedRecord = 'jackpots  Tournament Updated Successfully....';
              }
			});
		}		
	}




}]);