var apiUrl = 'http://mobirummy.com/api/';

pages.controller('withdrawrequestsCtrl',['$http','$scope','$rootScope',function ($http,$scope,$rootScope){

	$('ul li a').on('click',function() {
          $('ul li.activ').removeClass('activ');
          $(this).closest('li').addClass('activ');
       });
	
	$scope.echequedisApprovedRequests =  function(){
		$('#disapproved').show();
		$('#approved').hide();
		$('#disapprovedByAdmin').hide();
		$('#onlinePendingData').hide();
		$http.get(apiUrl+'wallet/getWithdrawlbyStsNType?wstatus=pending&withdrawType=echeque').success(function(disApprovedData){
			if(disApprovedData.data != null){
				$scope.disApprovedData = disApprovedData.data;
			}
		});
	}

	$scope.onlinedisApprovedRequests =  function(){
		$('#approved').hide();
		$('#disapproved').hide();
		$('#disapprovedByAdmin').hide();
		$('#onlinePendingData').show();
		$http.get(apiUrl+'wallet/getWithdrawlbyStsNType?wstatus=pending&withdrawType=Online').success(function(onlinedisApprovedData){
			if(onlinedisApprovedData.data != null){
				$scope.onlinedisApprovedDatas = onlinedisApprovedData.data;
				console.log($scope.onlinedisApprovedDatas);
			}
		});
	}

	$scope.disapprovedByAdmin =  function(){
		$('#disapprovedByAdmin').show();
		$('#approved').hide();
		$('#disapproved').hide();
		$('#onlinePendingData').hide();
		$http.get(apiUrl+'wallet/getDisApprovedReq',{status:'disapproved'}).success(function(admindisApprovedData){
			if(admindisApprovedData.data != null){
				$scope.admindisApprovedData = admindisApprovedData.data;
			}
		});
	}

	$scope.approveRequest = function(id){
		$http.put(apiUrl+'wallet/changeWithdrawReqSts',{wdReqId:id, wdstatus:'approved'}).success(function(data){
			if(data.data != null){
				if(data.data.withdrawType == 'echeque'){
					$scope.disApprovedData.splice($scope.disApprovedData.indexOf(id), 1);	
				}else if(data.data.withdrawType == 'Online'){
					$scope.onlinedisApprovedDatas.splice($scope.onlinedisApprovedDatas.indexOf(id), 1);	
				}
				
			}
			//console.log(data);
			
		});
	}

	$scope.makedisapproveRequest = function(id){
		$http.put(apiUrl+'wallet/changeWithdrawReqSts',{wdReqId:id, wdstatus:'disapproved'}).success(function(data){
			if(data.data != null){
				$scope.ApprovedData.splice($scope.ApprovedData.indexOf(id), 1);
			}
			console.log(data);
		});
	}

	$scope.approvedRequests =  function(){

			$('#approved').show();
			$('#disapproved').hide();
			$('#disapprovedByAdmin').hide();
			$('#onlinePendingData').hide();
			$http.get(apiUrl+'wallet/getApprovedReq',{status:'approved'}).success(function(ApprovedData){
				if(ApprovedData.data != null){
					$scope.ApprovedData = ApprovedData.data;
			}
		});
	}

}]);
