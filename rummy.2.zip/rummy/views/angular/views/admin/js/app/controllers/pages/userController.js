var apiUrl = 'http://mobirummy.com/api/';
var pages = angular.module('pages',[]);
pages.controller('userController',['$http','$scope','$rootScope', function ($http,$scope,$rootScope){
       $scope.allUsers = [];
       $scope.auser = [];

       $scope.pageSize = 5;
       $scope.currentPage = 1;

	/* Get all the users */
		
       $http.get(apiUrl+'admin/user/getAllUsers').success(function(data){
	       	if(data.data!=null){
	       		$scope.allUsers = data.data;
	       	}

       });

       $scope.getAllSavedUser = function(){
       		$http.get(apiUrl+'admin/user/getAllUsers').success(function(data){
		       	if(data.data!=null){
		       		$scope.allUsers = data.data;
		       	}
       		});
       }

    $scope.getContact = function(contact){
       $rootScope.contact = contact;
    }

    $scope.sendMessage =  function(){
       var textmessage = $scope.textmessage;
       var smsContact = $rootScope.contact;
       $http.post('http://mobirummy.com/sendMessage',{to:smsContact,textmessage:textmessage}).success(function(data){
              if(data.success == 1){
                     $('#myModal').hide();
                     $('#textmessage').val('');
                     alert('Message Sent Successfully..');
              }else if(data.success == 0){
                     $('#myModal').hide();
                     alert('Message did not sent..');
              }
       });
    }

       /* Add new User */

       $scope.addNewUser = function(){
       		var registervalidationFlag=true;
			$scope.registervalidateMessage='';
                     
                     console.log($scope.auser.firstname);
			
			$http.post(apiUrl+'user/addNewUser', {firstname:$scope.auser.firstname, username: $scope.auser.username, userEmail:$scope.auser.userEmail, userPass: $scope.auser.userPass, dob:$scope.auser.signup_dob,gender: $scope.auser.userGender,contact:$scope.auser.contact }).success(function(data){
					$scope.allUsers.push({firstname:$scope.auser.firstname, username: $scope.auser.username, email:$scope.auser.userEmail, userPass: $scope.auser.userPass, dob:$scope.auser.signup_dob,gender: $scope.auser.userGender,contact:$scope.auser.contact });
					$scope.registervalidateMessage = "User Saved Successfully....";
					$scope.auser = {};
			});
			
       }

       $scope.deleteUser =  function(users){
       		if(confirm('Are You Sure')){
       			$http.get(apiUrl+'admin/user/deleteUser/'+users._id).success(function(deleteData){
       				if(deleteData.data != null){
       					$scope.allUsers.splice($scope.allUsers.indexOf(users), 1);
       					$scope.usreDeletionMsg='User Deleted Successfully....';
       				}
       			});
       		}      	
       
       }

       $scope.editUser = function(id){
                      console.log(id);
       		$('#userAddFrom').hide();
       		$('#userEditForm').show();
       		$http.get(apiUrl+'admin/user/getUserById/'+id).success(function(data){
                            if(data.data != null){
                                   $scope.user = data.data;
                                   $scope.user.userEmail = data.data.email;
                                   $scope.user.userGender = data.data.gender; 

                            }
       			
       		});
       }

       $scope.updateUser = function(id){
       		$http.put(apiUrl+'admin/user/updateUserInfo/'+id, {userEmail:$scope.user.userEmail, username: $scope.user.username, firstname: $scope.user.firstname, dob:$scope.user.dob, gender:$scope.user.gender,contact:$scope.user.contact }).success(function(data){
       			if(data.data!=null){
                                   var userScope=angular.element('.tableUsers').scope();
                                   userScope.allUsers.splice(userScope.allUsers.indexOf(data._id), 1);
                                   userScope.allUsers.push(data.data);
                                   if(!userScope.$$phase){
                                      userScope.$apply();                                      
                                   }
       				$scope.userUpdatedRecord = 'User Updated Successfully....';
                                   $scope.user = {};
                                   $scope.user.userEmail = '';
                                   $scope.user.userGender = ''; 
                                   $('#userEditForm').hide();
                                   $('#userAddFrom').show();
       			}
       		});
       }

		
}]);