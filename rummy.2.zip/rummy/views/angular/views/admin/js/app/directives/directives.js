var auth    =   angular.module('Directives', ['DirectiveControllers']);




auth.directive('header', function() {
  return {
      
    templateUrl: '../../../views/admin/views/header.html',
   // controller:'AuthCtrl'
	  
  };
});

auth.directive('leftmenu', function() {
  return {
      
    templateUrl: '../../../views/admin/views/left_menu.html',
    controller:'menuCtrl'
    
  };
});

auth.directive('twentyonecard', function() {
  return {
      
    templateUrl: '../../../views/admin/views/21cardTournament.html',
    controller:'tournamentController'
    
  };
});

auth.directive('thirteencarddealrummy', function() {
  return {
      
    templateUrl: '../../../views/admin/views/13cardDealRummy.html',
    controller:'tableController'
    
  };
});





