var base_uri = 'http://mobirummy.com/admin';
var drc    =   angular.module('DirectiveControllers',[]);

drc.controller('menuCtrl',['$http','$scope',function ($http,$scope){

     

	
}]);