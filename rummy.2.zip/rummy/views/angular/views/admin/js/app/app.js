var adminUser = $.cookie('adminUser');
var adminUrl = 'http://mobirummy.com/';
var apiUrl = 'http://mobirummy.com/';
var adminApp = angular.module('adminApp',['ngRoute','ui.bootstrap','angularUtils.directives.dirPagination', 'Directives','pages'])
.config(['$routeProvider','$locationProvider',
  function($routeProvider,$locationProvider) {
	if($.cookie('adminUser')){
		var default_page='../../views/admin/views/dashboard.html';
		var default_ctrl='dashCtrl'
		
	}else{
		var default_page='../../views/admin/views/login.html';
		var default_ctrl='loginCtrl'
	}
 //  $locationProvider
//.html5Mode(true);
    $routeProvider.
	when('/admin/', {
        templateUrl: default_page,
		controller :default_ctrl
	}).
	when('/admin/#/dashboard/', {
        templateUrl: '../../views/admin/views/dashboard.html',
		controller :'dashCtrl'
	}).
	when('/admin/users', {
        templateUrl: '../../views/admin/views/getUserList.html',
		controller :'userController'
	}).
	when('/admin/addTable', {
        templateUrl: '../../views/admin/views/addTable.html',
		controller :'tableController'
	}).
	when('/admin/tournaments', {
        templateUrl: '../../views/admin/views/getAllTournaments.html',
		controller :'tournamentController'
	}).
	when('/admin/withdrawrequests', {
        templateUrl: '../../views/admin/views/withdrawrequests.html',
		controller :'withdrawrequestsCtrl'
	}).
	otherwise({
		templateUrl: '../../views/'+default_page,
		controller :default_ctrl
	});
	 
      $locationProvider.html5Mode(true); 
  }])
.filter('startFrom', function(){
	return function(data, start){
		return data.slice(start);
	}
});





adminApp.controller('dashCtrl', function($scope, $http) {
    	console.log('DashboardCtrl');
});

adminApp.controller('logoutCtrl', function($scope, $http) {
	$scope.adminLogout = function(){
		var remove_status=$.removeCookie('adminUser');
		
		if(!remove_status)
		{
			
			$.cookie('adminUser','');
		}

		location.href=adminUrl+'admin/';
	}
    	
});

adminApp.controller('loginCtrl', function($scope, $http, $location, $rootScope) {
    	$scope.adminLogin = function(){
    		var validationFlag=true;
			$scope.validateMessage='';
			if(!$scope.username){
				$scope.validateMessage="Please enter user email.!\n";
				validationFlag=false;
			}else if(!$scope.password){
				$scope.validateMessage ="Please enter user password.!";
				validationFlag=false;
			}
			if(validationFlag){
				var username = $scope.username;
	    		var password = $scope.password;
	    		$http.get(apiUrl+'admin/login/'+username+'/'+password).success(function(data){
	    			if(data.data!=null){
	    				$.cookie("adminUser", data.data, { expires: 7 });	
						location.href=adminUrl+'admin/';
	    			}else{
	    				$scope.validateMessage ='Invalid Email Id Or Password';
	    				$scope.username = "";
	    				$scope.password = "";	
	    			}
	    			
	    		});	
			}
    		
    	}
});

 
 var checkRouting= function ($q, $rootScope, $location) {
    if (adminUser) {
        return true;
    } else {
		 $location.path("/");
       
    }
};
 