var apiUrl = 'http://mobirummy.com/api/';
socket = io.connect('http://mobirummy.com/');
pages.controller('tableController',['$http','$scope','$rootScope',function ($http,$scope,$rootScope){

       $scope.pageSize = 10;
       $scope.currentPage = 1;
       
       $('ul li a').on('click',function() {
          $('ul li.activ').removeClass('activ');
          $(this).closest('li').addClass('activ');
       });
       
       $scope.addTable = function(){
              var tableValidationFlag=true;
              $scope.tableValidateMessage='';
              $scope.table;
              if($scope.table.matchFormatId == 1){
                    if(!$scope.table.tableName){
                            $scope.tableValidateMessage="Please enter match table name"; 
                             tableValidationFlag = false;
                     }else if(!$scope.table.pointValue){
                           $scope.tableValidateMessage="Please enter match point value"; 
                           tableValidationFlag = false;
                     }else if(!$scope.table.entryFee){
                           $scope.tableValidateMessage="Please enter match entry fee"; 
                           tableValidationFlag = false;
                     }else if(!$scope.table.maxPlayers){
                           $scope.tableValidateMessage="Please enter numbre of match players"; 
                           tableValidationFlag = false;
                     }else if(!$scope.table.matchMethod){
                            $scope.tableValidateMessage="Please select match method"; 
                            tableValidationFlag = false;
                     } 
              }
              if($scope.table.matchFormatId == 2){
                     if(!$scope.table.tableName){
                            $scope.tableValidateMessage="Please enter match table name"; 
                             tableValidationFlag = false;
                     }else if(!$scope.table.pointValue){
                           $scope.tableValidateMessage="Please enter match point value"; 
                           tableValidationFlag = false;
                     }else if(!$scope.table.poolType){
                           $scope.tableValidateMessage="Please enter match pool type"; 
                            tableValidationFlag = false;
                     }else if(!$scope.table.entryFee){
                           $scope.tableValidateMessage="Please enter match entry fee"; 
                           tableValidationFlag = false;
                     }else if(!$scope.table.prize){
                           $scope.tableValidateMessage="Please enter match prize"; 
                           tableValidationFlag = false;
                     }else if(!$scope.table.maxPlayers){
                           $scope.tableValidateMessage="Please enter numbre of match players"; 
                           tableValidationFlag = false;
                     }else if(!$scope.table.matchMethod){
                            $scope.tableValidateMessage="Please select match method"; 
                            tableValidationFlag = false;
                     }
              }
              if($scope.table.matchFormatId == 3){
                     if(!$scope.table.tableName){
                            $scope.tableValidateMessage="Please enter your table name"; 
                            tableValidationFlag = false;
                     }else if(!$scope.table.entryFee){
                           $scope.tableValidateMessage="Please enter match entry fee"; 
                           tableValidationFlag = false;
                     }else if(!$scope.table.deals){
                           $scope.tableValidateMessage="Please enter match deals"; 
                           tableValidationFlag = false;
                     }else if(!$scope.table.prize){
                           $scope.tableValidateMessage="Please enter match prize"; 
                           tableValidationFlag = false;
                     }else if(!$scope.table.maxPlayers){
                           $scope.tableValidateMessage="Please enter numbre of match players"; 
                           tableValidationFlag = false;
                     }else if(!$scope.table.matchMethod){
                            $scope.tableValidateMessage="Please select match method"; 
                            tableValidationFlag = false;
                     }
              }

              if($scope.table.matchFormatId == 4){
                     if(!$scope.table.tableName){
                            $scope.tableValidateMessage="Please enter your table name"; 
                            tableValidationFlag = false;
                     }else if(!$scope.table.pointValue){
                           $scope.tableValidateMessage="Please enter match point value"; 
                           tableValidationFlag = false;
                     }else if(!$scope.table.entryFee){
                           $scope.tableValidateMessage="Please enter match entry fee"; 
                           tableValidationFlag = false;
                     }else if(!$scope.table.maxPlayers){
                           $scope.tableValidateMessage="Please enter numbre of match players"; 
                           tableValidationFlag = false;
                     }else if(!$scope.table.matchMethod){
                            $scope.tableValidateMessage="Please select match method"; 
                            tableValidationFlag = false;
                     }
              }
              if(tableValidationFlag){
                   $http.post(apiUrl+'table/addTable',{matchFormatId:$scope.table.matchFormatId,tableName:$scope.table.tableName,decks:$scope.table.decks,pointValue:$scope.table.pointValue,entryFee:$scope.table.entryFee,poolType:$scope.table.poolType,prize:$scope.table.prize,deals:$scope.table.deals,maxPlayers:$scope.table.maxPlayers,matchMethod:$scope.table.matchMethod}).success(function(tableData){
                            $scope.table.tableName = "";
                            $scope.table.decks= "";
                            $scope.table.pointValue = "";
                            $scope.table.entryFee ="";
                            $scope.table.poolType ="";
                            $scope.table.prize ="";
                            $scope.table.deals ="";
                            $scope.table.maxPlayers ="";
                            $scope.table.matchMethod ="";
                            $scope.tableValidateMessage = "Table Added Successfully";

                     });  
              }
              
       }

       $(document).on('change', '#matchFormatId', function(){
              var matchFormatId = $('#matchFormatId').val();
              if(matchFormatId == 1){
                     $('#listAll').show();
                     $('#decksDiv').hide();
                     $('#poolTypeDiv').hide();
                     $('#dealsDiv').hide();
                     $('#prizeDiv').hide();
                     $('#decksDiv').show();
                     $('#tableNameDiv').show();
                     $('#pointValueDiv').show();
                     $('#entryFeeDiv').show();
                     $('#maxPlayersDiv').show();
              }else if(matchFormatId == 2){
                     $('#listAll').show();
                     $('#decksDiv').hide();
                     $('#dealsDiv').hide();
                      $('#tableNameDiv').show();
                     $('#pointValueDiv').show();
                     $('#poolTypeDiv').show();
                     $('#prizeDiv').show();
                     $('#entryFeeDiv').show();
                     $('#maxPlayersDiv').show();
              }else if(matchFormatId == 3){
                     $('#listAll').show();
                     $('#decksDiv').hide();
                     $('#poolTypeDiv').hide();
                     $('#pointValueDiv').hide();
                      $('#tableNameDiv').show();
                      $('#prizeDiv').show();
                      $('#dealsDiv').show();
                     $('#entryFeeDiv').show();
                     $('#maxPlayersDiv').show();
              }else if(matchFormatId == 4){
                     $('#listAll').show();
                     $('#decksDiv').hide();
                     $('#poolTypeDiv').hide();
                     $('#prizeDiv').hide();
                      $('#dealsDiv').hide();
                      $('#pointValueDiv').show();
                      $('#tableNameDiv').show();
                      $('#entryFeeDiv').show();
                     $('#maxPlayersDiv').show();
              }else if(matchFormatId == ''){
                     $('#listAll').hide();                    
              }
       } )
       


       $('#oneCard').on('click',function(){
              $('#firstDiv').show();
              $('#secondDiv').hide();
              $('#thirdDiv').hide();
              $('#fourthDiv').hide();
       });
        $('#twoCard').on('click',function(){
              $('#firstDiv').hide();
              $('#secondDiv').show();
              $('#thirdDiv').hide();
              $('#fourthDiv').hide();
       });
         $('#threeCard').on('click',function(){
              $('#firstDiv').hide();
              $('#secondDiv').hide();
              $('#thirdDiv').show();
              $('#fourthDiv').hide();
       });
       $('#fourCard').on('click',function(){
              $('#firstDiv').hide();
              $('#secondDiv').hide();
              $('#thirdDiv').hide();
              $('#fourthDiv').show();
       });



       $scope.oneCards = function(){
       
              $http.get(apiUrl+'table/admingetTblsByMtchFrmtId?matchFormatId=1').success(function(oneCardData){
                
                 console.log(oneCardData);
                     if(oneCardData.data!=null){
                            $scope.oneCardDatas = oneCardData.data;
                     }
              });
       }

      socket.on('addTable', function(data){
        if(data.action == 1){
          $('#oneCard').trigger('click');
        }
        if(data.action == 2){
          $('#twoCards').trigger('click'); 
        }
        if(data.action == 3){
          $('#threeCard').trigger('click'); 
        }
      });
      
      socket.on('listGame', function(data){
        if(data.action == 1){
          $scope.oneCardDatas = data.result;
          $scope.$apply();
        }
        if(data.action == 2){
          $scope.twoCardDatas = data.result;
          $scope.$apply();
        }
        if(data.action == 3){
          $scope.threeCardDatas = data.result;
          $scope.$apply();
        }
      });

       $scope.twoCards = function(){
              $http.get(apiUrl+'table/admingetTblsByMtchFrmtId?matchFormatId=2').success(function(twoCardData){
                     if(twoCardData.data!=null){
                            $scope.twoCardDatas = twoCardData.data;
                     }
              });      
       }

       $scope.threeCards = function(){
              $http.get(apiUrl+'table/admingetTblsByMtchFrmtId?matchFormatId=3').success(function(threeCardData){
                     if(threeCardData.data!=null){
                            $scope.threeCardDatas = threeCardData.data;
                     }
              });      
       }

       $scope.fourCards = function(){
              $http.get(apiUrl+'table/getTblsByMtchFrmtId?matchFormatId=4').success(function(fourCardData){
                     if(fourCardData.data!=null){
                            $scope.fourCardDatas = fourCardData.data;
                     }
              });      
       }

       /* Function for deleting the table for 13 cards points rummy */
       $scope.oneCardDelete = function(oneCardData){
              if(confirm('Are you sure')){
                     $http.get(apiUrl+'table/deleteTable/'+oneCardData._id).success(function(oneCardDeleteData){
                             if(oneCardDeleteData.data!=null){
                                   $scope.oneCardDatas.splice($scope.oneCardDatas.indexOf(oneCardData), 1);
                            }
                     });
              }
              
       }

       /* Function for editing the table for 13 cards points rummy */

       $scope.oneCardEdit = function(id){
              $('#addTable').css('display', 'none');
              $('#updateTable').css('display', 'block');
              $('#dealsDivUpdate').css('display', 'none');
              $('#prizeDivUpdate').css('display', 'none');
              $('#poolTypeDivUpdate').css('display', 'none');
              $http.get(apiUrl+'table/editTable/'+id).success(function(oneCardEditData){
                      if(oneCardEditData.data!=null){
                            $scope.table = oneCardEditData.data;
                     }
               });
      }

      /* Function for updating the table for 13 cards points rummy */

      $scope.updateTable = function(id){
              $http.put(apiUrl+'table/updateTable/'+id,{tableName:$scope.table.tableName,decks:$scope.table.decks, pointValue:$scope.table.pointValue, entryFee: $scope.table.entryFee, poolType:$scope.table.poolType, prize: $scope.table.prize, deals: $scope.table.deals,  maxPlayers: $scope.table.maxPlayers, matchMethod: $scope.table.matchMethod }).success(function(oneupdateTableData){
                      if(oneupdateTableData.data!=null){
                            $scope.tableUpdatedRecord = 'Table Updated Successfully....';
                             $('#updateTable').hide();
                            $('#addTable').show();
                            $scope.table = {};
                      }
               });
      }

      /* Function for deleting the pool rummuy data by Raghvendra singh */
      $scope.twoCardDelete = function(twoCardData){
               if(confirm('Are you sure')){
                     $http.get(apiUrl+'table/deleteTable/'+twoCardData._id).success(function(twoCardDeleteData){
                             if(twoCardDeleteData.data!=null){
                                   $scope.twoCardDatas.splice($scope.twoCardDatas.indexOf(twoCardData), 1);
                            }
                     });
              }
      }
      /* Function for edit the pool rummy data by raghvendra singh */

      $scope.twoCardEdit =  function(id){
              $('#addTable').css('display', 'none');
              $('#updateTable').css('display', 'block');
              $('#dealsDivUpdate').css('display', 'none');
              $('#decksDivUpdate').css('display', 'none');
              $http.get(apiUrl+'table/editTable/'+id).success(function(twoCardEditData){
                      if(twoCardEditData.data!=null){
                            $scope.table = twoCardEditData.data;
                     }
               });
      }
      /* Function for updating the deals rummy record by Raghvendra singh */
      $scope.deletethird = function(threeCardData){
              if(confirm('Are you sure')){
                     $http.get(apiUrl+'table/deleteTable/'+threeCardData._id).success(function(threeCardDeleteData){
                             if(threeCardDeleteData.data!=null){
                                   $scope.threeCardDatas.splice($scope.threeCardDatas.indexOf(threeCardData), 1);
                            }
                     });
              }
      }

      /* Function for editing the deals rummy data by Raghvendra singh */

      $scope.thirdCardEdit = function(id){
              $('#addTable').css('display', 'none');
              $('#updateTable').css('display', 'block');
              $('#dealsDivUpdate').css('display', 'block');
              $('#decksDivUpdate').css('display', 'none');
              $('#pointValueDiv').css('display', 'none');
              $('#poolTypeDivUpdate').css('display', 'none');
              $http.get(apiUrl+'table/editTable/'+id).success(function(threeCardEditData){
                      if(threeCardEditData.data!=null){
                            $scope.table = threeCardEditData.data;
                     }
               });
      }
      

       /* Function for deleting  the 21 card rummy record by Raghvendra singh */
      $scope.deleteFourth = function(fourCardData){
              if(confirm('Are you sure')){
                     $http.get(apiUrl+'table/deleteTable/'+fourCardData._id).success(function(fourCardDeleteData){
                             if(fourCardDeleteData.data!=null){
                             $scope.fourCardDatas.splice($scope.fourCardDatas.indexOf(fourCardData), 1);
                            }
                     });
              }
      }

      /* Function for editing the 21 card rummy data by Raghvendra singh */

      $scope.fourthCardEdit = function(id){
              $('#addTable').css('display', 'none');
              $('#updateTable').css('display', 'block');
              $('#dealsDivUpdate').css('display', 'none');
              $('#decksDivUpdate').css('display', 'none');
              $('#poolTypeDivUpdate').css('display', 'none');
              $('#prizeDivUpdate').css('display', 'none');
              $http.get(apiUrl+'table/editTable/'+id).success(function(fourthCardEditData){
                      if(fourthCardEditData.data!=null){
                            $scope.table = fourthCardEditData.data;
                     }
               });
      }

  /*  $('#thirteenCardDeal').on('click', function(){
      alert(1);
    var matchId = $('#thirteenCardDeal').attr('data-matchId');
    var matchId = angular.element(item).data('matchId');
    //alert(matchId);
    $rootScope.matchId = matchId;
    
  });*/
    $scope.getDealId = function(id){
      var matchId = id;
       $rootScope.matchId = matchId;

    }

  
  $scope.addMore = function()
  {
    console.log('add more field');
   $scope.tournament;
    var i=$('#NoOfPrizeList1').val();
    
    var newNumber=parseInt(i)+1;
    
    $('#prizeListDiv1').append('<div class="row"><div class="col-sm-6 col-md-6"><div class="input_block1"><div class="row"><div class="form-group"><label>Prize List'+newNumber+'</label><input class="span12 form-control" type="text" id="prizeListPosition'+newNumber+'" ng-model="tournament.prizeListPosition'+newNumber+'" placeholder="" /></div></div><div  class="row"><div class="form-group"><label>Rounds '+newNumber+' </label><input class="span12 form-control" type="text" id="prizeListRound'+newNumber+'" ng-model="tournament.prizeListRound'+newNumber+' " placeholder="" /></div></div></div></div><div class="col-sm-6 col-md-6"><div class="input_block2"><div class="row"><div class="form-group"><label>Prize'+newNumber+'</label><input class="span12 form-control" type="text" id="prizeListPrize'+newNumber+'" ng-model="tournament.prizeListPrize'+newNumber+'" placeholder="" /></div></div><div class="row"><div class="form-group"><label>Players'+newNumber+'</label><input class="span12 form-control" type="text" id="prizeListPlayers'+newNumber+'" ng-model="tournament.prizeListPlayers'+newNumber+'" placeholder="" /></div></div></div></div></div>');

      $('#NoOfPrizeList1').val(newNumber);
  }


  $scope.addTournament = function(){


     $scope.tournament; 
    var loopVal=parseInt($('#NoOfPrizeList1').val());
    var query='{';
    for(var i = 1; i <= loopVal; i++){
      var prizeListPosition=$('#prizeListPosition'+i).val();
      var prizeListPrize=$('#prizeListPrize'+i).val();
      var prizeListRound=$('#prizeListRound'+i).val();
      var prizeListPlayers=$('#prizeListPlayers'+i).val();
      if(query=='{')
      {
        query +='"'+(i-1)+'":{"position":"'+prizeListPosition+'","prize":"'+prizeListPrize+'","round_no":"'+prizeListRound+'","players":"'+prizeListPlayers+'"}';
      }
      else
      {
        query +=',"'+(i-1)+'":{"position":"'+prizeListPosition+'","prize":"'+prizeListPrize+'","round_no":"'+prizeListRound+'","players":"'+prizeListPlayers+'"}';
      }
      

    }
    query +='}';
    
    var tournamentType = $('#tournamentType').val();
    var registrationStart = $('#registrationStart').val();
    var registrationClose = $('#registrationClose').val();
    var tournamentStart = $('#tournamentStart').val();

    if(tournamentType == 'cashTournaments'){
      $http.post(apiUrl+'tournament/addCashTournament', {'tournamentName': $scope.tournament.tournamentName, 'matchId': $rootScope.matchId, 'entryFee': $scope.tournament.entryFee, 'maxPlayersPerTable':$scope.tournament.maxPlayersPerTable,'maxRegistartions':$scope.tournament.maxRegistartions, 'registrationStart':registrationStart,'registrationClose': registrationClose, 'tournamentStart': tournamentStart , 'estimatedDuration': $scope.tournament.estimatedDuration, 'prizeType':$scope.tournament.prizeType, 'totalRounds': $scope.tournament.totalRounds, 'currency': $scope.tournament.currency,allPrizeList:query }).success(function(data){
        alert(data);
        console.log(data);
        if(data.success == 1 ){
          $scope.tournamentMsg = 'Tournament Saved Successfully...';
          $scope.tournament = {}; 
          $('#registrationStart').val('');
          $('#registrationClose').val('');
          $('#tournamentStart').val('');
        }else{
          $scope.tournamentMsg = 'Error while saving the data....';
        }
        
      });
    }else if(tournamentType == 'specialTournaments'){
      
      $http.post(apiUrl+'tournament/addspecialTournament', {'tournamentName': $scope.tournament.tournamentName, 'matchId': $rootScope.matchId, 'entryFee': $scope.tournament.entryFee, 'maxPlayersPerTable':$scope.tournament.maxPlayersPerTable,'maxRegistartions':$scope.tournament.maxRegistartions, 'registrationStart':registrationStart,'registrationClose': registrationClose, 'tournamentStart':tournamentStart , 'estimatedDuration': $scope.tournament.estimatedDuration, 'prizeType':$scope.tournament.prizeType, 'totalRounds': $scope.tournament.totalRounds, 'currency': $scope.tournament.currency,allPrizeList:query }).success(function(data){
        console.log(data);
        if(data.success == 1 ){
          $scope.tournamentMsg = 'Tournament Saved Successfully...';
          $scope.tournament = {}; 
           $('#registrationStart').val('');
          $('#registrationClose').val('');
          $('#tournamentStart').val('');
        }else{
          $scope.tournamentMsg = 'Error while saving the data....';
        }
        
      });
    }else if(tournamentType == 'beginnersTournaments'){
      
      $http.post(apiUrl+'tournament/addbeginnersTournament', {'tournamentName': $scope.tournament.tournamentName, 'matchId': $rootScope.matchId, 'entryFee': $scope.tournament.entryFee, 'maxPlayersPerTable':$scope.tournament.maxPlayersPerTable,'maxRegistartions':$scope.tournament.maxRegistartions, 'registrationStart':registrationStart,'registrationClose': registrationClose, 'tournamentStart': tournamentStart , 'estimatedDuration': $scope.tournament.estimatedDuration, 'prizeType':$scope.tournament.prizeType, 'totalRounds': $scope.tournament.totalRounds, 'currency': $scope.tournament.currency,allPrizeList:query }).success(function(data){
        console.log(data);
        if(data.success == 1 ){
          $scope.tournamentMsg = 'Tournament Saved Successfully...';
          $scope.tournament = {}; 
           $('#registrationStart').val('');
          $('#registrationClose').val('');
          $('#tournamentStart').val('');
        }else{
          $scope.tournamentMsg = 'Error while saving the data....';
        }
        
      });
    }else if(tournamentType == 'weekendlootTournaments'){
      
      $http.post(apiUrl+'tournament/addweekendlootTournament', {'tournamentName': $scope.tournament.tournamentName, 'matchId': $rootScope.matchId, 'entryFee': $scope.tournament.entryFee, 'maxPlayersPerTable':$scope.tournament.maxPlayersPerTable,'maxRegistartions':$scope.tournament.maxRegistartions, 'registrationStart':registrationStart,'registrationClose': registrationClose, 'tournamentStart': tournamentStart , 'estimatedDuration': $scope.tournament.estimatedDuration, 'prizeType':$scope.tournament.prizeType, 'totalRounds': $scope.tournament.totalRounds, 'currency': $scope.tournament.currency,allPrizeList:query }).success(function(data){
        console.log(data);
        if(data.success == 1 ){
          $scope.tournamentMsg = 'Tournament Saved Successfully...';
          $scope.tournament = {}; 
           $('#registrationStart').val('');
          $('#registrationClose').val('');
          $('#tournamentStart').val('');
        }else{
          $scope.tournamentMsg = 'Error while saving the data....';
        }
        
      });
    }else if(tournamentType == 'rewardpointsTournaments'){
      
      $http.post(apiUrl+'tournament/addrewardpointsTournament', {'tournamentName': $scope.tournament.tournamentName, 'matchId': $rootScope.matchId, 'entryFee': $scope.tournament.entryFee, 'maxPlayersPerTable':$scope.tournament.maxPlayersPerTable,'maxRegistartions':$scope.tournament.maxRegistartions, 'registrationStart': registrationStart,'registrationClose':registrationClose, 'tournamentStart': tournamentStart , 'estimatedDuration': $scope.tournament.estimatedDuration, 'prizeType':$scope.tournament.prizeType, 'totalRounds': $scope.tournament.totalRounds, 'currency': $scope.tournament.currency,allPrizeList:query }).success(function(data){
        console.log(data);
        if(data.success == 1 ){
          $scope.tournamentMsg = 'Tournament Saved Successfully...';
          $scope.tournament = {}; 
           $('#registrationStart').val('');
          $('#registrationClose').val('');
          $('#tournamentStart').val('');
        }else{
          $scope.tournamentMsg = 'Error while saving the data....';
        }
        
      });
    }else if(tournamentType == 'jackpotsTournaments'){
      
      $http.post(apiUrl+'tournament/addjackpotsTournament', {'tournamentName': $scope.tournament.tournamentName, 'matchId': $rootScope.matchId, 'entryFee': $scope.tournament.entryFee, 'maxPlayersPerTable':$scope.tournament.maxPlayersPerTable,'maxRegistartions':$scope.tournament.maxRegistartions, 'registrationStart':registrationStart,'registrationClose':registrationClose, 'tournamentStart': tournamentStart , 'estimatedDuration': $scope.tournament.estimatedDuration, 'prizeType':$scope.tournament.prizeType, 'totalRounds': $scope.tournament.totalRounds, 'currency': $scope.tournament.currency,allPrizeList:query }).success(function(data){
        console.log(data);
        if(data.success == 1 ){
          $scope.tournamentMsg = 'Tournament Saved Successfully...';
          $scope.tournament = {}; 
           $('#registrationStart').val('');
          $('#registrationClose').val('');
          $('#tournamentStart').val('');
        }else{
          $scope.tournamentMsg = 'Error while saving the data....';
        }
        
      });
    }else if(tournamentType == 'clubTournaments'){
      $http.post(apiUrl+'tournament/addClubTournament', {'tournamentName': $scope.tournament.tournamentName, 'matchId': $rootScope.matchId, 'entryFee': $scope.tournament.entryFee, 'maxPlayersPerTable':$scope.tournament.maxPlayersPerTable,'maxRegistartions':$scope.tournament.maxRegistartions, 'registrationStart':registrationStart,'registrationClose': registrationClose, 'tournamentStart': tournamentStart , 'estimatedDuration': $scope.tournament.estimatedDuration, 'prizeType':$scope.tournament.prizeType, 'totalRounds': $scope.tournament.totalRounds, 'currency': $scope.tournament.currency,allPrizeList:query }).success(function(data){
        console.log(data);
        if(data.success == 1 ){
          $scope.tournamentMsg = 'Tournament Saved Successfully...';
          $scope.tournament = {}; 
           $('#registrationStart').val('');
          $('#registrationClose').val('');
          $('#tournamentStart').val('');
        }else{
          $scope.tournamentMsg = 'Error while saving the data....';
        }
        
      });
    }
  
  }


}]);
