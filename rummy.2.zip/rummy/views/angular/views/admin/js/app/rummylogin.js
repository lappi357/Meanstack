var apiUrl = 'http://mobirummy.com/';
var adminUrl = 'http://mobirummy.com/admin';
var rummylogin = angular.module('rummylogin', []);
rummylogin.controller('loginCtrl', function($scope, $http, $location, $rootScope) {
    	$scope.adminLogin = function(){
    		var validationFlag=true;
			$scope.validateMessage='';
			if(!$scope.username){
				$scope.validateMessage="Pleas enter user email.!\n";
				validationFlag=false;
			}else if(!$scope.password){
				$scope.validateMessage ="Pleas enter user password.!";
				validationFlag=false;
			}
			if(validationFlag){
				var username = $scope.username;
	    		var password = $scope.password;
	    		$http.get(apiUrl+'api/admin/login/'+username+'/'+password).success(function(data){
	    			if(data.data!=null){
	    				$.cookie("adminUser", data.data, { expires: 7 });	
						location.href=adminUrl+'#/admindashboard';
	    			}else{
	    				$scope.validateMessage ='Invalid Email Id Or Password';
	    				$scope.username = "";
	    				$scope.password = "";	
	    			}
	    			
	    		});	
			}
    		
    	}
});