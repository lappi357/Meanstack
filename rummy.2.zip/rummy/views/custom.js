$(document).ready(function() { 

 $("#PageOpenTimer").TimeCircles();            
            var updateTime = function(){
                var date = $("#date").val();
                var time = $("#time").val();
                var datetime = date + ' ' + time + ':00';
                $("#DateCountdown").data('date', datetime).TimeCircles().start();
            }
            
			//--------------------------02 class----------------------
			$("#PageOpenTimer2").TimeCircles();            
          var updateTime = function(){
                var date = $("#date").val();
                var time = $("#time").val();
                var datetime = date + ' ' + time + ':00';
                $("#DateCountdown").data('date', datetime).TimeCircles().start();
            }
			
			//--------------------------03 class----------------------
			$("#PageOpenTimer3").TimeCircles();            
          var updateTime = function(){
                var date = $("#date").val();
                var time = $("#time").val();
                var datetime = date + ' ' + time + ':00';
                $("#DateCountdown").data('date', datetime).TimeCircles().start();
            }
			
			
			//--------------------------04 class----------------------
			$("#PageOpenTimer4").TimeCircles();            
          var updateTime = function(){
                var date = $("#date").val();
                var time = $("#time").val();
                var datetime = date + ' ' + time + ':00';
                $("#DateCountdown").data('date', datetime).TimeCircles().start();
            }
			
			//--------------------------05 class----------------------
			$("#PageOpenTimer5").TimeCircles();            
          var updateTime = function(){
                var date = $("#date").val();
                var time = $("#time").val();
                var datetime = date + ' ' + time + ':00';
                $("#DateCountdown").data('date', datetime).TimeCircles().start();
            }
			
			//--------------------------06 class----------------------
			$("#PageOpenTimer6").TimeCircles();            
          var updateTime = function(){
                var date = $("#date").val();
                var time = $("#time").val();
                var datetime = date + ' ' + time + ':00';
                $("#DateCountdown").data('date', datetime).TimeCircles().start();
            }
});


$(document).ready(function() { 
			$('.ca_chat_area').hide();
			 $('.ca_chat_text').hide();
			 $('.ca_send_chat').hide();
			 $('#ca_close_chat').hide();
			 $('#ca_open_chat').show();
		
	$("#ca_close_chat").click(function(){
		var position	=	$('.cs_chat_box').position();
		var left =	position.left;
		if(left==0){
			$('.ca_chat_area').hide();
			 $('.ca_chat_text').hide();
			 $('.ca_send_chat').hide();
			 $('#ca_close_chat').hide();
			 $('#ca_open_chat').show();
		  $(".cs_chat_box").css('left', function(){ return $(this).offset().left; })
             .animate({"left":"-166px"}, "slow"); 
		}
		 else {
			$(".cs_chat_box").css('left', function(){ return $(this).offset().left; })
             .animate({"left":"0px"}, "slow"); 			  	 
			 $('.ca_chat_area').show();
			 $('.ca_chat_text').show();
			 $('.ca_send_chat').show();
			 
		 }
	});
	
	$('#ca_open_chat').click(function(){
		$(".cs_chat_box").css('left', function(){ return $(this).offset().left; })
             .animate({"left":"0px"}, "slow"); 			  	 
			 $('.ca_chat_area').show();
			 $('.ca_chat_text').show();
			 $('.ca_send_chat').show();
			 $('#ca_open_chat').hide();
			 $("#ca_close_chat").show();
	})
	
	

});


$(document).ready(function(){
  $("#ca_game_detail").click(function(){
    $(".topleft-links").slideToggle();
  });
});

$(document).ready(function(){
  $("#ca_reward_points").click(function(){
    $(".topright-links").slideToggle();
  });
});


