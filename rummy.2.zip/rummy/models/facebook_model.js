var mongoose	=	require('mongoose');
var helper      =   require(process.cwd()+'/helpers/common_helper.js');
var md5         =   require('MD5');



var mongooseConnection	=	mongoose.connect('mongodb://localhost:27017/rummy',function(err,data)
{
	if(err)
	console.log(err+'in match model');
});

var schema	=	mongoose.Schema();

var facebookSchema	= mongoose.Schema(
{
	'id':String,
	'token':String,
	'email':String,
	'name' :String
    
});


module.exports	=	mongoose.model('facebook',facebookSchema);
