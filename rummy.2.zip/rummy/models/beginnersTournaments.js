var mongoose	=	require('mongoose');
var mongooseConnection	=	mongoose.connect('mongodb://localhost:27017/rummy',function(err,data)
{
	if(err)
	console.log(err+'in tournaments Model');
});

var tournaments_model  =   require(process.cwd()+'/models/tournaments.js');

/*Schema of tournaments table */
var beginnersTournamentsSchema	= mongoose.Schema(
{
	'tournamentName':{type:String,required:true},
	'matchId':{type:String,required:true},
	'entryFee':{type:String,default:''},
	'maxPlayersPerTable':{type:Number,required:true},
	'maxRegistartions':{type:Number,required:true},
	'registrationStart':{type:String,required:true},
	'registrationClose':{type:String,required:true},
	'tournamentStart':{type:String,required:true},
	'estimatedDuration':{type:String,default:''},
	'prizeType':{type:String,default:''},
	'totalRounds':{type:Number,required:true},
	'allPrizeList':{type:Object,default:'{}'},
	'currency':{type:String,default:''},
	'tournamentStatus':{type:String,default:''}
});

beginnersTournamentsSchema.post('save',function(doc) {

	var tournamentSubCat	=	doc._id;
	var catId	=	2;
	var catName	=	'beginners';
	var tournaments    =   new tournaments_model({ catId:catId,catName:catName,tournamentSubCat:tournamentSubCat});
        
	tournaments.save(function (err, userDoc) {
		if(err)
		{
			console.log(err);
		}

	});

});

module.exports	=	mongoose.model('beginners_tournament',beginnersTournamentsSchema);