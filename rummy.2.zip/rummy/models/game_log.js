var mongoose	=	require('mongoose');

var mongooseConnection	=	mongoose.connect('mongodb://localhost:27017/rummy',function(err,data)
{
	if(err)
	console.log(err+'in game_log model');
});
													
var schema	=	mongoose.Schema();

var gameLogSchema	= mongoose.Schema(
{
	
	'userId':{type:String,required:true},
	'matchId':{type:String,required:true}
	
});

module.exports	=	mongoose.model('game_log',gameLogSchema);