var mongoose	=	require('mongoose');

var mongooseConnection	=	mongoose.connect('mongodb://localhost:27017/rummy',function(err,data)
{
	if(err)
	console.log(err+'in table model');
});
													
var schema	=	mongoose.Schema();

var findMeAGameSchema	= mongoose.Schema(
{
	
	'userId':{type:String,required:true},
	'matchMethod':{type:String,required:true},
	'matchFormatId' : {type:Number,required:true},
	'maxPlayers' : {type:Number,required:true},
	'waitingStatus' : {type:String,default:'waiting'}
	
});

module.exports	=	mongoose.model('waitingUsers',findMeAGameSchema);