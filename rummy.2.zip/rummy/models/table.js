var mongoose	=	require('mongoose');

var mongooseConnection	=	mongoose.connect('mongodb://localhost:27017/rummy',function(err,data)
{
	if(err)
	console.log(err+'in table model');
});
													
var schema	=	mongoose.Schema();

var tableSchema	= mongoose.Schema(
{
	'tableName':{type:String,default:''},
	'decks':{type:Number,default:0},
	'pointValue':{type:Number,default:0},
	'entryFee':{type:Number,default:0},
	'poolType':{type:Number,default:0},
	'prize':{type:String,default:''},
	'deals':{type:Number,default:0},
	'maxPlayers':{type:Number,default:0},
	'matchMethod':{type:String,default:''},
	'matchFormatId':{type:Number,default:0},
	'tableStatus':{type:String,default:''},
	'match_title':String,
	'match_seating':Array,
	'match_type':{type:Number,default:0},
	'match_game_type':{type:Number,default:0},
	'match_users':mongoose.Schema.Types.Mixed,
	'match_join_users':Array,
	'match_waiting_users':Array,
	'match_users_turn_detail':Array,
	'match_start_time':{type: Date, default: Date.now},
	'match_end_time':{type: Date, default: Date.now},
	'match_deck_close':mongoose.Schema.Types.Mixed,
	'match_player_no':{type:Number,default:6},
	'match_deck_open':mongoose.Schema.Types.Mixed,
	'match_last_moved_card':{type:String,default:''},
	'match_player_card':mongoose.Schema.Types.Mixed,
	match_last_player:{type:Number,default:-1},
	match_current_player:{type:Number,default:0},
	match_point_value:{type:Number,default:10},
	match_min_entry:{type:Number,default:100},
	'match_joker':String,
	match_date_time:Date,
	match_status:{type:Number,default:1},
    turn_counter:Number,
    match_turn_status:{type:Number,default:0},
    match_declare:Array,
    no_of_current_join : {type:Number,default:0},
    drop_users:{type:mongoose.Schema.Types.Mixed,default:''},
   	'table_history':Array,
   	'dropNdeclareData':Array,
   	'match_toss_winner':{type:String,default:''},
   	'current_match_user_points':{type:mongoose.Schema.Types.Mixed,default:''},
   	'users_turn_counter':{type:mongoose.Schema.Types.Mixed,default:''},
   	'pool_currentMatch_userpoints':{type:mongoose.Schema.Types.Mixed,default:''},
   	'deal_currentMatch_userpoints':{type:mongoose.Schema.Types.Mixed,default:''},
   	'currentDeal':{type:Number,default:0},
   	'deal_match_watch_list':Array,
   	'match_watch_list':Array,
   	'dealTie':{type:Number,default:0},
   	'last_deal':Array,
	
});

module.exports	=	mongoose.model('table',tableSchema);
