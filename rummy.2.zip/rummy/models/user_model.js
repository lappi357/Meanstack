var mongoose	=	require('mongoose');
var helper      =   require(process.cwd()+'/helpers/common_helper.js');
var md5         =   require('MD5');



var mongooseConnection	=	mongoose.connect('mongodb://localhost:27017/rummy',function(err,data)
{
	if(err)
	console.log(err+'in match model');
});

var schema	=	mongoose.Schema();

var userSchema	= mongoose.Schema(
{
	'email':{type:String,required:true,unique:true,lowercase:true,validate:helper.validateEmail},
	'password':{type:String,set:md5},
	'firstname':String,
	'username':{type:String,unique:true},
	'contact':{type:Number,default:''},
	'gender':{type:String}, 
	'dob':{type:String},
	'resetToken':{type:String,default:''},
	'userPoints':{type:Number,default:10000},
	'userType':{type:Number,default:0},
	'refral':String,
	'profilePic':String
    
});


module.exports	=	mongoose.model('User',userSchema);
