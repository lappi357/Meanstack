var mongoose	=	require('mongoose');
var mongooseConnection	=	mongoose.connect('mongodb://localhost:27017/rummy',function(err,data)
{
	if(err)
	console.log(err+'in tournaments Model');
});


/*Schema of tournaments table */
var tournamentsSchema	= mongoose.Schema(
{
	'catId':{type:String,required:true},
	'catName':{type:String,required:true},
	'tournamentSubCat':{type:String,required:true},
	'createTime':{type: Date, default: Date.now}
    
});

module.exports	=	mongoose.model('tournament',tournamentsSchema);