var mongoose	=	require('mongoose');
var mongooseConnection	=	mongoose.connect('mongodb://localhost:27017/rummy',function(err,data)
{
	if(err)
	console.log(err+'in tournaments filters Model');
});


/*Schema of tournaments filters table */
var tournamentsFiltersSchema	= mongoose.Schema(
{
	
	'filterName':{type:String,required:true},
	'filterType':{type:String,required:true},
	'value':{type:String,required:true}
    
});

module.exports	=	mongoose.model('tournament_filters',tournamentsFiltersSchema);