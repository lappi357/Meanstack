var mongoose	=	require('mongoose');

var mongooseConnection	=	mongoose.connect('mongodb://localhost:27017/rummy',function(err,data)
{
	if(err)
	console.log(err+'in match model');
});
													
var schema	=	mongoose.Schema();

var matchSchema	= mongoose.Schema(
{
	'matchName':{type:String,default:''},
	'matchId':{type:Number,default:0},
	
});

module.exports	=	mongoose.model('Match',matchSchema);
