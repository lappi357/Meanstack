var mongoose	=	require('mongoose');
var md5         =   require('MD5');

var mongooseConnection	=	mongoose.connect('mongodb://localhost:27017/rummy',function(err,data)
{
	if(err)
	console.log(err+'in user model');
});

var schema	=	mongoose.Schema();

var userSchema	= mongoose.Schema(
{
	'email':{type:String,unique:true,validate:validateEmail,required:true},
	'password':{type:String,set:md5,required:true},
	'firstname':String,
	'lastname':String
    
});

/*statics starts*/
userSchema.statics.findByColum   =   function (Colum,value)
{
    var arg =   {};
    arg[Colum]  =   value;
        this.find(arg,{},function(err,results)
        {
            if(err)
            {
                    console.log(err);
                return false;
            }
            else
            {
              //  console.log(results);
                return results;
                
            }
                
        });
};

userSchema.statics.findByEmail   =   function (email,cb)
{
    
       var result       = this.findOne({email:'devkishore24@gmail.com'},{},cb);
   
};
/*statics ends*/


/*methods starts*/
userSchema.methods.getName   =   function (email)
{
  
        return this.firstname+' '+this.lastname;
};

/*methods ends*/



module.exports	=	mongoose.model('User',userSchema);


/*custom functions starts*/

function validateEmail(email) {
    var x = email;
    var atpos = x.indexOf("@");
    var dotpos = x.lastIndexOf(".");
    if (atpos< 1 || dotpos<atpos+2 || dotpos+2>=x.length) {
        console.log("Not a valid e-mail address");
        return false;
    }
    else
    {
            console.log('validation done');
        return true;
    }
}
/*custom functions ends*/

