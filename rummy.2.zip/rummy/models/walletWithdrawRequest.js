var mongoose	=	require('mongoose');
var user_model  =   require(process.cwd()+'/models/user_model.js');
var walletWithdrawRequest_model  =   require(process.cwd()+'/models/walletWithdrawRequest.js');
var mongooseConnection	=	mongoose.connect('mongodb://localhost:27017/rummy',function(err,data)
{
	if(err)
	console.log(err+'in walletWithdrawRequest Model');
});


/*Schema of wallet transaction table */
var walletWithdrawRequestSchema	= mongoose.Schema(
{
	'userId':{type:String,required:true},
	'firstName':{type:String,required:true},
	'lastName':{type:String,required:true},
	'dob':{type:String,required:true},
	'addressLine1':{type:String,required:true},
	'addressLine2':{type:String,required:true},
	'city':{type:String,required:true},
	'state':{type:String,required:true},
	'pincode':{type:Number,required:true},
	'mobileno':{type:Number,required:true},
	'withdrawType':{type:String,default:''},
	'accountHolderName':{type:String,default:''},
	'accountNumber':{type:Number,default:0},
	'MICRCode':{type:String,default:''},
	'IFSCCode':{type:String,default:''},
	'bankName':{type:String,default:''},
	'branchName':{type:String,default:''},
	'amount':{type:String,default:''},
	'status':{type:String,required:true,default:''},
	'createTime':{type: String, default: ''}
    
});

module.exports	=	mongoose.model('walletWithdrawRequest',walletWithdrawRequestSchema);





