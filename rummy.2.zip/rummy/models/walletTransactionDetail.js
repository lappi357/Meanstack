var mongoose	=	require('mongoose');
var md5         =   require('MD5');

var walletTransaction_model  =   require(process.cwd()+'/models/wallet.js');
var user_model  =   require(process.cwd()+'/models/user_model.js');
var mongooseConnection	=	mongoose.connect('mongodb://localhost:27017/rummy',function(err,data)
{
	if(err)
	console.log(err+'in walletTransaction Model');
});

var smtpTransport =require('../mailSettings.js');

/*Schema of wallet transaction table */
var walletTransactionSchema	= mongoose.Schema(
{
	'userId':{type:String,required:true},
	'txnId':{type:String,default:''},
	'packageId':{type:String,default:''},
	'amount':{type:String,default:''},
	'currency':{type:String,default:''},
	'paymentMethod':{type:String,default:''}, 
	'payerId':{type:String,default:''},
	'createTime':{type: Date, default: Date.now},
	'transactionType':{type:String,default:''}
    
});
walletTransactionSchema.post('save',function(doc) {

	var transactionType=doc.transactionType;
	var wallettransactionAmount=doc.amount;
	/*Get user info by user Id*/
	user_model.findOne({ _id:doc.userId}, {},function (err, userDoc) {

	    if(err)
	    {
	        console.log(err);
	    }
	    else
	    {
	      	var userId=userDoc._id;
	      	var userEmail=userDoc.email;
	      	var firstname=userDoc.firstname;
	    	walletTransaction_model.findOne({ userId:userId}, {},function (err, userDoc) {

	    		var amount=0;
	    		if(transactionType=="Credit")
		    	{
		    		
		    		if(userDoc==null)
		    		{
		    			amount=0+parseFloat(wallettransactionAmount);

		    		}
		    		else
		    		{
		    			amount=parseFloat(userDoc.amount)+parseFloat(wallettransactionAmount);
		    		}

		    		walletTransaction_model.findOneAndUpdate({ userId:userId},{userId:userId,amount:amount }, {upsert:true},function(err,doc)
				    {
				            if (err) return console.log(err);
				            return console.log(doc);
				    });
				    smtpTransport.sendMail({
				       from: "Mobirummy <mobirummy@kiozen.com>", // sender address
				       to: firstname+" <"+userEmail+">", // comma separated list of receivers
				       subject: "Amount has been credited in your MobiRummy account", // Subject line
				       html: " Your Total Account Balance is $"+amount // plaintext body
				    }, function(error, response){
				       if(error){
				           console.log(error);
				       }else{
				           console.log(response);
				       }
				    }); 
		    	}
		    	else if(transactionType=="Debit")
		    	{
		    		if(userDoc!=null)
		    		{
		    			amount=parseFloat(userDoc.amount)-parseFloat(wallettransactionAmount);
		    			walletTransaction_model.findOneAndUpdate({ userId:userId},{userId:userId,amount:amount }, {upsert:false},function(err,doc)
					    {
					            if (err) return console.log(err);
					            return console.log(doc);
					    });
					    smtpTransport.sendMail({
					       from: "Mobirummy <mobirummy@kiozen.com>", // sender address
					       to: firstname+" <"+userEmail+">", // comma separated list of receivers
					       subject: "Amount has been debited  from your MobiRummy account", // Subject line
					       html: " Your Total Account Balance is $"+amount // plaintext body
					    }, function(error, response){
					       if(error){
					           console.log(error);
					       }else{
					           console.log(response);
					       }
					    }); 

		    		}

		    		
		    	}

	    	});

	    }
	});

});
module.exports	=	mongoose.model('WalletTransaction',walletTransactionSchema);
