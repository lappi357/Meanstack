var mongoose	=	require('mongoose');
var md5         =   require('MD5');



var mongooseConnection	=	mongoose.connect('mongodb://localhost:27017/rummy',function(err,data)
{
	if(err)
	console.log(err+'in wallet Model');
});

/*Schema of wallet transaction table */
var walletSchema	= mongoose.Schema(
{
	'userId':{type:String,required:true},
	'amount':{type:String,required:true},
	'points':{type:String,default:''}
    
});

module.exports	=	mongoose.model('Wallet',walletSchema);