var base_uri = 'http://mobirummy.com/';
var game	=	angular.module('game', ['ngCookies','ngRoute']);

game.controller('tableCtrl',['$http','$scope','$cookieStore','$route','$routeParams','$location',function($http,$scope,$cookieStore,$route,$routeParams,$location)
{
	
	/*setInterval(function(){
		var mid = $location.search().q;
        $.get(base_uri+'api/game/checkMatchStatus/'+mid).success(function(data){
        	console.log(data);
        });
	}, 2000);*/
}]);
