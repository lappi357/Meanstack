<?php
$content	=	simplexml_load_string(file_get_contents('https://www.google.co.in/alerts/feeds/16662047799013779839/12930295921731097643'));

echo '<pre>';
print_r($content);
echo '</pre>';