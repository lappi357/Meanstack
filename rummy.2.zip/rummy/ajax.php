<?php



$string='';
$siteUrl = 'http://52.10.187.1:8080/';
if(!empty($_GET))
{
	foreach($_GET as $key=>$val)
	{
		if($val=='')
		{
			$val=1;
		}

		$string	.=	$key.'='.$val.'&';
	}
}
if(!isset($_GET['method'])) 
{
	$data	=	file_get_contents($siteUrl.$string);
	//echo $siteUrl.$string;
	echo $data;
}
else
{
	
	
	$params['data'] = file_get_contents('php://input');
	
	$ch = curl_init(); 
    curl_setopt($ch,CURLOPT_URL,$siteUrl.$_GET['method']);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_HEADER, false);

	if(isset($_GET['put']) && $_GET['put']==1)
	{
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
    }
	else
	{
		curl_setopt($ch, CURLOPT_POST, 1);
	}
	curl_setopt($ch, CURLOPT_POSTFIELDS, $params);   
 
    $output=curl_exec($ch);
 
    curl_close($ch);
	print_r($output); 
	
	
	
}





?>