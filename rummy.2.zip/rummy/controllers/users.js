var express = require('express');
var app = express();
var async = require('async');
var router = express.Router();
/*var FacebookStrategy = require('passport-facebook').Strategy;*/
var user_model  =   require(process.cwd()+'/models/user_model.js');
/*var facebook_model  =   require(process.cwd()+'/models/facebook_model.js');*/
var walletTransactionDetail_model  =   require(process.cwd()+'/models/walletTransactionDetail.js');

var md5 =   require('MD5');
var encryptKey     =    'rummyteenpatti';
var helper  =   require(process.cwd()+ '/helpers/common_helper.js');

/*var configAuth = require('../auth.js');
*/

var smtpTransport =require('../mailSettings.js');

var main    =   {};


module.exports = function(router)
{

    /* Facebook login route */

    /*router.get('/auth/facebook', passport.authenticate('facebook', {scope: ['email']}));

    router.get('/auth/facebook/callback', passport.authenticate('facebook', { successRedirect: '/', failureRedirect: '/' }));

    passport.use(new FacebookStrategy({
        clientID: configAuth.facebookAuth.clientID,
        clientSecret: configAuth.facebookAuth.clientSecret,
        callbackURL: configAuth.facebookAuth.callbackURL
      },
      function(accessToken, refreshToken, profile, done) {
            process.nextTick(function(){
                facebook_model.findOne({'facebook.id': profile.id}, function(err, user){
                    if(err)
                        return done(err);
                    if(user)
                        return done(null, user);
                    else {
                        var newUser = new facebook_model();
                        newUser.facebook.id = profile.id;
                        newUser.facebook.token = accessToken;
                        newUser.facebook.name = profile.name.givenName + ' ' + profile.name.familyName;
                        newUser.facebook.email = profile.emails[0].value;

                        newUser.save(function(err){
                            if(err)
                                throw err;
                            return done(null, newUser);
                        })
                        console.log(profile);
                    }
                });
            });http://mobirummy.com/angular/#reset-password?q="+encryptUserId+"/"+reset_token
        }

    ));*/


/* facebook login route close */
     router.post('/user/sendEmails',function(req,res){
        var invitationMail = req.body.invitationMail;
        var refral = req.body.refral;

        async.waterfall([
                function(callback){
                    var counter = 0;
                    for(var i=0;i<invitationMail.length; i++){
                         smtpTransport.sendMail({
                           from: "Mobirummy <mobirummy@kiozen.com>", // sender address
                           to:" <"+invitationMail[i]+">", // comma separated list of receivers
                           subject: "Mobirummy Invitation", // Subject line
                           //html: "<p>Hello There you want to play mobirummy kindly join this game while registering.<a href='http://mobirummy.com/angular/?refral="+refral+"'>Click Here For Free Registration</a></p>"
                            html: "<p>Hello There you want to play mobirummy kindly join this game while registering.<a href='http://mobirummy.com/angular/#refral?q="+refral+"'>Click Here For Free Registration</a></p>"
                            }, function(error, response){
                           if(error){
                               console.log(error);
                               callback(error, null);
                           }else{
                               console.log("Message sent: ");
                           }
                           
                           counter++;
                           console.log('condition=>'+counter+' == '+invitationMail.length )
                           if( counter == invitationMail.length ){
                                callback(null, true);
                           }

                        });
                    }
                }
            ], function(error, result){
                if(error){
                    console.log('error=>'+error)
                    return res.send({success:0, data:error});
                }
                else{
                    console.log('success=>'+result)
                    return res.send({success:1, data:'Message sent successfully'});
                }
        });
        
    });



    router.post('/user/sendInvitation',function(req,res){
        var invitationMail = req.body.invitationMail;
        var refral = req.body.refral;
        for(var i=0;i<=invitationMail.length-1; i++){
             smtpTransport.sendMail({
               from: "Mobirummy <mobirummy@kiozen.com>", // sender address
               to:" <"+invitationMail[i]+">", // comma separated list of receivers
               subject: "Mobirummy Invitation", // Subject line
               html: "<p>Hello There you want to play mobirummy kindly join this game while registering.<a href='http://mobirummy.com/angular/?refral="+refral+"'>Click Here For Free Registration</a></p>"
                }, function(error, response){
               if(error){
                   console.log(error);
               }else{
                   console.log("Message sent: ");
               }
            });
        }
        return res.send({success:1, data:'sent'});
        
    });

    router.get('/user/userLogin',function (req,res)
    {
        console.log(req.query.userEmail);
        console.log(req.query.userPass);
        user_model.findOne({ email: req.query.userEmail, password:md5(req.query.userPass)}, {},function (err, result) {
        
        if(err)
        {
            res.send({success:0,data:err});
        }
        else
        {
            
            var token    =    helper.encryptData(req.ip+'||'+result._id+'||'+Date(),encryptKey);
            
            res.send({success:1,data:{email:result.email,name:result.name,token:token}});
        }
        
        });
    });


    router.get('/user/getUserInfo',function (req,res)
    {
        user_model.findOne({ _id:req.query.userId}, {},function (err, userDoc) {

        if(err)
        {
            res.send({success:0,data:err});
        }
        else
        {
            res.send({success:1,data:userDoc});
        }


     });

    });



    router.get('/user/getUser',function (req,res)
    {
        var token   =   helper.decryptData(req.query.token,encryptKey);
        if(!token)
        {
            res.send('Not Authorized');
        }
        var user_id =   token.split('||'); 
        if(req.ip!=user_id[0])
        {
            res.send('Not Authorized');
            return false;
        }
        
        console.log(user_id);
        user_model.findOne({ _id:user_id[1]}, {},function (err, result) {
        
        if(err)
        {
            res.send({success:0,data:err});
        }
            else
            {
                var token   =   helper.encryptData(result._id,encryptKey);
                res.send({success:1,data:{email:result.email,name:result.name,token:token}});
            }
        
        });
    });

    router.post('/user/createUser',function (req,res)
    {
        var post_data   =   JSON.parse(req.body.data);
        console.log(post_data);
        var user    =   new user_model({email:post_data.userEmail,password:post_data.userPass,firstname:post_data.firstname,username:post_data.username,dob:post_data.dob,gender:post_data.gender,contact:post_data.contact});
        user.save(function (err,doc)
        {
            if(err)
            {
                console.log(err);
                res.send(err);
            }
            else
            {
                res.send(doc);
            }
        });
    });
    /*Add new user added by rashmi sharma on 31-07-2015 */
    router.post('/user/addNewUser',function (req,res)
    {
        var refral=req.body.refral;
        console.log('Refral=>'+refral);
        if(refral){
            var refralUser  =   new user_model({email:req.body.userEmail,password:req.body.userPass,firstname:req.body.firstname,username:req.body.username,dob:req.body.dob,gender:req.body.gender,contact:req.body.contact,refral:req.body.refral});
             refralUser.save(function (err,doc)
            {
            if(err)
            {
                res.send({success:0,data:err});
            }
            else
            {
                
                if(doc!=null)
                {
                    user_model.findOne({ _id:refral}, {},function (err, userDoc) {
                        if(userDoc)
                        {
                            userDoc.userPoints += 10000;
                            userDoc.save(function (err,updatedDoc)
                            {
                            });
                        }

                        smtpTransport.sendMail({
                           from: "Mobirummy <mobirummy@kiozen.com>", // sender address
                           to: doc.username+" <"+userDoc.email+">", // comma separated list of receivers
                           subject: "Mobirummy Refral Points", // Subject line
                           html: "<p>Hey '"+doc.username+"' you got 10000 chips because a refral user has joined <a href='http:mobirummy.com/angular'>MobiRummy</a> through you. </p>"
                            }, function(error, response){
                           if(error){
                               console.log(error);
                           }else{
                               console.log("Message sent: ");
                           }
                        });


                     });

                    res.send({success:1,data:doc});
                }
               
                
                smtpTransport.sendMail({
                   from: "Mobirummy <mobirummy@kiozen.com>", // sender address
                   to: doc.username+" <"+doc.email+">", // comma separated list of receivers
                   subject: "Registration Successfully", // Subject line
                   html: "<p>Thank you for registering with MobiRummy.com</p>"
                    }, function(error, response){
                   if(error){
                       console.log(error);
                   }else{
                       console.log("Message sent: ");
                   }
                });
            }
        });
        }else{
            var user    =   new user_model({email:req.body.userEmail,password:req.body.userPass,firstname:req.body.firstname,username:req.body.username,dob:req.body.dob,gender:req.body.gender,contact:req.body.contact,profilePic:req.body.profilePic});
        user.save(function (err,doc)
        {
            if(err)
            {
                res.send({success:0,data:err});
            }
            else
            {
                
                if(doc!=null)
                {
                    res.send({success:1,data:doc});
                }
                else
                {
                    res.send({success:1,data:doc});
                }
                
                smtpTransport.sendMail({
                   from: "Mobirummy <mobirummy@kiozen.com>", // sender address
                   to: doc.username+" <"+doc.email+">", // comma separated list of receivers
                   subject: "Registration Successfully", // Subject line
                   html: "<p>Thank you for registering with MobiRummy.com</p>"
                    }, function(error, response){
                   if(error){
                       console.log(error);
                   }else{
                       console.log("Message sent: ");
                   }
                });
            }
        });
        }
        
    });

    router.post('/user/matchUsers', function(req, res){
       user_model.findOne({email:req.body.userEmail},{},function(err,docu)
        {
            if (err)
            {
                return res.send({success:0,data:err});
            }
            else
            {
                return res.send({success:1,data:docu});  
            }
        });
    });

    /* Contact us form by raghvendra singh  */

    router.post('/user/contactus', function(req, res){
        console.log(req.body.email);
           smtpTransport.sendMail({
                   from: req.body.email, // sender address
                   to: "raghvendra.pratap@kiozen.com", // comma separated list of receivers
                   subject: req.body.topic, // Subject line
                   html: "<p>'"+req.body.messge+"'</p>"
                    }, function(error, response){
                   if(error){
                       console.log(error);
                   }else{
                      return res.send({success:1, data:"Message Sent"});
                   }
            });
    });

    router.get('/user/getAllUsers',function (req,res)
    {

        user_model.find({},function (err,doc)
        {
           
            res.send(doc);
        });
    });

    /*Change Password  Added By Rashmi Sharma on 31-07-2015*/
    router.put('/user/changePassword',function (req,res)
    {
        user_model.findOneAndUpdate({ _id:req.body.userId,password:md5(req.body.password)},{ password: md5(req.body.newPassword) }, {upsert:false},function(err,doc)
        {
                if (err)
                {
                    return res.send({success:0,data:err});
                }
                else
                {
                    if(doc!=null)
                    {
                        smtpTransport.sendMail({
                           from: "Mobirummy <mobirummy@kiozen.com>", // sender address
                           to: doc.username+" <"+doc.email+">", // comma separated list of receivers
                           subject: "Password Changed Successfully", // Subject line
                           text: "Your Password has been changed successfully" // plaintext body
                        }, function(error, response){
                           if(error){
                               console.log(error);
                           }else{
                               console.log("Message sent: ");
                           }
                        });
                        return res.send({success:1,data:doc});
                    }
                    else
                    {
                        return res.send({success:1,data:"successfully changed"});
                    }
                    
                    
                } 
                
        });
        

    });

    /*Change User Email Added By Rashmi Sharma on 31-07-2015*/
    router.put('/user/changeUserEmail',function (req,res)
    {
        user_model.findOneAndUpdate({ email:req.body.email},{ email:req.body.newEmail }, {upsert:false},function(err,doc)
        {
                if (err)
                {
                    return res.send({success:0,data:err});
                } 
                else
                {

                    if(doc!=null)
                    {
                        return res.send({success:1,data:"successfully updated"});

                    }
                    else
                    {
                        return res.send({success:1,data:doc});
                    }
                    
                }
                
        });
        
    });

    /*Update Mobile No Added By Rashmi Sharma on 31-07-2015*/
    router.put('/user/updateMobileNo',function (req,res)
    {
        user_model.findOneAndUpdate({ _id:req.body.userId},{ contact:req.body.contact }, {upsert:false},function(err,doc)
        {
                if (err)
                {
                    return res.send({success:0,data:err});
                }
                else
                {
  
                    if(doc!=null)
                    {
                       smtpTransport.sendMail({
                           from: "Mobirummy <mobirummy@kiozen.com>", // sender address
                           to: doc.username+" <"+doc.email+">", // comma separated list of receivers
                           subject: "your contact number changed successfully", // Subject line
                           html: "Hello "+doc.username+"<br/>your contact number has been  changed successfully" // plaintext body
                        }, function(error, response){
                           if(error){
                               console.log(error);
                           }else{
                               console.log("Message sent: ");
                           }
                        });

                        user_model.findOne({_id:doc._id},{},function(err,docu)
                        {
                            if (err)
                            {
                                return res.send({success:0,data:err});
                            }
                            else
                            {
                                return res.send({success:1,data:docu});  
                            }
                        });
                        
                    }
                    else
                    {
                        return res.send({success:1,data:doc});
                    }
                    
                } 
                
        });
        
    });


    /*Reset Password link Added By Rashmi Sharma on 31-07-2015*/
    router.put('/user/forgotPassword',function(req,res)
    {

        var reset_token=md5(Math.random());

        user_model.findOneAndUpdate({ email:req.body.email},{ resetToken: reset_token }, {upsert:false},function(err,doc)
        {
                
            if (err) 
            {
                return res.send({success:0,data:err});
            }
            else
            {
                
                
                
                if(doc!=null)
                {
                    var encryptUserId   =   helper.encryptData(doc._id,'forgotPassword');
                    res.send({success:1,data:"successfully"});
                   smtpTransport.sendMail({
                       from: "Mobirummy <mobirummy@kiozen.com>", // sender address
                       to: doc.username+" <"+doc.email+">", // comma separated list of receivers
                       subject: "Reset Password", // Subject line
                       html: "Hello "+doc.username+"<br/><p>We have received a forgot username/password request.</p> <p>Your MobiRummy Username is "+doc.username+"</p> .<p>You can also reset your password by clicking on the following URL:<p> http://mobirummy.com/angular/#reset-password?q="+encryptUserId+"/"+reset_token // plaintext body
                    }, function(error, response){
                       if(error){
                           console.log(error);
                       }else{
                           console.log("Message sent: ");
                       }
                    });  
                }
                else
                {
                    return res.send({success:0,data:"failed"});
                }
               
            }
                
        });
    });

    /*Reset Password Added by Rashmi sharma 02-08-2015*/
    router.put('/user/resetPassword',function(req,res)
    {

        var token   =   helper.decryptData(req.body.userId,'forgotPassword');
        if(!token)
        {
            return res.send('Not Authorized');
        }
        var user_id =   token.split('||'); 
       
        user_model.findOneAndUpdate({ _id:user_id[0],resetToken:req.body.resetToken},{ password:md5(req.body.password) }, {upsert:false},function(err,doc)
        {
            if(err) 
            { 
                return res.send({success:0,data:err});
            }
            else
            {
                
                if(doc!=null)
                {
                    smtpTransport.sendMail({
                       from: "Mobirummy <mobirummy@kiozen.com>", // sender address
                       to: doc.username+" <"+doc.email+">", // comma separated list of receivers
                       subject: "Password Changed Successfully", // Subject line
                       text: "Your Password has been changed successfully" // plaintext body
                    }, function(error, response){
                       if(error){
                           console.log(error);
                       }else{
                           console.log("Message sent: ");
                       }
                    });
                    return res.send({success:1,data:"successfully changed"});
                }
                else
                {
                    return res.send({success:1,data:doc});
                }
                    
                
            }
        });
    });



    router.get('/user/login', function (req,res)
    {
        console.log(req.query.userEmail);
        console.log(req.query.userPass);
        user_model.findOne({ email: req.query.userEmail, password:md5(req.query.userPass)}, {},function (err, result) {
        
        if(err)
        {
            res.send({success:0,data:err});
            /*cb({success:0,data:err});*/
                
        }
        else
        {
          
            if(result!=null)
            {

                res.send({success:1,data:{_id:result._id,username:result.username,email:result.email,name:result.name}});
                /*cb({success:1,data:{_id:result._id,email:result.email,name:result.name,token:token}});
                */
            }
            else
            {
                res.send({success:1,data:result});
            }
        }
        
        });

    });

    


    /*Get wallet Transaction detail by user id Added by Rashmi Sharma on 1-08-2015*/
    router.get('/user/getWalletTnxDetailByUserId',function(req,res)
    {
        var query={};
        console.log(req.query.transactionType);
        if(req.query.transactionType)
        {
            if(req.query.transactionType=="dnw")
            {
               
                query={ userId: req.query.userId,$or:[{transactionType: "Debit"}, {transactionType:"Credit"}]};
            }
            else if(req.query.transactionType=="ot")
            {
                

                query={userId:req.query.userId,$and:[{transactionType:{'$ne':'Debit'}},{transactionType: {'$ne':'Credit' }},{transactionType: {'$ne':'Bonuses' }},{transactionType: {'$ne':'game_transaction' }}]};
            }
            else
            {
                query={ userId: req.query.userId,transactionType:req.query.transactionType};
            }
        }
        else
        {
            query={ userId: req.query.userId};
        }
        walletTransactionDetail_model.find(query,{},function (err, result) {
        
        if(err)
        {
            res.send({success:0,data:err});
                
        }
        else
        {
            res.send({sucess:1,data:result});
            
        }
        
        });
    });


     /*validate login details of admin added by Rashmi Sharma on 25-08-2015*/
    router.get('/admin/login/:userName/:userPass', function (req,res)
    {
        
        
        user_model.findOne({ username: req.params.userName, password:md5(req.params.userPass),userType:1}, {},function (err, result) {
        
            if(err)
            {
                res.send({success:0,data:err});
                /*cb({success:0,data:err});*/
                    
            }
            else
            {
              
                if(result!=null)
                {

                    res.send({success:1,data:{_id:result._id,username:result.username,email:result.email,name:result.name}});
                    /*cb({success:1,data:{_id:result._id,email:result.email,name:result.name,token:token}});
                    */
                }
                else
                {
                    res.send({success:0,data:'Invalid credentials'});
                }
            }
        
        });

    });

    /*get all user information added by rashmi sharma on 25-08-2015*/
    router.get('/admin/user/getAllUsers',function (req,res)
    {

        user_model.find({userType:0},function (err,doc)
        {
            if(err)
            {
                return res.send({success:0,data:err});
            }
            else{

                return res.send({success:1,data:doc});
            }
            
        });
    });

    /*delete  user by user id  added by rashmi sharma on 25-08-2015*/
    router.get('/admin/user/deleteUser/:userId',function (req,res)
    {

        user_model.remove({_id:req.params.userId},function (err,doc)
        {
            if(err)
            {
                return res.send({success:0,data:err});
            }
            else{

                return res.send({success:1,data:doc});
            }
            
        });
    });

/* Get Uesr By Id By Raghvendra Singh 28-08-15 */
    router.get('/admin/user/getUserById/:userId', function(req,res){
        user_model.findOne({_id:req.params.userId},{}, function(err, result){
            if(err){
                return res.send({success:0, data:err});
            }else{
                return res.send({success:1, data:result});
            }
        });
    });

     /*delete  user by user id  added by rashmi sharma on 25-08-2015*/
    router.put('/admin/user/updateUserInfo/:userId',function (req,res)
    {

        user_model.findOneAndUpdate({ _id:req.params.userId},{ email:req.body.userEmail,dob:req.body.dob,username:req.body.username,firstname:req.body.firstname,gender:req.body.gender,contact:req.body.contact }, {upsert:false},function(err,doc)
        {
            if (err)
            {
                return res.send({success:0,data:err});
            }
            else
            {

                if(doc!=null)
                {
                   smtpTransport.sendMail({
                       from: "Mobirummy <mobirummy@kiozen.com>", // sender address
                       to: doc.username+" <"+doc.email+">", // comma separated list of receivers
                       subject: "information updated successfully", // Subject line
                       html: "Hello "+doc.username+"<br/>your information has been updated successfully by Admin" // plaintext body
                    }, function(error, response){
                       if(error){
                           console.log(error);
                       }else{
                           console.log("Message sent");
                       }
                    });

                    user_model.findOne({ _id:req.params.userId},{}, function(err, result){
                        if(err){
                            return res.send({success:0,data:err});
                        }else{
                            return res.send({success:1,data:result});  
                        }
                    })

                   // return res.send({success:1,data:"successfully changed"});  
                }
                else
                {
                    return res.send({success:0,data:doc});
                }
                
            } 
                
        });
    });

    /*chaneg Password by admin Added by Rashmi sharma 25-08-2015*/
    router.put('/admin/user/changePassword/:userID/:password',function(req,res)
    {

        user_model.findOneAndUpdate({ _id:req.params.userID},{ password:md5(req.params.password) }, {upsert:false},function(err,doc)
        {
            if(err) 
            { 
                return res.send({success:0,data:err});
            }
            else
            {
                
                if(doc!=null)
                {
                    smtpTransport.sendMail({
                       from: "Mobirummy <mobirummy@kiozen.com>", // sender address
                       to: doc.username+" <"+doc.email+">", // comma separated list of receivers
                       subject: "Password Changed Successfully By admin", // Subject line
                       text: "Your Password has been changed successfully" // plaintext body
                    }, function(error, response){
                       if(error){
                           console.log(error);
                       }else{
                           console.log("Message sent: ");
                       }
                    });
                    return res.send({success:1,data:"successfully changed"});
                }
                else
                {
                    return res.send({success:0,data:doc});
                }
                    
                
            }
        });
    });

};



