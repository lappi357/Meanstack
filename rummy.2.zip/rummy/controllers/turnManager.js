module.exports = function(){

	startMatch	=	function (match_id)
	{
		if(typeof ios!='undefined')
		{
			main.io=ios;
		}
	    if(main.match_counter[match_id])
	    {
	    	////console.log('counter working');
	        clearInterval(main.match_counter[match_id]);
	    }
	      
	    //main.clients       =    clients;
	   	/*match starting*/
	       
	   
	    ////console.log('timer working');
		
	    ////console.log('interval working');
	    match.findOne({_id:match_id },{}, function (err, doc)
	    {
		    if(doc.match_current_player==(doc.match_join_users.length-1))
			{
				new_match_current_player	=	0;
			}
			else
			{
				new_match_current_player =doc.match_current_player+1;
			}
			
			match.update({_id:match_id},{match_current_player:new_match_current_player,match_declare:[],'match_turn_status':0,$inc:{'turn_counter':1}},function(err)
			{
				if(err)
				{
					////console.log(err);
				}
				else
				{
					console.log(doc.match_deck_open);   
					if(doc.match_deck_open!=null)
					{
						if(doc.match_deck_open.constructor=== Array)
						{
							var open_card	=	{card_value:doc.match_deck_open[doc.match_deck_open.length-1],card_face:main.getCardImage(doc.match_deck_open[doc.match_deck_open.length-1])};
							
						}
						else
						{
							var open_card	=	{card_value:doc.match_deck_open,card_face:main.getCardImage(doc.match_deck_open)};
						}
					}
					else
					{
						var open_card	=	{card_value:doc.match_deck_open,card_face:main.getCardImage(doc.match_deck_open)};
					}
						

	           		var match_deck_open=[];
					match_deck_open[0]=[];
					if(doc.match_deck_open.constructor=== Array)
					{
						var i=0;		
						
						
						for(card in doc.match_deck_open)
						{
							
							match_deck_open[0][card]	={card_value:doc.match_deck_open[card],card_face:main.getCardImage(doc.match_deck_open[card])};	
							
							
						}
					}
					else
					{
						match_deck_open[0][0]	=	{card_value:doc.match_deck_open,card_face:main.getCardImage(doc.match_deck_open)}; 
					}

		            var roomName=doc._id+doc.match_join_users[new_match_current_player];  
		            main.io.to(roomName).emit('turn',{message:doc.match_join_users[new_match_current_player],open_card:open_card,match_deck_open:match_deck_open});
					var current_user_id=doc.match_join_users[new_match_current_player];
		            var temp_users=[];
		            temp_users=doc.match_join_users;

		            
		           
		           	temp_users.splice(new_match_current_player,1);
			           
		            for(var temp_k=0; temp_k<temp_users.length;temp_k++)
		            {
		            	/*if(temp_k!=new_match_current_player)
		            	{*/
		            		
			            	var temp_roomname=doc._id+temp_users[temp_k];  
			            	console.log('start temp count start');
			            	console.log(temp_roomname);
			            	console.log(' start temp count end');
			            	main.io.to(temp_roomname).emit('turn',{message:current_user_id,open_card:open_card,match_deck_open:match_deck_open});
			            		
		            	/*}*/
		            	
		            } 
		           	
					
					 
					
				}
			});
			
		});
	   
	    /*match ending*/
	         
	         
	    main.match_counter[match_id]      =   setInterval(function()
		{
	             
		  
			match.findOne({_id:match_id },{}, function (err, doc){
	             
			    ////console.log('timer working');
				console.log('current player'+doc.match_current_player);
				if(doc.match_current_player==(doc.match_join_users.length-1))
				{
					new_match_current_player	=	0;
				}
				else
				{
					new_match_current_player =doc.match_current_player+1;
				}
		            ////console.log('interval working');
		        var previous_user=doc.match_current_player;
					
				match.update({_id:match_id},{'match_current_player':new_match_current_player,'match_turn_status':0,$inc:{'turn_counter':1}},function(err)
				{
					if(err)
					{
						////console.log(err);
					}
					else
					{
						   
						var match_last_moved_card=doc.match_last_moved_card;
	               		
	               		var total_cards=0;
	               		for(var i=0 ; i<=6;i++)
	           			{
	           				
	           				if (doc.match_player_card[previous_user][i]!=null)
							{
							  total_cards=total_cards+doc.match_player_card[previous_user][i].length;
							}
	           			}
	           			
	               		if(total_cards>13)
	               		{
	               			for(var i=0 ; i<=6;i++)
	               			{
	               				var arr=doc.match_player_card[previous_user][i];
	               				if (doc.match_player_card[previous_user][i]!=null)
								{
								  
									console.log(doc.match_player_card[previous_user][i].indexOf(match_last_moved_card));
		               				if (doc.match_player_card[previous_user][i].indexOf(match_last_moved_card)!=-1)
									{
									  // found it
									  	doc.match_player_card[previous_user][i].splice(doc.match_player_card[previous_user][i].indexOf(match_last_moved_card),1);
									  	if(doc.match_deck_open.constructor=== Array)
										{ 
											doc.match_deck_open.push(match_last_moved_card);
										}
										else
										{
											if(doc.match_deck_open!=null || doc.match_deck_open!='')
											{
												var temp_match_deck_open=doc.match_deck_open;
												doc.match_deck_open=[];
												doc.match_deck_open.push(temp_match_deck_open);
												doc.match_deck_open.push(match_last_moved_card);
											}
											

											doc.match_deck_open	=	[match_last_moved_card];
										}

										match.update({_id:match_id},{match_player_card:doc.match_player_card,match_deck_open:doc.match_deck_open},function(err)
										{
											if(err)
											{
												////console.log(err);
											}
											else
											{
												console.log('player id'+doc.match_join_users[previous_user]);
												console.log(doc.match_player_card[previous_user]);
												var roomName=doc._id+doc.match_join_users[previous_user];   
												if(typeof doc.match_player_card[previous_user] !='undefined' || doc.match_player_card[previous_user]!=null)
												{
													var cards=[];

													for(group in doc.match_player_card[previous_user])
													{
															
														//		////console.log(matchResult.match_player_card[player_id][group]);
														//////console.log(group);
															
														var i=0;		
														if(!cards[group])
														{
															cards[group]	=	[];
														}
														for(card in doc.match_player_card[previous_user][group])
														{
															
															cards[group][card]	={card_value:doc.match_player_card[previous_user][group][card],card_face:main.getCardImage(doc.match_player_card[previous_user][group][card])};	
															
															
														}
														
													
													}
													setTimeout(function()
													{
														main.io.to(roomName).emit('update_card',{cards:cards});
													},1000);
													
												}


												
			
											}
											
										});
									  break;
									}
								}
	               			}
	               		}


	               		match.findOne({_id:match_id },{}, function (err, doc){

	               			if(err)
	               			{

	               			}
	               			else
	               			{
	               				if(doc!=null)
	               				{
	               					if(doc.match_deck_open.constructor=== Array)
									{
										var open_card	=	{card_value:doc.match_deck_open[doc.match_deck_open.length-1],card_face:main.getCardImage(doc.match_deck_open[doc.match_deck_open.length-1])};
										
									}
									else
									{
										var open_card	=	{card_value:doc.match_deck_open,card_face:main.getCardImage(doc.match_deck_open)};
									}

									var roomName=doc._id+doc.match_join_users[new_match_current_player];  
					                var emit_status=findClientsSocket(roomName,main.io);
					               
									var match_deck_open=[];
									match_deck_open[0]=[];
									if(doc.match_deck_open.constructor=== Array)
									{
										var i=0;		
										
										
										for(card in doc.match_deck_open)
										{
											
											match_deck_open[0][card]	={card_value:doc.match_deck_open[card],card_face:main.getCardImage(doc.match_deck_open[card])};	
											
											
										}
									}
									else
									{
										match_deck_open[0][0]	=	{card_value:doc.match_deck_open,card_face:main.getCardImage(doc.match_deck_open)}; 
									}

					                main.io.to(roomName).emit('turn',{message:doc.match_join_users[new_match_current_player],open_card:open_card,match_deck_open:match_deck_open});
									
									var current_user_id=doc.match_join_users[new_match_current_player];
					                var temp_users=[];
						            temp_users=doc.match_join_users;

						            
						           
						           	temp_users.splice(new_match_current_player,1);

						           	if(emit_status==0)
									{
										for(var temp_k=0; temp_k<temp_users.length;temp_k++)
							            {
							            	
							            	var temp_roomname=doc._id+temp_users[temp_k];  
							            	
							            	main.io.to(temp_roomname).emit('disconnectUserInfo',{message:current_user_id});
							            		
						            		
							            	
							            } 
									}


						

						            for(var temp_k=0; temp_k<temp_users.length;temp_k++)
						            {
						            	/*if(temp_k!=new_match_current_player)
						            	{*/
						            		console.log('temp count start');
							            	console.log(current_user_id);
							            	console.log('temp count end');
							            	var temp_roomname=doc._id+temp_users[temp_k];  
							            	main.io.to(temp_roomname).emit('turn',{message:current_user_id,open_card:open_card,match_deck_open:match_deck_open});
							            		
						            	/*}*/
						            	
						            } 


	               				}
	               			}


	               		});
	 	 			}
				});
			
			
			});
	             
		},30000);
	    
	         /*
	    var updateFields    =   {};
	    
	    updateFields.turnInterval   =   new_turnInterval;
	     ////console.log(new_turnInterval);
	    
	         /*
	    match.findOne({ '_id': '54804e66b6ae70624a2607e9' },updateFields, function (err, doc){
	    ////console.log('timer added');
	    });
	    */
	    
	    
	};
}