var express = require('express');
var router = express.Router();
var walletTransactionDetail_model  =   require(process.cwd()+'/models/walletTransactionDetail.js');

var wallet_model  =   require(process.cwd()+'/models/wallet.js');
var walletWithdrawRequest_model  =   require(process.cwd()+'/models/walletWithdrawRequest.js');
var user_model  =   require(process.cwd()+'/models/user_model.js');
var smtpTransport =require('../mailSettings.js');
var wallet    =   {};

module.exports = function(router)
{
    /*Add cash into user wallet Added by Rashmi Sharma on 3-08-2015*/
    router.get('/wallet/getWalletAmountByuid',function(req,res)
    {
                
        wallet_model.findOne({ userId:req.query.userId}, {},function (err, userDoc) {

            if(err)
            {
                res.send({success:0,data:err});

            }
            else
            {
                res.send({success:1,data:userDoc});
            }

        }); 
    });

     /*get user wallet amount detail Added by Rashmi Sharma on 3-08-2015*/
    router.post('/wallet/addCashUserWalletByAdmin',function(req,res)
    {
        var walletTransactionDetail    =   new walletTransactionDetail_model({userId:req.body.userId,amount:req.body.amount,currency:req.body.currency,paymentMethod:req.body.paymentMethod,transactionType:req.body.transactionType});
        walletTransactionDetail.save(function (err,doc)
        {
            if(err)
            {
                res.send({success:0,data:err});
            }
            else
            {
                res.send({success:1,data:doc});
            }
        });
    });

    /*send request to admin for Withdrawing cash (Step one)  Added by Rashmi Sharma on 5-08-2015*/
    router.post('/wallet/withdrawRequestStepOne',function(req,res)
    {
        var datetime = new Date();
        var walletWithdrawRequest    =   new walletWithdrawRequest_model({userId:req.body.userId,firstName:req.body.firstName,lastName:req.body.lastName,dob:req.body.dob,addressLine1:req.body.addressLine1,addressLine2:req.body.addressLine2,city:req.body.city,state:req.body.state,pincode:req.body.pincode,mobileno:req.body.mobileno,status:'process',createTime:datetime});
        walletWithdrawRequest.save(function (err,doc)
        {
            if(err)
            {
                res.send({success:0,data:err});
            }
            else
            {
                res.send({success:1,data:doc});
            }
        });
    });

    /*send request  for Withdrawing cash (step 2)  Added by Rashmi Sharma on 5-08-2015*/
    router.put('/wallet/withdrawRequestStepTwo',function(req,res)
    {
        
        
        var datetime = new Date();
        walletWithdrawRequest_model.findOneAndUpdate({ _id:req.body.requestId},{ withdrawType:req.body.withdrawType,accountHolderName:req.body.accountHolderName,accountNumber:req.body.accountNumber,MICRCode:req.body.MICRCode,IFSCCode:req.body.IFSCCode,bankName:req.body.bankName,branchName:req.body.branchName,amount:req.body.amount ,createTime:datetime,status:'pending'}, {upsert:false},function(err,doc)
        {
            if(err) 
            { 
                return res.send({success:0,data:err});
            }
            else
            {
                
                if(doc!=null)
                {

                    user_model.findOne({ _id:doc.userId}, {},function (err, userDoc)
                    {

                        if(err)
                        {
                            console.log(err);
                        }
                        else
                        {
                            var userId=userDoc._id;
                            var userEmail=userDoc.email;
                            var firstname=userDoc.firstname;
                            smtpTransport.sendMail({
                               from: "Mobirummy <mobirummy@kiozen.com>", // sender address
                               to: firstname+" <"+userEmail+">", // comma separated list of receivers
                               subject: "Withdraw Request sent Successfully", // Subject line
                               html: " we have successfully sent  withdraw request to admin  "// plaintext body
                            }, function(error, response){
                               if(error){
                                   console.log(error);
                               }else{
                                   console.log(response);
                               }
                            }); 

                        }
                    });
                }
                return res.send({success:1,data:doc});

            }
        });


    });
    
    /*get Withdrawl Status  Added by Rashmi Sharma on 5-08-2015*/
    router.get('/wallet/getWithdrawlStatus',function(req,res)
    {
        
        walletWithdrawRequest_model.find({ userId: req.query.userId}, {},function (err, result)
        {
        
            if(err)
            {
                res.send({success:0,data:err});
                /*cb({success:0,data:err});*/
                    
            }
            else
            {
                
                res.send({success:1,data:result});
                
            }
        
        });
    });


    /*get Withdrawl request details by Status and userId  Added by Rashmi Sharma on 10-08-2015*/
    router.get('/wallet/getWddetailsByuidAndSts',function(req,res)
    {
        
        walletWithdrawRequest_model.findOne({ userId: req.query.userId,status: req.query.wdstatus}, {},function (err, result)
        {
        
            if(err)
            {
                res.send({success:0,data:err});
                    
            }
            else
            {
                
                res.send({success:1,data:result});
                
            }
        
        });
    });

     /*get pending Withdrawl request by raghvendra singh 08-09-2015 */
    router.get('/wallet/getDisApprovedReq',function(req,res)
    {
        
        walletWithdrawRequest_model.find({status:'disapproved'},function (err, result)
        {
        
            if(err)
            {
                res.send({success:0,data:err});
                    
            }
            else
            {
                
                res.send({success:1,data:result});
                
            }
        
        });
    });

         /*get pending Withdrawl request by raghvendra singh 08-09-2015 */
    router.get('/wallet/getWithdrawlbyStsNType',function(req,res)
    {
        console.log(req.query.wstatus);
        walletWithdrawRequest_model.find({status:req.query.wstatus, withdrawType:req.query.withdrawType},function (err, result)
        {
        
            if(err)
            {
                res.send({success:0,data:err});
                    
            }
            else
            {
                console.log(result);
                res.send({success:1,data:result});
                
            }
        
        });
    });

     /*get approved Withdrawl request by raghvendra singh 08-09-2015 */
    router.get('/wallet/getApprovedReq',function(req,res)
    {
        
        walletWithdrawRequest_model.find({status:'approved'},function (err, result)
        {
        
            if(err)
            {
                res.send({success:0,data:err});
                    
            }
            else
            {
                
                res.send({success:1,data:result});
                
            }
        
        });
    });

    /*deduct amount from user wallet Added by Rashmi Sharma on 26-08-2015*/
    router.post('/wallet/deductAmtWltByuid',function(req,res)
    {
        


        var userId=req.body.userId;
        var walletdeductAmount=req.body.amount;
        /*Get user info by user Id*/
        user_model.findOne({ _id:userId}, {},function (err, userDoc) {

            if(err)
            {
                console.log(err);
                return res.send(err);
            }
            else
            {
                var userId=userDoc._id;
                var userEmail=userDoc.email;
                var firstname=userDoc.firstname;
                wallet_model.findOne({ userId:userId}, {},function (err, userDoc) {


                    var amount=0;
                    if(userDoc==null)
                    {
                        amount=0;

                    }
                    else
                    {
                        if(parseFloat(userDoc.amount)>=parseFloat(walletdeductAmount))
                        {
                            amount=parseFloat(walletdeductAmount);
                        }
                        else
                        {
                            return res.send('You do not have enough amount');
                        }

                        var walletTransactionDetail    =   new walletTransactionDetail_model({userId:req.body.userId,amount:req.body.amount,currency:req.body.currency,transactionType:'Debit'});
                        walletTransactionDetail.save(function (err,doc)
                        {
                            if(err)
                            {
                                res.send({success:0,data:err});
                            }
                            else
                            {
                                res.send({success:1,data:doc});
                            }
                        });
                        
                    }

                    
                });

            }
        });


    });

    /*approve or disapprove user withdraw request Added by Rashmi Sharma on 26-08-2015*/
    router.put('/wallet/changeWithdrawReqSts',function(req,res)
    {
        var datetime = new Date();
        var status=req.body.wdstatus;
        walletWithdrawRequest_model.findOneAndUpdate({_id:req.body.wdReqId},{status:req.body.wdstatus,createTime:datetime},function (err,doc)
        {
            if(err)
            {
                return res.send({success:0,data:err});
            }
            else
            {
                if(doc!=null)
                {
                   /*Get user info by user Id*/
                    user_model.findOne({ _id:doc.userId}, {},function (err, userDoc) {

                        if(err)
                        {
                            
                            return res.send(err);
                        }
                        else
                        {
                            if(userDoc!=null)
                            {
                                var userId=userDoc._id;
                                var userEmail=userDoc.email;
                                var firstname=userDoc.firstname;
                                if(status=="approved")
                                {
                                    smtpTransport.sendMail({
                                       from: "Mobirummy <mobirummy@kiozen.com>", // sender address
                                       to: firstname+" <"+userEmail+">", // comma separated list of receivers
                                       subject: "Withdraw request approved successfully", // Subject line
                                       html: " Withdraw request has been approved by admin" // plaintext body
                                    }, function(error, response){
                                       if(error){
                                           console.log(error);
                                       }else{
                                           console.log(response);
                                       }
                                    }); 
                                }else if(status=="disapproved")
                                {
                                    smtpTransport.sendMail({
                                       from: "Mobirummy <mobirummy@kiozen.com>", // sender address
                                       to: firstname+" <"+userEmail+">", // comma separated list of receivers
                                       subject: "Withdraw request disapproved", // Subject line
                                       html: " Withdraw request has been disapproved by admin" // plaintext body
                                    }, function(error, response){
                                       if(error){
                                           console.log(error);
                                       }else{
                                           console.log(response);
                                       }
                                    }); 
                                }
                            }
                            
                            

                        }
                    }); 
                }
                return res.send({success:1,data:doc});
            }
        });
    });



};