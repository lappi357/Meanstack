var urlencode = require('urlencode');
var clubTournaments_model  =   require(process.cwd()+'/models/clubTournaments.js');
var cashTournaments_model  =   require(process.cwd()+'/models/cashTournaments.js');
var specialTournaments_model  =   require(process.cwd()+'/models/specialTournaments.js');
var beginnersTournaments_model  =   require(process.cwd()+'/models/beginnersTournaments.js');
var weekendlootTournaments_model  =   require(process.cwd()+'/models/weekendlootTournaments.js');
var rewardpointsTournaments_model  =   require(process.cwd()+'/models/rewardpointsTournaments.js');
var jackpotsTournaments_model  =   require(process.cwd()+'/models/jackpotsTournaments.js');
var tournamentsFilters_model  =   require(process.cwd()+'/models/tournaments_filters.js');


module.exports = function(router)
{
   
    /*Add club tournament added by Rashmi Sharma 05-08-2015*/
    router.post('/tournament/addClubTournament',function(req,res)
    {
        var allPrizeList=req.body.allPrizeList;
        var clubTournaments    =   new clubTournaments_model({tournamentName:req.body.tournamentName,matchId:req.body.matchId,entryFee:req.body.entryFee,maxPlayersPerTable:req.body.maxPlayersPerTable,maxRegistartions:req.body.maxRegistartions,registrationStart:req.body.registrationStart,registrationClose:req.body.registrationClose,tournamentStart:req.body.tournamentStart,estimatedDuration:req.body.estimatedDuration,prizeType:req.body.prizeType,totalRounds:req.body.totalRounds,allPrizeList:allPrizeList,currency:req.body.currency,tournamentStatus:'running'});
        clubTournaments.save(function (err,doc)
        {
            if(err)
            {
                res.send({success:0,data:err});
            }
            else
            {
                res.send({success:1,data:"successfully added"});
            }
        });
    });

    /*edit club tournament added by Rashmi Sharma 25-08-2015*/
    router.put('/tournament/updateClubTournament',function(req,res)
    {
        var allPrizeList=req.body.allPrizeList;
        clubTournaments_model.findOneAndUpdate({_id:req.body.tournamentId},{tournamentName:req.body.tournamentName,matchId:req.body.matchId,entryFee:req.body.entryFee,maxPlayersPerTable:req.body.maxPlayersPerTable,maxRegistartions:req.body.maxRegistartions,registrationStart:req.body.registrationStart,registrationClose:req.body.registrationClose,tournamentStart:req.body.tournamentStart,estimatedDuration:req.body.estimatedDuration,prizeType:req.body.prizeType,totalRounds:req.body.totalRounds,allPrizeList:allPrizeList,currency:req.body.currency,tournamentStatus:req.body.tournamentStatus},function (err,doc)
        {
            if(err)
            {
                res.send({success:0,data:err});
            }
            else
            {
                if(doc!=null)
                {
                    clubTournaments_model.findOne({_id:doc._id},{}, function(err, result){
                        if(err){
                            res.send({success:0,data:err});               
                        }else{
                            res.send({success:1,data:result});      
                        }
                    });
                    //res.send({success:1,data:doc});
                }
                else
                {
                    res.send({success:0,data:"not found"});
                }
                
            }
        });
    });
    /*delete tournaments Added by Rashmi Sharma on 25-08-2015*/
    router.get('/tournament/deleteClubTournament/:tournamentId',function(req,res)
    {
        
        clubTournaments_model.remove({_id:req.params.tournamentId},function (err,doc)
        {
            if(err)
            {
                res.send({success:0,data:err});
            }
            else
            {
                if(doc!=null)
                {
                    res.send({success:1,data:"successfully deletd"});
                }
                else
                {
                    res.send({success:0,data:"not found"});
                }
                
            }
        });
    });

    /*Filter club tournaments  added by Rashmi Sharma 05-08-2015*/
    router.post('/tournament/filterClubTournaments',function(req,res)
    {
        

        //var filters=JSON.parse(req.body.filters);
        var filters=req.body.filters;
        
        var entryQuery1={};
        var prizeQuery1={};
        var otherQuery1={};
        var tempArrEntry = [];
        var tempArrPrize = [];
        var tempArrOther = [];
        var count=0;
        getFilters(req.body.filters,function(entryQuery,prizeQuery,otherQuery)
        {
            count++;
            
            console.log('get filters entryQuery start');
        	console.log(entryQuery);
        	console.log('get filters entryQuery end');
            if(entryQuery.hasOwnProperty('entryFee'))
            {
                
            	tempArrEntry.push(entryQuery);
            	console.log('entryQuery start');
            	console.log(tempArrEntry);
            	console.log(entryQuery);
            	console.log('entryQuery end');
                //entryQuery1.$or=tempArrEntry;

                /*if(entryQuery1)
                {

                    //entryQuery1.$or.push(entryQuery);
                    tempArr.push(entryQuery);
                    entryQuery1.$or=tempArr;

                }
                else
                {

                   entryQuery1.$or.push(entryQuery);
                }*/
            }
            if(otherQuery.hasOwnProperty('tournamentStatus'))
            {
                tempArrOther.push(otherQuery);
                //otherQuery1.$or=tempArrOther;
                /*if(otherQuery1)
                {
                	tempArrOther.push(otherQuery);
                    otherQuery1.$or=tempArrOther;
                }
                else
                {

                    otherQuery1.$or.push(otherQuery);
                }*/
            }
            if(prizeQuery.hasOwnProperty('prizeType'))
            {
                
            	tempArrPrize.push(prizeQuery);
            	//prizeQuery1.$or=tempArrPrize;
               /* if(prizeQuery1)
                {

                    prizeQuery1=prizeQuery1.$or.push(prizeQuery);
                }
                else
                {

                    prizeQuery1=prizeQuery1.$or.push(prizeQuery);
                }*/
            }
            
            
            
            
            if(parseInt(filters.length)==count)
            {
            
               	if(tempArrEntry.length>0)
                {
                    entryQuery1.$or=tempArrEntry;
                }
                if(tempArrOther.length>0)
                {
                    otherQuery1.$or=tempArrOther;
                }
                if(tempArrPrize.length>0)
                {
                   prizeQuery1.$or=tempArrPrize; 
                }
                
               	
               	
                var filterQueries=[];
                filterQueries.push(entryQuery1);
                filterQueries.push(otherQuery1);
                filterQueries.push(prizeQuery1);
                
	            

	            var query={$and:[]};
                    
                        
                query.$and=filterQueries;
                
                //console.log(JSON.parse(JSON.stringify(query)));
                //res.send(query);

               
                //console.log(JSON.stringify(filterQueries));
               
               /* return  res.send(JSON.stringify(query));*/
                clubTournaments_model.find(query, {},function (err, result)
                {
                
                    if(err)
                    {
                        return res.send({success:0,data:err});
                            
                    }
                    else
                    {
                      
                        if(result!=null)
                        {

                           return res.send({success:1,data:result});
                           
                        }
                        else
                        {
                           return res.send({success:0,data:"Not Found"});
                        }
                    }
                
                });




               /* builtQuery(entryQuery1,prizeQuery1,otherQuery1,function(filterQueries)
                {
                    var query={$and:[]};
                    if(filterQueries)
                    {
                        
                        query.$and=[filterQueries];
                    }
                   
                    console.log('filter tournament query start');
                    console.log(query);
                    console.log('filter tournament query end');
                    return  res.send(JSON.stringify(filterQueries));
                    clubTournaments_model.find(query, {},function (err, result)
                    {
                    
                        if(err)
                        {
                            return res.send({success:0,data:err});
                                
                        }
                        else
                        {
                          
                            if(result!=null)
                            {

                               return res.send({success:1,data:result});
                               
                            }
                            else
                            {
                               return res.send({success:0,data:"Not Found"});
                            }
                        }
                    
                    });

                });*/
                


            }
            
           

        });
        
    });


    /*get all club tournaments*/
    router.get('/tournament/getAllClubTournaments',function(req,res)
    {
       
        clubTournaments_model.find({}, {},function (err, result)
        {
        
            if(err)
            {
                res.send({success:0,data:err});
                    
            }
            else
            {
              
                if(result!=null)
                {

                    res.send({success:1,data:result});
                   
                }
                else
                {
                    res.send({success:1,data:result});
                }
            }
        
        });

    });

    /*get club tournament detail by id*/
    router.get('/tournament/getClubTournaments/:tournamentId',function(req,res)
    {
       
        clubTournaments_model.findOne({_id:req.params.tournamentId}, {},function (err, result)
        {
        
            if(err)
            {
                res.send({success:0,data:err});
                    
            }
            else
            {
              
                if(result!=null)
                {

                    res.send({success:1,data:result});
                   
                }
                else
                {
                    res.send({success:1,data:result});
                }
            }
        
        });

    });

    /*Add filters added by rashmi sharma 07-08-2015*/
    router.post('/tournament/addFilter',function(req,res){

        var tournamentsFilters    =   new tournamentsFilters_model({filterName:req.body.fltName,value:req.body.fltValue,filterType:req.body.fltType});
        tournamentsFilters.save(function (err,doc)
        {
            if(err)
            {
                res.send({success:0,data:err});
            }
            else
            {
                res.send({success:1,data:"successfully added"});
            }
        });

    });


    /*add cash tournament added by Rashmi Sharma 10-08-2015*/
    router.post('/tournament/addCashTournament',function(req,res)
    {
        var allPrizeList=req.body.allPrizeList;
        var cashTournaments    =   new cashTournaments_model({tournamentName:req.body.tournamentName,matchId:req.body.matchId,entryFee:req.body.entryFee,maxPlayersPerTable:req.body.maxPlayersPerTable,maxRegistartions:req.body.maxRegistartions,registrationStart:req.body.registrationStart,registrationClose:req.body.registrationClose,tournamentStart:req.body.tournamentStart,estimatedDuration:req.body.estimatedDuration,prizeType:req.body.prizeType,totalRounds:req.body.totalRounds,allPrizeList:allPrizeList,currency:req.body.currency,tournamentStatus:'running'});
        cashTournaments.save(function (err,doc)
        {
            if(err)
            {
                res.send({success:0,data:err});
            }
            else
            {
                res.send({success:1,data:"successfully added"});
            }
        });
    });

    /*edit cash tournament added by Rashmi Sharma 25-08-2015*/
    router.put('/tournament/updateCashTournament',function(req,res)
    {
        var allPrizeList=req.body.allPrizeList;
        cashTournaments_model.findOneAndUpdate({_id:req.body.tournamentId},{tournamentName:req.body.tournamentName,matchId:req.body.matchId,entryFee:req.body.entryFee,maxPlayersPerTable:req.body.maxPlayersPerTable,maxRegistartions:req.body.maxRegistartions,registrationStart:req.body.registrationStart,registrationClose:req.body.registrationClose,tournamentStart:req.body.tournamentStart,estimatedDuration:req.body.estimatedDuration,prizeType:req.body.prizeType,totalRounds:req.body.totalRounds,allPrizeList:allPrizeList,currency:req.body.currency,tournamentStatus:req.body.tournamentStatus},function (err,doc)
        {
            if(err)
            {
                res.send({success:0,data:err});
            }
            else
            {
                if(doc!=null)
                {
                    res.send({success:1,data:"successfully updated"});
                }
                else
                {
                    res.send({success:0,data:"not found"});
                }
                
            }
        });
    });
    /*delete cash tournaments Added by Rashmi Sharma on 25-08-2015*/
    router.get('/tournament/deleteCashTournament/:tournamentId',function(req,res)
    {
        
        cashTournaments_model.remove({_id:req.params.tournamentId},function (err,doc)
        {
            if(err)
            {
                res.send({success:0,data:err});
            }
            else
            {
                if(doc!=null)
                {
                    res.send({success:1,data:"successfully deletd"});
                }
                else
                {
                    res.send({success:0,data:"not found"});
                }
                
            }
        });
    });

    /*get all cash tournaments*/
    router.get('/tournament/getAllCashTournaments',function(req,res)
    {
       
        cashTournaments_model.find({}, {},function (err, result)
        {
        
            if(err)
            {
                res.send({success:0,data:err});
                    
            }
            else
            {
              
                if(result!=null)
                {

                    res.send({success:1,data:result});
                   
                }
                else
                {
                    res.send({success:1,data:result});
                }
            }
        
        });

    });

    /*get cash tournament detail by id*/
    router.get('/tournament/getCashTournaments/:tournamentId',function(req,res)
    {
       
        cashTournaments_model.findOne({_id:req.params.tournamentId}, {},function (err, result)
        {
        
            if(err)
            {
                res.send({success:0,data:err});
                    
            }
            else
            {
              
                if(result!=null)
                {

                    res.send({success:1,data:result});
                   
                }
                else
                {
                    res.send({success:1,data:result});
                }
            }
        
        });

    });


    /*Filter cash tournaments  added by Rashmi Sharma 05-08-2015*/
    router.post('/tournament/filterCashTournaments',function(req,res)
    {
        

        //var filters=JSON.parse(req.body.filters);
        var filters=req.body.filters;
        
		var entryQuery1={};
        var prizeQuery1={};
        var otherQuery1={};
        var tempArrEntry = [];
        var tempArrPrize = [];
        var tempArrOther = [];

        var count=0;
        getFilters(req.body.filters,function(entryQuery,prizeQuery,otherQuery)
        {
            count++;
            

            if(entryQuery.hasOwnProperty('entryFee'))
            {
            	tempArrEntry.push(entryQuery);  
            }
            if(otherQuery.hasOwnProperty('tournamentStatus'))
            {
                tempArrOther.push(otherQuery);
            }
            if(prizeQuery.hasOwnProperty('prizeType'))
            { 
            	tempArrPrize.push(prizeQuery);
            }
            
 
            if(parseInt(filters.length)==count)
            {
                
                if(tempArrEntry.length>0)
                {
                    entryQuery1.$or=tempArrEntry;
                }
                if(tempArrOther.length>0)
                {
                    otherQuery1.$or=tempArrOther;
                }
                if(tempArrPrize.length>0)
                {
                   prizeQuery1.$or=tempArrPrize; 
                }
                /*entryQuery1.$or=tempArrEntry;
               	otherQuery1.$or=tempArrOther;
               	prizeQuery1.$or=tempArrPrize;*/
                var filterQueries=[];
                filterQueries.push(entryQuery1);
                filterQueries.push(otherQuery1);
                filterQueries.push(prizeQuery1);
	            var query={$and:[]};        
                query.$and=filterQueries;

                cashTournaments_model.find(query, {},function (err, result)
                {
                
                    if(err)
                    {
                        return res.send({success:0,data:err});
                            
                    }
                    else
                    {
                      
                        if(result!=null)
                        {

                           return res.send({success:1,data:result});
                           
                        }
                        else
                        {
                           return res.send({success:0,data:"Not Found"});
                        }
                    }
                
                });
                


            }
            
           

        });
        
    });

    /*Add club tournament added by Rashmi Sharma 24-08-2015*/
    router.post('/tournament/addspecialTournament',function(req,res)
    {
        var allPrizeList=req.body.allPrizeList;
        var specialTournaments    =   new specialTournaments_model({tournamentName:req.body.tournamentName,matchId:req.body.matchId,entryFee:req.body.entryFee,maxPlayersPerTable:req.body.maxPlayersPerTable,maxRegistartions:req.body.maxRegistartions,registrationStart:req.body.registrationStart,registrationClose:req.body.registrationClose,tournamentStart:req.body.tournamentStart,estimatedDuration:req.body.estimatedDuration,prizeType:req.body.prizeType,totalRounds:req.body.totalRounds,allPrizeList:allPrizeList,currency:req.body.currency,tournamentStatus:'running'});
        specialTournaments.save(function (err,doc)
        {
            if(err)
            {
                res.send({success:0,data:err});
            }
            else
            {
                res.send({success:1,data:"successfully added"});
            }
        });
    });



    /*edit special tournament added by Rashmi Sharma 25-08-2015*/
    router.put('/tournament/updateSpecialTournament',function(req,res)
    {
        var allPrizeList=req.body.allPrizeList;
        specialTournaments_model.findOneAndUpdate({_id:req.body.tournamentId},{tournamentName:req.body.tournamentName,matchId:req.body.matchId,entryFee:req.body.entryFee,maxPlayersPerTable:req.body.maxPlayersPerTable,maxRegistartions:req.body.maxRegistartions,registrationStart:req.body.registrationStart,registrationClose:req.body.registrationClose,tournamentStart:req.body.tournamentStart,estimatedDuration:req.body.estimatedDuration,prizeType:req.body.prizeType,totalRounds:req.body.totalRounds,allPrizeList:allPrizeList,currency:req.body.currency,tournamentStatus:req.body.tournamentStatus},function (err,doc)
        {
            if(err)
            {
                res.send({success:0,data:err});
            }
            else
            {
                if(doc!=null)
                {
                    res.send({success:1,data:"successfully updated"});
                }
                else
                {
                    res.send({success:0,data:"not found"});
                }
                
            }
        });
    });
    /*delete special tournament Added by Rashmi Sharma on 25-08-2015*/
    router.get('/tournament/deleteSpecialTournament/:tournamentId',function(req,res)
    {
        
        specialTournaments_model.remove({_id:req.params.tournamentId},function (err,doc)
        {
            if(err)
            {
                res.send({success:0,data:err});
            }
            else
            {
                if(doc!=null)
                {
                    res.send({success:1,data:"successfully deletd"});
                }
                else
                {
                    res.send({success:0,data:"not found"});
                }
                
            }
        });
    });


     /*get all cash tournaments*/
    router.get('/tournament/getAllSpecialTournament',function(req,res)
    {
       
        specialTournaments_model.find({}, {},function (err, result)
        {
        
            if(err)
            {
                res.send({success:0,data:err});
                    
            }
            else
            {
              
                if(result!=null)
                {

                    res.send({success:1,data:result});
                   
                }
                else
                {
                    res.send({success:1,data:result});
                }
            }
        
        });

    });

    /*get Special tournament detail by id*/
    router.get('/tournament/getSpecialTournaments/:tournamentId',function(req,res)
    {
       
        specialTournaments_model.findOne({_id:req.params.tournamentId}, {},function (err, result)
        {
        
            if(err)
            {
                res.send({success:0,data:err});
                    
            }
            else
            {
              
                if(result!=null)
                {

                    res.send({success:1,data:result});
                   
                }
                else
                {
                    res.send({success:1,data:result});
                }
            }
        
        });

    });

      /*Filter cash tournaments  added by Rashmi Sharma 05-08-2015*/
    router.post('/tournament/filterSpecialTournaments',function(req,res)
    {
        

        //var filters=JSON.parse(req.body.filters);
        var filters=req.body.filters;
       	var entryQuery1={};
        var prizeQuery1={};
        var otherQuery1={};
        var tempArrEntry = [];
        var tempArrPrize = [];
        var tempArrOther = [];
        var count=0;
        getFilters(req.body.filters,function(entryQuery,prizeQuery,otherQuery)
        {
            count++;
            

            if(entryQuery.hasOwnProperty('entryFee'))
            {
            	tempArrEntry.push(entryQuery); 
            }
            if(otherQuery.hasOwnProperty('tournamentStatus'))
            {
                tempArrOther.push(otherQuery);
            }
            if(prizeQuery.hasOwnProperty('prizeType'))
            {
            	tempArrPrize.push(prizeQuery);
            }
            
 
            if(parseInt(filters.length)==count)
            {
            
               	if(tempArrEntry.length>0)
                {
                    entryQuery1.$or=tempArrEntry;
                }
                if(tempArrOther.length>0)
                {
                    otherQuery1.$or=tempArrOther;
                }
                if(tempArrPrize.length>0)
                {
                   prizeQuery1.$or=tempArrPrize; 
                }

                /*entryQuery1.$or=tempArrEntry;
               	otherQuery1.$or=tempArrOther;
               	prizeQuery1.$or=tempArrPrize;*/
                var filterQueries=[];
                filterQueries.push(entryQuery1);
                filterQueries.push(otherQuery1);
                filterQueries.push(prizeQuery1);
	            var query={$and:[]};        
                query.$and=filterQueries;
                specialTournaments_model.find(query, {},function (err, result)
                {
                
                    if(err)
                    {
                        console.log(err);
                        return res.send({success:0,data:err});
                            
                    }
                    else
                    {
                      
                        if(result!=null)
                        {

                           return res.send({success:1,data:result});
                           
                        }
                        else
                        {
                           return res.send({success:0,data:"Not Found"});
                        }
                    }
                
                });
            }
            
           

        });
        
    });




    /*Add beginners tournament added by Rashmi Sharma 24-08-2015*/
    router.post('/tournament/addbeginnersTournament',function(req,res)
    {
        var allPrizeList=req.body.allPrizeList;
        var beginnersTournaments    =   new beginnersTournaments_model({tournamentName:req.body.tournamentName,matchId:req.body.matchId,entryFee:req.body.entryFee,maxPlayersPerTable:req.body.maxPlayersPerTable,maxRegistartions:req.body.maxRegistartions,registrationStart:req.body.registrationStart,registrationClose:req.body.registrationClose,tournamentStart:req.body.tournamentStart,estimatedDuration:req.body.estimatedDuration,prizeType:req.body.prizeType,totalRounds:req.body.totalRounds,allPrizeList:allPrizeList,currency:req.body.currency,tournamentStatus:'running'});
        beginnersTournaments.save(function (err,doc)
        {
            if(err)
            {
                res.send({success:0,data:err});
            }
            else
            {
                res.send({success:1,data:"successfully added"});
            }
        });
    });



    /*edit beginners tournament added by Rashmi Sharma 25-08-2015*/
    router.put('/tournament/updateBeginnersTournament',function(req,res)
    {
        var allPrizeList=req.body.allPrizeList;
        beginnersTournaments_model.findOneAndUpdate({_id:req.body.tournamentId},{tournamentName:req.body.tournamentName,matchId:req.body.matchId,entryFee:req.body.entryFee,maxPlayersPerTable:req.body.maxPlayersPerTable,maxRegistartions:req.body.maxRegistartions,registrationStart:req.body.registrationStart,registrationClose:req.body.registrationClose,tournamentStart:req.body.tournamentStart,estimatedDuration:req.body.estimatedDuration,prizeType:req.body.prizeType,totalRounds:req.body.totalRounds,allPrizeList:allPrizeList,currency:req.body.currency,tournamentStatus:req.body.tournamentStatus},function (err,doc)
        {
            if(err)
            {
                res.send({success:0,data:err});
            }
            else
            {
                if(doc!=null)
                {
                    res.send({success:1,data:"successfully updated"});
                }
                else
                {
                    res.send({success:0,data:"not found"});
                }
                
            }
        });
    });
    /*delete beginners tournament Added by Rashmi Sharma on 25-08-2015*/
    router.get('/tournament/deleteBeginnersTournament/:tournamentId',function(req,res)
    {
        
        beginnersTournaments_model.remove({_id:req.params.tournamentId},function (err,doc)
        {
            if(err)
            {
                res.send({success:0,data:err});
            }
            else
            {
                if(doc!=null)
                {
                    res.send({success:1,data:doc});
                }
                else
                {
                    res.send({success:0,data:"not found"});
                }
                
            }
        });
    });


     /*get all beginners tournaments*/
    router.get('/tournament/getAllBeginnersTournament',function(req,res)
    {
       
        beginnersTournaments_model.find({}, {},function (err, result)
        {
        
            if(err)
            {
                res.send({success:0,data:err});
                    
            }
            else
            {
              
                if(result!=null)
                {

                    res.send({success:1,data:result});
                   
                }
                else
                {
                    res.send({success:1,data:result});
                }
            }
        
        });

    });

    /*get beginners tournament detail by id*/
    router.get('/tournament/getBeginnersTournaments/:tournamentId',function(req,res)
    {
       
        beginnersTournaments_model.findOne({_id:req.params.tournamentId}, {},function (err, result)
        {
        
            if(err)
            {
                res.send({success:0,data:err});
                    
            }
            else
            {
              
                if(result!=null)
                {

                    res.send({success:1,data:result});
                   
                }
                else
                {
                    res.send({success:1,data:result});
                }
            }
        
        });

    });

     /*Filter beginners tournaments  added by Rashmi Sharma 15-09-2015*/
    router.post('/tournament/filterBeginnersTournaments',function(req,res)
    {
        

        //var filters=JSON.parse(req.body.filters);
        var filters=req.body.filters;
       	var entryQuery1={};
        var prizeQuery1={};
        var otherQuery1={};
        var tempArrEntry = [];
        var tempArrPrize = [];
        var tempArrOther = [];
        var count=0;
        getFilters(req.body.filters,function(entryQuery,prizeQuery,otherQuery)
        {
            count++;
            

            if(entryQuery.hasOwnProperty('entryFee'))
            {
            	tempArrEntry.push(entryQuery); 
            }
            if(otherQuery.hasOwnProperty('tournamentStatus'))
            {
                tempArrOther.push(otherQuery);
            }
            if(prizeQuery.hasOwnProperty('prizeType'))
            {
            	tempArrPrize.push(prizeQuery);
            }
            
 
            if(parseInt(filters.length)==count)
            {
            
               	
                if(tempArrEntry.length>0)
                {
                    entryQuery1.$or=tempArrEntry;
                }
                if(tempArrOther.length>0)
                {
                    otherQuery1.$or=tempArrOther;
                }
                if(tempArrPrize.length>0)
                {
                   prizeQuery1.$or=tempArrPrize; 
                }
               /* entryQuery1.$or=tempArrEntry;
               	otherQuery1.$or=tempArrOther;
               	prizeQuery1.$or=tempArrPrize;*/
                var filterQueries=[];
                filterQueries.push(entryQuery1);
                filterQueries.push(otherQuery1);
                filterQueries.push(prizeQuery1);
	            var query={$and:[]};        
                query.$and=filterQueries;
                beginnersTournaments_model.find(query, {},function (err, result)
                {
                
                    if(err)
                    {
                        console.log(err);
                        return res.send({success:0,data:err});
                            
                    }
                    else
                    {
                      
                        if(result!=null)
                        {

                           return res.send({success:1,data:result});
                           
                        }
                        else
                        {
                           return res.send({success:0,data:"Not Found"});
                        }
                    }
                
                });
            }
            
           

        });
        
    });

    /*Add weekendloot tournament added by Rashmi Sharma 25-08-2015*/
    router.post('/tournament/addweekendlootTournament',function(req,res)
    {
        var allPrizeList=req.body.allPrizeList;
        var weekendlootTournaments    =   new weekendlootTournaments_model({tournamentName:req.body.tournamentName,matchId:req.body.matchId,entryFee:req.body.entryFee,maxPlayersPerTable:req.body.maxPlayersPerTable,maxRegistartions:req.body.maxRegistartions,registrationStart:req.body.registrationStart,registrationClose:req.body.registrationClose,tournamentStart:req.body.tournamentStart,estimatedDuration:req.body.estimatedDuration,prizeType:req.body.prizeType,totalRounds:req.body.totalRounds,allPrizeList:allPrizeList,currency:req.body.currency,tournamentStatus:'running'});
        weekendlootTournaments.save(function (err,doc)
        {
            if(err)
            {
                res.send({success:0,data:err});
            }
            else
            {
                res.send({success:1,data:"successfully added"});
            }
        });
    });



    /*edit weekendloot tournament added by Rashmi Sharma 25-08-2015*/
    router.put('/tournament/updateWeekendlootTournament',function(req,res)
    {
        var allPrizeList=req.body.allPrizeList;
        weekendlootTournaments_model.findOneAndUpdate({_id:req.body.tournamentId},{tournamentName:req.body.tournamentName,matchId:req.body.matchId,entryFee:req.body.entryFee,maxPlayersPerTable:req.body.maxPlayersPerTable,maxRegistartions:req.body.maxRegistartions,registrationStart:req.body.registrationStart,registrationClose:req.body.registrationClose,tournamentStart:req.body.tournamentStart,estimatedDuration:req.body.estimatedDuration,prizeType:req.body.prizeType,totalRounds:req.body.totalRounds,allPrizeList:allPrizeList,currency:req.body.currency,tournamentStatus:req.body.tournamentStatus},function (err,doc)
        {
            if(err)
            {
                res.send({success:0,data:err});
            }
            else
            {
                if(doc!=null)
                {
                    res.send({success:1,data:"successfully updated"});
                }
                else
                {
                    res.send({success:0,data:"not found"});
                }
                
            }
        });
    });
    /*delete weekendloot tournament Added by Rashmi Sharma on 25-08-2015*/
    router.get('/tournament/deleteWeekendlootTournament/:tournamentId',function(req,res)
    {
        
        weekendlootTournaments_model.remove({_id:req.params.tournamentId},function (err,doc)
        {
            if(err)
            {
                res.send({success:0,data:err});
            }
            else
            {
                if(doc!=null)
                {
                    res.send({success:1,data:doc});
                }
                else
                {
                    res.send({success:0,data:"not found"});
                }
                
            }
        });
    });


     /*get all weekendloot tournaments*/
    router.get('/tournament/getAllWeekendlootTournament',function(req,res)
    {
       
        weekendlootTournaments_model.find({}, {},function (err, result)
        {
        
            if(err)
            {
                res.send({success:0,data:err});
                    
            }
            else
            {
              
                if(result!=null)
                {

                    res.send({success:1,data:result});
                   
                }
                else
                {
                    res.send({success:1,data:result});
                }
            }
        
        });

    });

    /*get weekendloot tournament detail by id*/
    router.get('/tournament/getWeekendlootTournaments/:tournamentId',function(req,res)
    {
       
        weekendlootTournaments_model.findOne({_id:req.params.tournamentId}, {},function (err, result)
        {
        
            if(err)
            {
                res.send({success:0,data:err});
                    
            }
            else
            {
              
                if(result!=null)
                {

                    res.send({success:1,data:result});
                   
                }
                else
                {
                    res.send({success:1,data:result});
                }
            }
        
        });

    });


    /*Filter Weekendloot tournaments  added by Rashmi Sharma 15-09-2015*/
    router.post('/tournament/filterWeekendlootTournaments',function(req,res)
    {
        

        //var filters=JSON.parse(req.body.filters);
        var filters=req.body.filters;
       	var entryQuery1={};
        var prizeQuery1={};
        var otherQuery1={};
        var tempArrEntry = [];
        var tempArrPrize = [];
        var tempArrOther = [];
        var count=0;
        getFilters(req.body.filters,function(entryQuery,prizeQuery,otherQuery)
        {
            count++;
            

            if(entryQuery.hasOwnProperty('entryFee'))
            {
            	tempArrEntry.push(entryQuery); 
            }
            if(otherQuery.hasOwnProperty('tournamentStatus'))
            {
                tempArrOther.push(otherQuery);
            }
            if(prizeQuery.hasOwnProperty('prizeType'))
            {
            	tempArrPrize.push(prizeQuery);
            }
            
 
            if(parseInt(filters.length)==count)
            {
            
               	/*entryQuery1.$or=tempArrEntry;
               	otherQuery1.$or=tempArrOther;
               	prizeQuery1.$or=tempArrPrize;*/
                if(tempArrEntry.length>0)
                {
                    entryQuery1.$or=tempArrEntry;
                }
                if(tempArrOther.length>0)
                {
                    otherQuery1.$or=tempArrOther;
                }
                if(tempArrPrize.length>0)
                {
                   prizeQuery1.$or=tempArrPrize; 
                }
                var filterQueries=[];
                filterQueries.push(entryQuery1);
                filterQueries.push(otherQuery1);
                filterQueries.push(prizeQuery1);
	            var query={$and:[]};        
                query.$and=filterQueries;
                weekendlootTournaments_model.find(query, {},function (err, result)
                {
                
                    if(err)
                    {
                        console.log(err);
                        return res.send({success:0,data:err});
                            
                    }
                    else
                    {
                      
                        if(result!=null)
                        {

                           return res.send({success:1,data:result});
                           
                        }
                        else
                        {
                           return res.send({success:0,data:"Not Found"});
                        }
                    }
                
                });
            }
            
           

        });
        
    });

    /*Add rewardpoints tournament added by Rashmi Sharma 25-08-2015*/
    router.post('/tournament/addrewardpointsTournament',function(req,res)
    {
        var allPrizeList=req.body.allPrizeList;
        var rewardpointsTournaments    =   new rewardpointsTournaments_model({tournamentName:req.body.tournamentName,matchId:req.body.matchId,entryFee:req.body.entryFee,maxPlayersPerTable:req.body.maxPlayersPerTable,maxRegistartions:req.body.maxRegistartions,registrationStart:req.body.registrationStart,registrationClose:req.body.registrationClose,tournamentStart:req.body.tournamentStart,estimatedDuration:req.body.estimatedDuration,prizeType:req.body.prizeType,totalRounds:req.body.totalRounds,allPrizeList:allPrizeList,currency:req.body.currency,tournamentStatus:'running'});
        rewardpointsTournaments.save(function (err,doc)
        {
            if(err)
            {
                res.send({success:0,data:err});
            }
            else
            {
                res.send({success:1,data:"successfully added"});
            }
        });
    });



    /*edit rewardpoints tournament added by Rashmi Sharma 25-08-2015*/
    router.put('/tournament/updateRewardpointsTournament',function(req,res)
    {
        var allPrizeList=req.body.allPrizeList;
        rewardpointsTournaments_model.findOneAndUpdate({_id:req.body.tournamentId},{tournamentName:req.body.tournamentName,matchId:req.body.matchId,entryFee:req.body.entryFee,maxPlayersPerTable:req.body.maxPlayersPerTable,maxRegistartions:req.body.maxRegistartions,registrationStart:req.body.registrationStart,registrationClose:req.body.registrationClose,tournamentStart:req.body.tournamentStart,estimatedDuration:req.body.estimatedDuration,prizeType:req.body.prizeType,totalRounds:req.body.totalRounds,allPrizeList:allPrizeList,currency:req.body.currency,tournamentStatus:req.body.tournamentStatus},function (err,doc)
        {
            if(err)
            {
                res.send({success:0,data:err});
            }
            else
            {
                if(doc!=null)
                {
                    res.send({success:1,data:"successfully updated"});
                }
                else
                {
                    res.send({success:0,data:"not found"});
                }
                
            }
        });
    });

    /*delete rewardpoints tournament Added by Rashmi Sharma on 25-08-2015*/
    router.get('/tournament/deleteRewardpointsTournament/:tournamentId',function(req,res)
    {
        
        rewardpointsTournaments_model.remove({_id:req.params.tournamentId},function (err,doc)
        {
            if(err)
            {
                res.send({success:0,data:err});
            }
            else
            {
                if(doc!=null)
                {
                    res.send({success:1,data:doc});
                }
                else
                {
                    res.send({success:0,data:"not found"});
                }
                
            }
        });
    });


     /*get all rewardpoints tournaments*/
    router.get('/tournament/getAllRewardpointsTournament',function(req,res)
    {
       
        rewardpointsTournaments_model.find({}, {},function (err, result)
        {
        
            if(err)
            {
                res.send({success:0,data:err});
                    
            }
            else
            {
              
                if(result!=null)
                {

                    res.send({success:1,data:result});
                   
                }
                else
                {
                    res.send({success:1,data:result});
                }
            }
        
        });

    });

    /*get rewardpoints tournament detail by id*/
    router.get('/tournament/getRewardpointsTournaments/:tournamentId',function(req,res)
    {
       
        rewardpointsTournaments_model.findOne({_id:req.params.tournamentId}, {},function (err, result)
        {
        
            if(err)
            {
                res.send({success:0,data:err});
                    
            }
            else
            {
              
                if(result!=null)
                {

                    res.send({success:1,data:result});
                   
                }
                else
                {
                    res.send({success:1,data:result});
                }
            }
        
        });

    });

    /*Filter Rewardpoints tournaments  added by Rashmi Sharma 15-09-2015*/
    router.post('/tournament/filterRewardpointsTournaments',function(req,res)
    {
        

        //var filters=JSON.parse(req.body.filters);
        var filters=req.body.filters;
       	var entryQuery1={};
        var prizeQuery1={};
        var otherQuery1={};
        var tempArrEntry = [];
        var tempArrPrize = [];
        var tempArrOther = [];
        var count=0;
        getFilters(req.body.filters,function(entryQuery,prizeQuery,otherQuery)
        {
            count++;
            

            if(entryQuery.hasOwnProperty('entryFee'))
            {
            	tempArrEntry.push(entryQuery); 
            }
            if(otherQuery.hasOwnProperty('tournamentStatus'))
            {
                tempArrOther.push(otherQuery);
            }
            if(prizeQuery.hasOwnProperty('prizeType'))
            {
            	tempArrPrize.push(prizeQuery);
            }
            
 
            if(parseInt(filters.length)==count)
            {
            
               	/*entryQuery1.$or=tempArrEntry;
               	otherQuery1.$or=tempArrOther;
               	prizeQuery1.$or=tempArrPrize;*/
                if(tempArrEntry.length>0)
                {
                    entryQuery1.$or=tempArrEntry;
                }
                if(tempArrOther.length>0)
                {
                    otherQuery1.$or=tempArrOther;
                }
                if(tempArrPrize.length>0)
                {
                   prizeQuery1.$or=tempArrPrize; 
                }
                var filterQueries=[];
                filterQueries.push(entryQuery1);
                filterQueries.push(otherQuery1);
                filterQueries.push(prizeQuery1);
	            var query={$and:[]};        
                query.$and=filterQueries;
                rewardpointsTournaments_model.find(query, {},function (err, result)
                {
                
                    if(err)
                    {
                        console.log(err);
                        return res.send({success:0,data:err});
                            
                    }
                    else
                    {
                      
                        if(result!=null)
                        {

                           return res.send({success:1,data:result});
                           
                        }
                        else
                        {
                           return res.send({success:0,data:"Not Found"});
                        }
                    }
                
                });
            }
            
           

        });
        
    });

    /*Add jackpots tournament added by Rashmi Sharma 25-08-2015*/
    router.post('/tournament/addjackpotsTournament',function(req,res)
    {
        var allPrizeList=req.body.allPrizeList;
        var jackpotsTournaments    =   new jackpotsTournaments_model({tournamentName:req.body.tournamentName,matchId:req.body.matchId,entryFee:req.body.entryFee,maxPlayersPerTable:req.body.maxPlayersPerTable,maxRegistartions:req.body.maxRegistartions,registrationStart:req.body.registrationStart,registrationClose:req.body.registrationClose,tournamentStart:req.body.tournamentStart,estimatedDuration:req.body.estimatedDuration,prizeType:req.body.prizeType,totalRounds:req.body.totalRounds,allPrizeList:allPrizeList,currency:req.body.currency,tournamentStatus:'running'});
        jackpotsTournaments.save(function (err,doc)
        {
            if(err)
            {
                res.send({success:0,data:err});
            }
            else
            {
                res.send({success:1,data:"successfully added"});
            }
        });
    });



    /*edit jackpots tournament added by Rashmi Sharma 25-08-2015*/
    router.put('/tournament/updateJackpotsTournament',function(req,res)
    {
        var allPrizeList=req.body.allPrizeList;
        jackpotsTournaments_model.findOneAndUpdate({_id:req.body.tournamentId},{tournamentName:req.body.tournamentName,matchId:req.body.matchId,entryFee:req.body.entryFee,maxPlayersPerTable:req.body.maxPlayersPerTable,maxRegistartions:req.body.maxRegistartions,registrationStart:req.body.registrationStart,registrationClose:req.body.registrationClose,tournamentStart:req.body.tournamentStart,estimatedDuration:req.body.estimatedDuration,prizeType:req.body.prizeType,totalRounds:req.body.totalRounds,allPrizeList:allPrizeList,currency:req.body.currency,tournamentStatus:req.body.tournamentStatus},function (err,doc)
        {
            if(err)
            {
                res.send({success:0,data:err});
            }
            else
            {
                if(doc!=null)
                {
                    res.send({success:1,data:"successfully updated"});
                }
                else
                {
                    res.send({success:0,data:"not found"});
                }
                
            }
        });
    });
    /*delete special tournament Added by Rashmi Sharma on 25-08-2015*/
    router.get('/tournament/deleteJackpotsTournament/:tournamentId',function(req,res)
    {
        
        jackpotsTournaments_model.remove({_id:req.params.tournamentId},function (err,doc)
        {
            if(err)
            {
                res.send({success:0,data:err});
            }
            else
            {
                if(doc!=null)
                {
                    res.send({success:1,data:doc});
                }
                else
                {
                    res.send({success:0,data:"not found"});
                }
                
            }
        });
    });


     /*get all jackpots tournaments*/
    router.get('/tournament/getAllJackpotsTournament',function(req,res)
    {
       
        jackpotsTournaments_model.find({}, {},function (err, result)
        {
        
            if(err)
            {
                res.send({success:0,data:err});
                    
            }
            else
            {
              
                if(result!=null)
                {

                    res.send({success:1,data:result});
                   
                }
                else
                {
                    res.send({success:1,data:result});
                }
            }
        
        });

    });

    /*get jackpots tournament detail by id*/
    router.get('/tournament/getJackpotsTournaments/:tournamentId',function(req,res)
    {
       
        jackpotsTournaments_model.findOne({_id:req.params.tournamentId}, {},function (err, result)
        {
        
            if(err)
            {
                res.send({success:0,data:err});
                    
            }
            else
            {
              
                if(result!=null)
                {

                    res.send({success:1,data:result});
                   
                }
                else
                {
                    res.send({success:1,data:result});
                }
            }
        
        });

    });

     /*Filter Jackpots tournaments  added by Rashmi Sharma 15-09-2015*/
    router.post('/tournament/filterJackpotsTournaments',function(req,res)
    {
        

        //var filters=JSON.parse(req.body.filters);
        var filters=req.body.filters;
       	var entryQuery1={};
        var prizeQuery1={};
        var otherQuery1={};
        var tempArrEntry = [];
        var tempArrPrize = [];
        var tempArrOther = [];
        var count=0;
        getFilters(req.body.filters,function(entryQuery,prizeQuery,otherQuery)
        {
            count++;
            

            if(entryQuery.hasOwnProperty('entryFee'))
            {
            	tempArrEntry.push(entryQuery); 
            }
            if(otherQuery.hasOwnProperty('tournamentStatus'))
            {
                tempArrOther.push(otherQuery);
            }
            if(prizeQuery.hasOwnProperty('prizeType'))
            {
            	tempArrPrize.push(prizeQuery);
            }
            
 
            if(parseInt(filters.length)==count)
            {
            
               	/*entryQuery1.$or=tempArrEntry;
               	otherQuery1.$or=tempArrOther;
               	prizeQuery1.$or=tempArrPrize;*/

                if(tempArrEntry.length>0)
                {
                    entryQuery1.$or=tempArrEntry;
                }
                if(tempArrOther.length>0)
                {
                    otherQuery1.$or=tempArrOther;
                }
                if(tempArrPrize.length>0)
                {
                   prizeQuery1.$or=tempArrPrize; 
                }
                var filterQueries=[];
                filterQueries.push(entryQuery1);
                filterQueries.push(otherQuery1);
                filterQueries.push(prizeQuery1);
	            var query={$and:[]};        
                query.$and=filterQueries;
                jackpotsTournaments_model.find(query, {},function (err, result)
                {
                
                    if(err)
                    {
                        console.log(err);
                        return res.send({success:0,data:err});
                            
                    }
                    else
                    {
                      
                        if(result!=null)
                        {

                           return res.send({success:1,data:result});
                           
                        }
                        else
                        {
                           return res.send({success:0,data:"Not Found"});
                        }
                    }
                
                });
            }
            
           

        });
        
    });



};
function getFilters(filter,callback)
{
    
    //var filters=JSON.parse(filter);
    var filters=filter;
    //var entryQuery ={};
    
    for(var i = 0; i < filters.length; i++)
    {
       
        var filterId = filters[i].filterId;
        //console.log(i);
        tournamentsFilters_model.findOne({_id:filterId},{},function(err,result)
        {
            var entryQuery={};
            var prizeQuery={};
            var otherQuery={};
            if(err)
            {
                //return res.send({success:0,data:err});
            }
            else
            {
                if(result!=null)
                {
                    var filterValue=result.value;
                    var filterV=filterValue.split(",");
                    
                    if(result.filterType=="Entry fee")
                    {
                        if(filterV[1])
                        {
                            if(!isNaN(filterV[1]))
                            {
                                //entryQuery=entryQuery+"{$and:[{entryFee:{'$gt':'"+filterV[0]+"'}},{entryFee:{'$lt':'"+filterV[1]+"'}}]}";
                                entryQuery.$and = [{entryFee:{$gt:filterV[0]}},{entryFee:{$lt:filterV[1]}}];
                            }
                            else if(filterV[1]=="*")
                            {
                                //entryQuery=entryQuery+"{entryFee:{'$gt':'"+filterV[0]+"'}}";
                                entryQuery.entryFee = {$gt:filterV[0]};
                            }
                            else
                            {
                                //entryQuery=entryQuery+"{$or:[{entryFee:'"+filterV[0]+"'}"+','+"{entryFee:'"+filterV[1]+"'}]}";
                                entryQuery.$or = [{entryFee:filterV[0]},{entryFee:filterV[1]}];
                            }
                            
                        }
                        else
                        {
                           // entryQuery=entryQuery+"{entryFee:'"+filterV[0]+"'}";
                           entryQuery.entryFee = filterV[0];
                        }
                       
                        
                    }else if(result.filterType=="Prizes")
                    {
                        //prizeQuery=prizeQuery+"{prizeType:'"+filterV[0]+"'}";
                        prizeQuery.prizeType = filterV[0];
                           
                    }else if(result.filterType=="Other")
                    {
                        //otherQuery=otherQuery+"{tournamentStatus:'"+filterV[0]+"'}";
                        otherQuery.tournamentStatus = filterV[0];
                    }
                    
                }
                else
                {
                    //return res.send({sucess:0,data:"Failed"});
                } 
            }
            
            callback(entryQuery,prizeQuery,otherQuery); 
        });

    }

}
function builtQuery(entryQuery1,prizeQuery1,otherQuery1,callback)
{
    var filterQuery='';
    
    
    if(entryQuery1)
    {
        
        if(!filterQuery)
        {
            filterQuery=entryQuery1;
        }
        else
        {
            filterQuery=filterQuery+","+entryQuery1;
        }
        
    }
    if(prizeQuery1)
    {
        
        if(!filterQuery)
        {
            filterQuery=prizeQuery1;
        }
        else
        {
            filterQuery=filterQuery+","+prizeQuery1;
        }
    }
    if(otherQuery1)
    {
        
        if(!filterQuery)
        {
            filterQuery=otherQuery1;
        }
        else
        {
            filterQuery=filterQuery+","+otherQuery1;
        }
    }
    callback(filterQuery);
}