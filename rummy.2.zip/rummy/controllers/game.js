var tabletype_model  =   require(process.cwd()+'/models/match.js');
var table_model  =   require(process.cwd()+'/models/table.js');



module.exports = function(router,io)
{

	/* join user for match added by Rashmi Sharma 0n 17-08-2015*/
	router.get('/game/joinUserMatch/:mid/:uid',function(req,res)
	{

		
		var matchId=req.params.mid;
		var userId=req.params.uid;
		//console.log('joinUser');
		
		//var userSocket=io.sockets.in(userId);
		//console.log(userSocket);
		//console.log(io.sockets.rooms);
		//console.log(io.sockets.sockets[userId]);

		//console.log('joinUserMatch');

		/* Check loging Users */

		table_model.findOne({_id:matchId},{},function(err,info)
		{
			
			//info.match_join_users.pop(userId);
			//info.no_of_current_join =info.no_of_current_join -1;
			

			if(err){
				//console.log('Failed');
				return res.send('Failed');
			}else if(info != null){
				
				//createMatch(info.match_join_users, matchId);
				if(info.no_of_current_join > 0 ){

					if(info.no_of_current_join == info.maxPlayers){
						//console.log('Stack Full');
						return res.send('Stack Full');
					}else{					
						var join_users = info.match_join_users;
						var flag = 1;
						for (var i in join_users) {
						  
						  if(join_users[i] == userId){
						  	flag = 0;
						  	//console.log('Already joined');
						  	return res.send('Already joined');
						  	break;
						  }
						  //console.log(join_users[i]);
						}
						if(flag)
						{
							info.match_join_users.push(userId);

							info.no_of_current_join =info.no_of_current_join +1;
							console.log(info.no_of_current_join);
							info.match_users_turn_detail[userId]=[];
							info.save(function (err,final_doc)
								{
									
									if(err){
										//console.log('Internal server error');

										return res.send('Internal server error');	
									}
									else
									{
										
										
										
										res.redirect('http://mobirummy.com/mobidemogame?q='+matchId+'&p='+userId);
										//return res.send('Joined');	

										setTimeout(function ()
										{
											if(info.no_of_current_join >5)
											{
												setTimeout(function ()
												{
													createMatch(info.match_join_users, matchId);

												},5000);
											}	
										},3000);
									}
									
								});
							
						}

					}

				}else{

					/* Join new users */
					info.match_join_users.push(userId);
					info.no_of_current_join  =info.no_of_current_join+1;
					console.log(info.no_of_current_join);
					info.match_users_turn_detail[userId]=[];
					
					info.save(function (err,final_doc)
						{
						
							if(err){
								//console.log('Internal server error');
								return res.send('Internal server error');	
							}
							else
							{
								res.redirect('http://mobirummy.com/mobidemogame?q='+matchId+'&p='+userId);
										//return res.send('Joined');	

								setTimeout(function ()
								{
									if(info.no_of_current_join >5)
									{
										setTimeout(function ()
										{
											createMatch(info.match_join_users, matchId);

										},5000);
									}	
								},3000);
							}

							
					});
				}

			}
		});


	});


	/* check Match status added by Rashmi Sharma 0n 18-08-2015*/
	router.get('/game/checkMatchStatus/:mid',function(req,res)
	{
		var matchId=req.params.mid;
		table_model.findOne({_id:matchId},{},function(err,info)
		{
			
			if(err){
				console.log('Failed');

				return res.send(err);
			}
			else if(info != null){
				if(info.tableStatus == 'seating'){
					if(info.no_of_current_join >= 6){
						return res.send('Match Stared');
						//createMatch(info.match_join_users, matchId);
					}else{
						return res.send('Please Wait');
					}
				}else{
					return res.send('Running');
				}
				
			}
		});

	});




}





function createMatch(userIds, matchId){

	var newMatch	=	{};
	var tossWinner='';
	var currentMatchJokers = [];
	var open_deck_card=new Array();
	var closed_deck_card=new Array();
	var cards	=	
	['1-1','1-2','1-3','1-4','1-5','1-6','1-7','1-8','1-9','1-10','1-11','1-12','1-13',
	'2-1','2-2','2-3','2-4','2-5','2-6','2-7','2-8','2-9','2-10','2-11','2-12','2-13',
	'3-1','3-2','3-3','3-4','3-5','3-6','3-7','3-8','3-9','3-10','3-11','3-12','3-13',
	 '4-1','4-2','4-3','4-4','4-5','4-6','4-7','4-8','4-9','4-10','4-11','4-12','4-13',
	'0-0','0-0'
	];	

	var card_deck	=	shuffle(cards);
	
	
	newMatch.match_player_card	=	new Array();
	/*var i = 0;
	for (var user in userIds) {
		
		i++;
	}*/
	
	var j = 0;
	begin_toss = [];

	for( var user in userIds){

		newMatch.match_player_card[j]	=	[];
		newMatch.match_player_card[j][0]	=	new Array();
		
		

		var splitCards = card_deck[j].split('-');
		begin_toss[j] = splitCards[1];
		j++;
		if(j == userIds.length){
			var winnerCardValue = Math.max.apply(Math,begin_toss);
			var winnerCardKey = begin_toss.indexOf(Math.max.apply(Math, begin_toss));
			tossWinner=userIds[winnerCardKey];

			newMatch.match_current_player=tossWinner;

			var main_deck	=	shuffle(cards);

			checkJokerCard(main_deck, function(joker){
				var split_joker = joker.split('-');
				
				currentMatchJokers = split_joker[1];
				

				var main_deck	=	shuffle(cards);
				var i = 0;
				
				while(newMatch.match_player_card[(userIds.length-1)][0].length<13)
				{
					
					
					if(newMatch.match_player_card[i][0])
					{
					newMatch.match_player_card[i][0].push(main_deck.pop());
					}
					if(i==(userIds.length-1))
					{
						i=0;
					}
					else
					{
						i++;
					}
					
					
				}
				var i=0;
				
				for(var user_cards in newMatch.match_player_card)
				{
					console.log(newMatch.match_player_card[i][0]);
				}
				open_deck_card.push(main_deck.pop());
				closed_deck_card=main_deck;
				/*get joker , open deck , close deck*/
				newMatch.match_joker	=	currentMatchJokers;
				newMatch.match_deck_open	=	open_deck_card;
				newMatch.match_deck_close	=	closed_deck_card;

				console.log(open_deck_card);
				console.log(closed_deck_card);


				table_model.update({_id:matchId}, newMatch, function(err,res)
				{
					if(err)
					{
						console.log(err);
						return 'failed';
					}
					else
					{ 

						//main.startMatch(matchId,io);
						for(var k=0;k<userIds.length;k++)
						{
							io.to(userIds[k]).emit('reload',{data:1});
						}
						return res;
					}
				});




				
			});
			break;
		}
	}


}


/* Function for checking joker cards */
var checkJokerCard =  function(main_deck, callback){
	 callback(main_deck[0]);
}

/* Card shuffle funciton */

var shuffle 	=function(o)
{
	for(var j, x, i = o.length; i; j = Math.floor(Math.random() * i), x = o[--i], o[i] = o[j], o[j] = x);
    return o;
}

/*check valid grop of cards added by Rashmi Sharma on 17-08-2015 */

var validCardsGroup = function(userCards)
{
	var groupcardvalue=new Array();
	var groupcardface= new Array();
	if(userCards.legth==3 || userCards.legth==4 )
	{
		for(var cards in userCards)
		{
			cardvalue=userCards.split('-');
			groupcardvalue.push(cardvalue[1]);
			groupcardface.push(cardvalue[0]);
			var suitResult=arrayValuesSame(groupcardface);
			if(suitResult)
			{
				var cardsCons = arrayCons(cardvalue);
				if(cardsCons){
					console.log('Valid Sequence');
				}else{
					console.log('Invalid Sequence');
				}
			}
			else
			{
				var indexResult=arrayValuesSame(groupcardvalue);
				if(indexResult){
					console.log('Valid Cards');
				}else{
					console.log('Invalid Card');
				}
			}
		}
	}
	else
	{
		console.log('invalid Group');
	}
}

/* Check Card Values Same Or Not */
var arrayValuesSame = function(cardvalue) {

    for(var i = 1; i < cardvalue.length; i++)
    {
        if(cardvalue[i] !== cardvalue[0])
            return false;
    }

    return true;
}

/* check conscutive array in cards */
var arrayCons = function (cardvalue) {
  var offset = 0; // remember the last offset
  return function () {
    var start = offset, len = cardvalue.length;
    for (var i = start + 1; i < len; i++) {
      if (cardvalue[i] !== cardvalue[i-1] + 1) {
        return false;
      }
    }
    offset = i;
    return true;
  };
}

var rummyUserTurn = function(userId){

}