var tabletype_model  =   require(process.cwd()+'/models/match.js');
var table_model  =   require(process.cwd()+'/models/table.js');
var tableFilters_model  =   require(process.cwd()+'/models/tables_filter.js');
var findMeAGame_model  =   require(process.cwd()+'/models/findMeAGame.js');

module.exports = function(router, io)
{

     /*Get All Matches By Match Method Cash Added By Raghvendra Singh 04-09-2015*/


    router.get('/table/gatAllCashTypeMatches',function(req,res)
    {
        table_model.find({matchFormatId:req.query.matchFormatId, matchMethod:req.query.matchMethod}, function(err, result){
            if(err){
                res.send({success:0, data:err});
            }else{
                io.emit('listGame',{'result' : result, 'action':req.query.matchFormatId, 'gameType':req.query.matchMethod});
                res.send({success:1, data:result});
            }
        });
        
    });


     /*Get All Matches By Match Method Practice Added By Raghvendra Singh 04-09-2015*/


    router.get('/table/gatAllPracticeTypeMatches',function(req,res)
    {
        table_model.find({matchFormatId:req.query.matchFormatId, matchMethod:req.query.matchMethod}, function(err, result){
            if(err){
                res.send({success:0, data:err});
            }else{
                res.send({success:1, data:result});
            }
        });
        
    });



    /*Find me a game by Raghvendra singh*/
    router.get('/table/findMeAGame',function(req,res)
    {
       

        var userId = req.query.userId;
        console.log(req.query);
        table_model.findOne({matchMethod:req.query.matchMethod, matchFormatId:req.query.matchFormatId, maxPlayers: req.query.maxPlayers}, {},function(err, result){
              if(err){     
              console.log(err);    
                    res.send({success:0,message:err});                        
                }else{
                    console.log('find me a game');
                    console.log(result);
                    if(result!=null){
                        if(result.tableStatus == 'seating'){
                            console.log('seating');
                            return res.send({success:1,data:result});
                        }else if(result.tableStatus == 'running'){
                           
                            var waitingUsers = new findMeAGame_model({userId: userId, matchMethod: req.query.matchMethod, matchFormatId:req.query.matchFormatId, maxPlayers: req.query.maxPlayers });
                            waitingUsers.save(function(err, doc){
                                if(err){
                                    return res.send({success:0,message:err});  
                                }else{
                                    return res.send({success:1,message:'saved successfully'});
                                }
                            });
                        }
                    }
                    else
                    {
                        console.log('in else');
                        return res.send({success:0});  
                    }
                }
        });

    });

	/*Add table(match) type  added by Rashmi Sharma 10-08-2015*/
    router.post('/table/addTableFormat',function(req,res)
    {
        
        var table    =   new tabletype_model({matchId:req.body.matchId,matchName:req.body.matchName});
        table.save(function (err,doc)
        {
            if(err)
            {
                res.send({success:0,data:err});
            }
            else
            {
                res.send({success:1,data:"successfully added"});
            }
        });
    });

    /*get all table(match) type  added by Rashmi Sharma 10-08-2015*/
    router.get('/table/getTableFormat',function(req,res)
    {
    	tabletype_model.find({}, {},function (err, result)
        {
        
            if(err)
            {
                res.send({success:0,data:err});
                    
            }
            else
            {
              
                if(result!=null)
                {

                    res.send({success:1,data:result});
                   
                }
                else
                {
                    res.send({success:0,data:result});
                }
            }
        
        });

    });

    /*get  table(match) type by id   added by Rashmi Sharma 10-08-2015*/
    router.get('/table/getTableFormatById',function(req,res)
    {
    	tabletype_model.findOne({matchId:req.query.matchId}, {},function (err, result)
        {
        
            if(err)
            {
                res.send({success:0,data:err});
                    
            }
            else
            {
              
                if(result!=null)
                {

                    res.send({success:1,data:result});
                   
                }
                else
                {
                    res.send({success:0,data:result});
                }
            }
        
        });

    });

    /*add table added by Rashmi Sharma 10-08-2015*/
    router.post('/table/addTable',function(req,res)
    {
    	
        console.log(req.body);
    	var table    =   new table_model({tableName:req.body.tableName,decks:req.body.decks,pointValue:req.body.pointValue,entryFee:req.body.entryFee,poolType:req.body.poolType,prize:req.body.prize,deals:req.body.deals,maxPlayers:req.body.maxPlayers,matchMethod:req.body.matchMethod,matchFormatId:req.body.matchFormatId,tableStatus:'seating'});
        table.save(function (err,doc)
        {
            if(err)
            {
                res.send({success:0,data:err});
            }
            else
            {
                io.emit('addTable',{'data' : 'hitAction', 'action': req.body.matchFormatId,'gameType':req.body.matchMethod});
                res.send({success:1,data:"successfully added"});
            }
        });

    });


    /*get table details added by Rashmi Sharma 10-08-2015*/
    router.get('/table/getTblsByMtchFrmtId',function(req,res)
    {
    	table_model.find({matchFormatId:req.query.matchFormatId,matchMethod:req.query.matchMethod}, {},function (err, result)
        {        
            if(err)
            {
                res.send({success:0,data:err});                    
            }
            else
            {              
                if(result!=null)
                {
                    io.emit('listGame',{'result' : result, 'action':req.query.matchFormatId, 'gameType':req.query.matchMethod});
                    //io.broadcast.emit('listGame',{'result' : result, 'action':'broadcast'});
                    res.send({success:1,data:result});
                }
                else
                {
                    res.send({success:0,data:result});
                }
            }
        
        });

    });

    router.get('/table/admingetTblsByMtchFrmtId',function(req,res)
    {
        table_model.find({matchFormatId:req.query.matchFormatId}, {},function (err, result)
        {        
            if(err)
            {
                res.send({success:0,data:err});                    
            }
            else
            {              
                if(result!=null)
                {
                    res.send({success:1,data:result});
                    io.emit('listGame',{'result' : result});
                }
                else
                {
                    res.send({success:0,data:result});
                }
            }
        
        });

    });

    /*get table by filters details added by Rashmi Sharma 10-08-2015*/
    router.post('/table/getTblsByFltrsnMfid',function(req,res)
    {
    	//var filters=JSON.parse(req.body.filters);
    	var filters=req.body.filters;
        var matchFormatId=req.body.matchFormatId;
    	var matchMethod=req.body.matchMethod;
        var deckQuery1={};
        var statusQuery1={};
        var maxPlayerQuery1={};
        var poolTypeQuery1={};
        var dealQuery1={};
        var tempArrdeck = [];
        var tempArrstatus = [];
        var tempArrmaxPlayer = [];
        var tempArrpoolType = [];
        var tempArrdeal = [];

        var count=0;
        getFilter(req.body.filters,function(deckQuery,statusQuery,maxPlayerQuery,poolTypeQuery,dealQuery)
        {
             
            count++;
            
            if(deckQuery.hasOwnProperty('decks'))
            {
            	tempArrdeck.push(deckQuery); 
            }
            if(statusQuery.hasOwnProperty('tableStatus'))
            {
            	tempArrstatus.push(statusQuery); 
            }
            if(maxPlayerQuery.hasOwnProperty('maxPlayers'))
            {
            	tempArrmaxPlayer.push(maxPlayerQuery); 
            }
            if(poolTypeQuery.hasOwnProperty('poolType'))
            {
            	tempArrpoolType.push(poolTypeQuery); 
            }
            if(dealQuery.hasOwnProperty('deals'))
            {
            	tempArrdeal.push(dealQuery); 
            }
            

            /*if(deckQuery)
            {
                
                if(deckQuery1)
                {

                    deckQuery1=deckQuery1+','+deckQuery;
                }
                else
                {

                    deckQuery1=deckQuery1+deckQuery;
                }
            }
            if(statusQuery)
            {
                if(statusQuery1)
                {

                    statusQuery1=statusQuery1+','+statusQuery;
                }
                else
                {

                    statusQuery1=statusQuery1+statusQuery;
                }
            }
            if(maxPlayerQuery)
            {
                if(maxPlayerQuery1)
                {

                    maxPlayerQuery1=maxPlayerQuery1+','+maxPlayerQuery;
                }
                else
                {

                    maxPlayerQuery1=maxPlayerQuery1+maxPlayerQuery;
                }
            }
            if(poolTypeQuery)
            {
                if(poolTypeQuery1)
                {

                    poolTypeQuery1=poolTypeQuery1+','+poolTypeQuery;
                }
                else
                {

                    poolTypeQuery1=poolTypeQuery1+poolTypeQuery;
                }
            }
            if(dealQuery)
            {
                if(dealQuery1)
                {

                    dealQuery1=dealQuery1+','+dealQuery;
                }
                else
                {

                    dealQuery1=dealQuery1+dealQuery;
                }
            }*/
 
            if(parseInt(filters.length)==count)
            {
            
                
            	
		        if(tempArrdeck.length>0)
		        {
		        	deckQuery1.$or=tempArrdeck;
		        }
                if(tempArrstatus.length>0)
		        {
		        	statusQuery1.$or=tempArrstatus;
		        }
                
                if(tempArrmaxPlayer.length>0)
		        {
		        	maxPlayerQuery1.$or=tempArrmaxPlayer;
		        }
                
                if(tempArrpoolType.length>0)
		        {
		        	poolTypeQuery1.$or=tempArrpoolType;
		        }
                
                if(tempArrdeal.length>0)
		        {
		        	dealQuery1.$or=tempArrdeal;
		        }
                
               
               	
               	
               
                var filterQueries=[];
                filterQueries.push(deckQuery1);
                filterQueries.push(statusQuery1);
                filterQueries.push(maxPlayerQuery1);
                filterQueries.push(poolTypeQuery1);
                filterQueries.push(dealQuery1);
                filterQueries.push({matchMethod:matchMethod,matchFormatId:matchFormatId});
               
	            var query={$and:[]};        
                query.$and=filterQueries;
                
                console.log('filterId start');
		        console.log(query);
		        console.log('filterId end');
                table_model.find(query, {},function (err, result)
                {
                
                    if(err)
                    {
                        return res.send({success:0,data:err});
                            
                    }
                    else
                    {
                      
                        if(result!=null)
                        {

                           return res.send({success:1,data:result});
                           
                        }
                        else
                        {
                           return res.send({success:0,data:"Not Found"});
                        }
                    }
                
                });
            }
            
           

        });

    });

    /*add Table filters added by Rashmi Sharma 10-08-2015*/
    router.post('/table/addTableFltrs',function(req,res)
    {
    	var tableFilters    =   new tableFilters_model({filterName:req.body.fltName,value:req.body.fltValue,filterType:req.body.fltType});
        tableFilters.save(function (err,doc)
        {
            if(err)
            {
                res.send({success:0,data:err});
            }
            else
            {
                res.send({success:1,data:"successfully added"});
            }
        });

    });

    /*get all Table filters added by Rashmi Sharma 10-08-2015*/
    router.get('/table/getTableFltrs',function(req,res)
    {
    	var tableFilters    =   new tableFilters_model({filterName:req.body.fltName,value:req.body.fltValue,filterType:req.body.fltType});
       	tableFilters_model.find({}, {},function (err, result)
        {
        
            if(err)
            {
                res.send({success:0,data:err});
                    
            }
            else
            {
              
                if(result!=null)
                {

                    res.send({success:1,data:result});
                   
                }
                else
                {
                    res.send({success:0,data:result});
                }
            }
        
        });

    });


    /*delete table  added by Rashmi Sharma 25-08-2015*/
    router.get('/table/deleteTable/:tableId',function(req,res)
    {
        
        table_model.remove({_id:req.params.tableId},function (err, result)
        {        
            
            if(err)
            {
                return res.send({success:0,data:err});                    
            }
            else
            {              
                if(result!=null)
                {
                    return res.send({success:1,data:result});                   
                }
                else
                {
                    return res.send({success:0,data:result});
                }
            }
        
        });

    });


    /* Get table info by table id add by Raghvendra Singh 27-08-15*/

    router.get('/table/editTable/:tableId', function(req, res){
        table_model.findOne({_id:req.params.tableId}, function(err, result){
            if(err)
            {
                return res.send({success:0,data:err});                    
            }
            else
            {              
                if(result!=null)
                {
                    return res.send({success:1,data:result});                   
                }
                else
                {
                    return res.send({success:0,data:result});
                }
            }
        });
    });

    /*update all Table  added by Rashmi Sharma 25-08-2015*/
    router.put('/table/updateTable/:tableId',function(req,res)
    {
        console.log(req.params.tableId);
        table_model.findOneAndUpdate({_id:req.params.tableId}, {tableName:req.body.tableName,decks:req.body.decks,pointValue:req.body.pointValue,entryFee:req.body.entryFee,poolType:req.body.poolType,prize:req.body.prize,deals:req.body.deals,maxPlayers:req.body.maxPlayers,matchMethod:req.body.matchMethod},function (err, result)
        {
        
            if(err)
            {
                res.send({success:0,data:err});
                    
            }
            else
            {
              
                if(result!=null)
                {

                    res.send({success:1,data:'updated successfully'});
                   
                }
                else
                {
                    res.send({success:0,data:''});
                }
            }
        
        });

    });


}


function getFilter(filter,callback)
{
    
    //var filters=JSON.parse(filter);
    var filters=filter;
    for(var i = 0; i < filters.length; i++)
    {
       
        var filterId = filters[i].filterId;
        
        tableFilters_model.findOne({_id:filterId},{},function(err,result,next)
        {
            var deckQuery={};
            var statusQuery={};
            var maxPlayerQuery={};
            var poolTypeQuery={};
            var dealQuery={};
            if(err)
            {
                
            }
            else
            {
                
                if(result!=null)
                {
                    var filterValue=result.value;
                    var filterV=filterValue.split(",");
                    
                    if(result.filterType=="Decks")
                    {
                        
                        //deckQuery="{decks:'"+filterV[0]+"'}";
                        deckQuery.decks=filterV[0];
                        
                          
                    }else if(result.filterType=="Status")
                    {
                        //statusQuery="{tableStatus:'"+filterV[0]+"'}";
                        statusQuery.tableStatus=filterV[0];
                           
                    }else if(result.filterType=="Max Players")
                    {
                        //maxPlayerQuery="{maxPlayers:'"+filterV[0]+"'}";
                        maxPlayerQuery.maxPlayers=filterV[0];
                    }
                    else if(result.filterType=="Pool type")
                    {
                        poolTypeQuery.poolType=filterV[0];
                    }
                    else if(result.filterType=="Deals")
                    {
                        
                    	if(filterV[1])
                        {
                            if(!isNaN(filterV[1]))
                            {
                                dealQuery.$and=[{deals:{$gt:filterV[0]}},{deals:{$lt:filterV[1]}}];
                            	
                            }
                            else if(filterV[1]=="*")
                            {
                                dealQuery.deals={$gt:filterV[0]};
                            }
                            
                            
                        }

                    }
                    
                }
                 
               
            }
            console.log('deckQuery');
            console.log(deckQuery);
            console.log(statusQuery);
            console.log(maxPlayerQuery);
            console.log(poolTypeQuery);
            console.log(dealQuery);
            console.log('dealQuery');
            callback(deckQuery,statusQuery,maxPlayerQuery,poolTypeQuery,dealQuery); 

        });

    }

}
function BuiltQuery(deckQuery1,statusQuery1,maxPlayerQuery1,poolTypeQuery1,dealQuery1,callback)
{
    var filterQuery='';
    
    
    if(deckQuery1)
    {
        
        if(!filterQuery)
        {
            filterQuery=deckQuery1;
        }
        else
        {
            filterQuery=filterQuery+","+deckQuery1;
        }
        
    }
    if(statusQuery1)
    {
        
        if(!filterQuery)
        {
            filterQuery=statusQuery1;
        }
        else
        {
            filterQuery=filterQuery+","+statusQuery1;
        }
    }
    if(maxPlayerQuery1)
    {
        
        if(!filterQuery)
        {
            filterQuery=maxPlayerQuery1;
        }
        else
        {
            filterQuery=filterQuery+","+maxPlayerQuery1;
        }
    }
    if(poolTypeQuery1)
    {
        
        if(!filterQuery)
        {
            filterQuery=poolTypeQuery1;
        }
        else
        {
            filterQuery=filterQuery+","+poolTypeQuery1;
        }
    }
    if(dealQuery1)
    {
        
        if(!filterQuery)
        {
            filterQuery=dealQuery1;
        }
        else
        {
            filterQuery=filterQuery+","+dealQuery1;
        }
    }
    callback(filterQuery);
}
