var express	=	require('express');
var app = express();
var routes = require('../routes.js');
var router = express.Router();
var fs     = require('fs');

module.exports = function(router)
{
	/*Paypal Added by Rashmi Sharma on 31-07-2015*/
	router.get('/paypal/create', routes.create);
	router.get('/paypal/execute', routes.execute);
	router.get('/paypal/cancel', routes.cancel);
	/*end Paypal Added by Rashmi Sharma on 31-07-2015*/
	/*Get Paypal Config File*/

};
try {
  var configJSON = fs.readFileSync("/home/ubuntu/codeangularjs/paypalconfig.json");
  var config = JSON.parse(configJSON.toString());
} catch (e) {
  console.error("File config.json not found or is invalid: " + e.message);
  process.exit(1);
}
routes.init(config);


