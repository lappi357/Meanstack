var match	=	require(process.cwd()+'/models/table.js');
var user_model  =   require(process.cwd()+'/models/user_model.js');
var game_log  =   require(process.cwd()+'/models/game_log.js');
var findMeAGame_model  =   require(process.cwd()+'/models/findMeAGame.js');
var wallet_model  =   require(process.cwd()+'/models/wallet.js');
var walletTransactionDetail_model  =   require(process.cwd()+'/models/walletTransactionDetail.js');
//var user_model	=	require(__dirname+'/user.js');

var main=	{};
main.io='';



main.match_counterdeal    = [];
main.clients;





main.startMatchdeal	=	function (match_id,io)
{
	
	if(typeof io!='undefined')
	{
		main.io=io;
	}
	////console.log('match - -   '+match_id);
    if(main.match_counterdeal[match_id])
    {
    	//////console.log('counter working');
        clearInterval(main.match_counterdeal[match_id]);
    }
      
    //main.clients       =    clients;
   	/*match starting*/
       
   
    //////console.log('timer working');
	
    //////console.log('interval working');
    match.findOne({_id:match_id },{}, function (err, doc)
    {
	    if(doc.match_current_player==(doc.match_join_users.length-1))
		{
			new_match_current_player	=	0;
		}
		else
		{
			new_match_current_player =doc.match_current_player+1;
		}
		//new_match_current_player =doc.match_current_player;

		var users_turn_id=doc.match_join_users[new_match_current_player];
		//console.log('new_match_current_player.........'+doc.match_join_users[new_match_current_player]);

		doc.users_turn_counter[users_turn_id]=parseInt(doc.users_turn_counter[users_turn_id])+1;

			if(doc.drop_users.hasOwnProperty(users_turn_id))
			{
				match.update({_id:match_id},{match_current_player:new_match_current_player,match_declare:[],'match_turn_status':0},function(err)
				{
					if(err)
					{
						//console.log(err);
					}
					else
					{
						if(main.match_counterdeal[match_id])
					    {
					    	//////console.log('counter working');
					    	//console.log('drop users');
					    	//console.log(new_match_current_player);
					        //clearInterval(main.match_counterdeal[match_id]);
					        main.startMatchdeal(match_id);
					    }
					}
				});


			}else{
				//console.log('drop user2 ');
				var datetime = new Date();
				match.update({_id:match_id},{match_current_player:new_match_current_player,users_turn_counter:doc.users_turn_counter,match_declare:[],'match_turn_status':0,'match_start_time':datetime,$inc:{'turn_counter':1}},function(err)
				{
					if(err)
					{
						//////console.log(err);
					}
					else
					{
						//console.log(doc.match_deck_open);   
						if(doc.match_deck_open!=null)
						{
							if(doc.match_deck_open.constructor=== Array)
							{
								var open_card	=	{card_value:doc.match_deck_open[doc.match_deck_open.length-1],card_face:main.getCardImagedeal(doc.match_deck_open[doc.match_deck_open.length-1])};
								
							}
							else
							{
								var open_card	=	{card_value:doc.match_deck_open,card_face:main.getCardImagedeal(doc.match_deck_open)};
							}
						}
						else
						{
							var open_card	=	{card_value:doc.match_deck_open,card_face:main.getCardImagedeal(doc.match_deck_open)};
						}
						

			           	
			           		//////console.log(doc.match_join_users[new_match_current_player]);
			           	setTimeout(function()
			           	{
			           		var match_deck_open=[];
							match_deck_open[0]=[];
							if(doc.match_deck_open.constructor=== Array)
							{
								var i=0;	
								for(card in doc.match_deck_open)
								{
									
									match_deck_open[0][card]	={card_value:doc.match_deck_open[card],card_face:main.getCardImagedeal(doc.match_deck_open[card])};	
									
									
								}
							}
							else
							{
								match_deck_open[0][0]	=	{card_value:doc.match_deck_open,card_face:main.getCardImagedeal(doc.match_deck_open)}; 
							}

				            var roomName=doc._id+doc.match_join_users[new_match_current_player];  
				           // main.io.to(roomName).emit('turn',{message:doc.match_join_users[new_match_current_player],open_card:open_card,match_deck_open:match_deck_open});
							var current_user_id=doc.match_join_users[new_match_current_player];
				            /*var temp_users=[];
				            temp_users=doc.match_join_users;

				            
				           
				           	temp_users.splice(new_match_current_player,1);*/
				           
				            for(var temp_k=0; temp_k<doc.match_join_users.length;temp_k++)
				            {
				            	/*if(temp_k!=new_match_current_player)
				            	{*/
				            		
					            	var temp_roomname=doc._id+doc.match_join_users[temp_k];  
					            	//console.log('turn 1');
					            	main.io.to(temp_roomname).emit('turn',{message:current_user_id,open_card:open_card,match_deck_open:match_deck_open});
					            		
				            	/*}*/
				            	
				            }
				            
				            /*inform current user turn info to  waiting users*/
				            for(var waiting_k=0; waiting_k<doc.match_waiting_users.length;waiting_k++)
				            {
				            	
				            	//console.log('turn 2');
				            	var wait_roomname=doc._id+doc.match_waiting_users[waiting_k];  
				            	main.io.to(wait_roomname).emit('turn',{message:current_user_id,open_card:open_card,match_deck_open:match_deck_open});
					            	
				            }
				            if(doc.deal_match_watch_list!=undefined || doc.deal_match_watch_list.length>0)
							{
								for(var k=0;k<doc.deal_match_watch_list.length;k++)
								{
									var watch_roomName=doc._id+doc.deal_match_watch_list[k];
									main.io.to(watch_roomName).emit('turn',{message:current_user_id,open_card:open_card,match_deck_open:match_deck_open});
								}
							} 
				        },3000);
						
						 
						
					}
				});
			}
	});
   
    /*match ending*/
         
         
    main.match_counterdeal[match_id]      =   setInterval(function()
	{
		console.log('counter ....................');
		match.findOne({_id:match_id },{}, function (err, doc){
             
		    console.log('in counter ....................');
		    //////console.log('timer working');
			//console.log('current player'+doc.match_current_player);

			if(doc.match_current_player==(doc.match_join_users.length-1))
			{
				new_match_current_player	=	0;
			}
			else
			{
				new_match_current_player =doc.match_current_player+1;
			}
			//console.log('new_match_current_player.........'+doc.match_join_users[new_match_current_player]);
	            //////console.log('interval working');
	        var previous_user=doc.match_current_player;
				
			var users_turn_id=doc.match_join_users[new_match_current_player];
		

			doc.users_turn_counter[users_turn_id]=parseInt(doc.users_turn_counter[users_turn_id])+1;
			//console.log('users_turn_id : '+users_turn_id);
			if(doc.drop_users.hasOwnProperty(users_turn_id))
			{
				console.log('drop user3 ');
				/*if(main.match_counterdeal[match_id])
			    {
			    	//console.log('drop users');
			    	//console.log(new_match_current_player);
			    	//////console.log('counter working');
			        //clearInterval(main.match_counterdeal[match_id]);
			        main.startMatchdeal(match_id);

			    }*/
				/*if(new_match_current_player==(doc.match_join_users.length-1))
				{
					new_match_current_player	=	0;
				}
				else
				{
					new_match_current_player =new_match_current_player+1;
				}*/

				match.update({_id:match_id},{match_current_player:new_match_current_player,match_declare:[],'match_turn_status':0},function(err)
				{
					if(err)
					{
						//////console.log(err);
					}
					else
					{
						if(main.match_counterdeal[match_id])
					    {
					    	//console.log('drop users');
					    	//console.log(new_match_current_player);
					    	//////console.log('counter working');
					        //clearInterval(main.match_counterdeal[match_id]);
					        main.startMatchdeal(match_id);

					    }
					}
				});


			}else{
				console.log('drop user4 ');
				match.update({_id:match_id},{'match_current_player':new_match_current_player,users_turn_counter:doc.users_turn_counter,'match_turn_status':0,$inc:{'turn_counter':1}},function(err)
				{
					if(err)
					{
						//////console.log(err);
					}
					else
					{
	           			getUserTotalCards(previous_user,doc,function(previous_user,total_cards,doc)
	       				{
	       					
	       					var doc=doc;
	       					//console.log('doc start');
	       					//console.log(doc.match_join_users);
	       					//console.log('doc end');
	       					checkUserCards(previous_user,total_cards,doc,function(previous_user,doc)
		           			{
		           				if(doc!=null)
		           				{
		           					if(doc.match_deck_open.constructor=== Array)
									{
										var open_card	=	{card_value:doc.match_deck_open[doc.match_deck_open.length-1],card_face:main.getCardImagedeal(doc.match_deck_open[doc.match_deck_open.length-1])};
										
									}
									else
									{
										var open_card	=	{card_value:doc.match_deck_open,card_face:main.getCardImagedeal(doc.match_deck_open)};
									}

									var roomName=doc._id+doc.match_join_users[new_match_current_player];  
					                var emit_status=findClientsSocket(roomName,main.io);
					               
									var match_deck_open=[];
									match_deck_open[0]=[];
									if(doc.match_deck_open.constructor=== Array)
									{
										var i=0;		
										
										
										for(card in doc.match_deck_open)
										{
											
											match_deck_open[0][card]	={card_value:doc.match_deck_open[card],card_face:main.getCardImagedeal(doc.match_deck_open[card])};	
											
											
										}
									}
									else
									{
										match_deck_open[0][0]	=	{card_value:doc.match_deck_open,card_face:main.getCardImagedeal(doc.match_deck_open)}; 
									}
									//console.log('turn 3');
					                main.io.to(roomName).emit('turn',{message:doc.match_join_users[new_match_current_player],open_card:open_card,match_deck_open:match_deck_open});
									
									var current_user_id=doc.match_join_users[new_match_current_player];
					                var temp_users=[];
						            temp_users=doc.match_join_users;

						            
						           
						           	temp_users.splice(new_match_current_player,1);

						           	if(emit_status==0)
									{
										for(var temp_k=0; temp_k<temp_users.length;temp_k++)
							            {
							            	
							            	var temp_roomname=doc._id+temp_users[temp_k];  
							            	
							            	main.io.to(temp_roomname).emit('disconnectUserInfo',{message:current_user_id});
							            		
						            		
							            	
							            } 
									}


						

						            for(var temp_k=0; temp_k<temp_users.length;temp_k++)
						            {
						            	/*if(temp_k!=new_match_current_player)
						            	{*/
						            		//console.log('turn 4');
							            	var temp_roomname=doc._id+temp_users[temp_k];  
							            	main.io.to(temp_roomname).emit('turn',{message:current_user_id,open_card:open_card,match_deck_open:match_deck_open});
							            		
						            	/*}*/
						            	
						            }

						            /*inform current user turn info to  waiting users*/
						            for(var waiting_k=0; waiting_k<doc.match_waiting_users.length;waiting_k++)
						            {
						            	
						            	//console.log('turn 5');
						            	var wait_roomname=doc._id+doc.match_waiting_users[waiting_k];  
						            	main.io.to(wait_roomname).emit('turn',{message:current_user_id,open_card:open_card,match_deck_open:match_deck_open});
							            	
						            } 
						             if(doc.deal_match_watch_list!=undefined || doc.deal_match_watch_list.length>0)
									{
										for(var k=0;k<doc.deal_match_watch_list.length;k++)
										{
											var roomName=doc._id+doc.deal_match_watch_list[k];
											main.io.to(roomName).emit('turn',{message:current_user_id,open_card:open_card,match_deck_open:match_deck_open});
										}
									}  


		           				}
		           			});
	       				});
		
	 	 			}
				});
			}
			
		
		
		});
             
	},30000);
    
         /*
    var updateFields    =   {};
    
    updateFields.turnInterval   =   new_turnInterval;
     //////console.log(new_turnInterval);
    
         /*
    match.findOne({ '_id': '54804e66b6ae70624a2607e9' },updateFields, function (err, doc){
    //////console.log('timer added');
    });
    */
    
    
};



main.declaredeal =function(req,res)
{

	
	var player_id=req.params.player_id;
	var points=req.params.points;
	var declare_deal_username = req.params.declare_deal_username;
	var wrongDeclare = req.params.wrongDeclare;
	//console.log('declare_deal_username');
	//console.log(declare_deal_username);
		match.findOne({_id:req.params.match_id},{},function (err,doc)
		{
			console.log('points=>'+points+' typeof=>'+ typeof points+'doc.match_declare.length=>'+doc.match_declare.length );
			console.log("declaredeal=>"+points!=0 && doc.match_declare.length<=0);
			console.log("wrongDeclare=>"+wrongDeclare);
			if(points!=0 && doc.match_declare.length<=0 && wrongDeclare == 0 )
			{
				//console.log('in drop deal 1');
					
				if(doc!=null)
				{
					//console.log('in drop deal 2');
					var wdpoints = 80;
					if(doc.drop_users.length==0)
					{
						doc.drop_users={};
					}
					var temp_match_player_card=[[]];

					/*get player cards start*/
						if(typeof doc.match_player_card !='undefined' || doc.match_player_card!=null)
						{
							var players_id	=	doc.match_join_users.indexOf(player_id);
							for(group in doc.match_player_card[players_id])
							{
								if(temp_match_player_card[group]==undefined)
								{
									temp_match_player_card[group]	=	[];
								}
								if(doc.match_player_card[players_id][group]!=undefined && doc.match_player_card[players_id][group]!=null )
								{
									for(card in doc.match_player_card[players_id][group])
									{
										if(temp_match_player_card[group][card]==undefined)
										{
											temp_match_player_card[group][card]	=	[];
										}
										if(doc.match_player_card[players_id][group][card]!=undefined && doc.match_player_card[players_id][group][card]!=null)
										{
											temp_match_player_card[group][card]	={card_value:doc.match_player_card[players_id][group][card],card_face:main.getCardImagedeal(doc.match_player_card[players_id][group][card])};	
										
										}
											
									}
								}
							}
						}
					/*get player cards end*/
				
				

					if(doc.current_match_user_points.hasOwnProperty(player_id))
					{
						doc.current_match_user_points[player_id]=parseInt(doc.current_match_user_points[player_id])-wdpoints;
					}
					doc.drop_users[player_id]={player_id:player_id,points:parseInt(wdpoints),username:declare_deal_username,declare_player_cards:temp_match_player_card,status:'Dropped',total_user_chips: doc.current_match_user_points[player_id]};
					
					match.update({_id:doc._id},doc,function (err,userdoc)
					{
			            if(err)
			            {
			            	//console.log(err);
			            }
			            else
			            {
			            	var current_playing_users=doc.match_join_users.length-Object.keys(doc.drop_users).length;
			            	console.log('current_playing_users')
			            	console.log(current_playing_users);
			            	for(var i=0;i<doc.match_join_users.length;i++)
							{
						 		var roomName=doc._id+doc.match_join_users[i];
						 	
						 		main.io.to(roomName).emit('wrongDeclaretion',{user_id:player_id,points:doc.current_match_user_points[player_id],action:'wrongDeclare'});
							 	if(current_playing_users <= 1){
							 		console.log('declareAfterAllDrops');
							 		main.io.to(roomName).emit('declareAfterAllDrops',{data:1});
							 	}
							}
			            }
					});
				}	
			}
			else
			{
				clearInterval(main.match_counterdeal[req.params.match_id]);
				getUserTotalPointsDeal(doc,player_id,declare_deal_username,points,function(doc)
				{
					var datetime = new Date();
					/*get current match winner info*/
					doc.match_end_time=datetime;
					
					
					match.update({_id:doc._id},doc,function (err,userdoc)
					{
			            if(err)
			            {
			            	
			            }
			            else
			            {
			            	
			            }
			            
			            match.findOne({_id:doc._id},{},function(err,matdoc)
		            	{
		            		
		            	});
			            
			            getCurrentConnectedUsersdeal(doc,function(doc,connectedUsers)
		            	{
		            		console.log('doc.match_declare.length start');
				            console.log(doc.match_declare.length);
				            console.log('connectedUsers connectedUsers start');
				            console.log(connectedUsers);
				            console.log('connectedUsers connectedUsers end');
				            var totalDeclares = 0;
				            if(doc.drop_users.length == 0){
				            	totalDeclares=doc.match_declare.length;	
				            }else{
				            	totalDeclares=doc.match_declare.length+Object.keys(doc.drop_users).length;
				            }
				           
				            console.log('totalDeclares');
				            console.log(totalDeclares);
				            console.log('totalDeclares');
							if(totalDeclares == connectedUsers)
							{
								console.log('in total declare condition');
								var tableHistory={};
								tableHistory.match_declare=doc.match_declare;
								tableHistory.drop_users=doc.drop_users;
								tableHistory.users_turn_counter = doc.users_turn_counter;
								tableHistory.dropNdeclareData=doc.dropNdeclareData;
								tableHistory.match_min_entry=doc.match_min_entry;
								tableHistory.match_point_value=doc.match_point_value;
								tableHistory.match_last_player=doc.match_last_player;
								tableHistory.match_last_moved_card=doc.match_last_moved_card;
								tableHistory.match_end_time=doc.match_end_time;
								tableHistory.match_start_time=doc.match_start_time;
								tableHistory.match_join_users=doc.match_join_users;
								tableHistory.decks=doc.decks;
								tableHistory.match_player_card=doc.match_player_card;
								tableHistory.match_joker=doc.match_joker;
								tableHistory.match_deck_open=doc.match_deck_open;
								tableHistory.turn_counter=doc.turn_counter;
								
								tableHistory.deal_currentMatch_userpoints=doc.deal_currentMatch_userpoints;
								doc.table_history.push(tableHistory);
								var last_deal_data= [];
								var temp_declare = [];

								if(doc.drop_users.length == 0){
									last_deal_data = doc.match_declare;	
								}else if(Object.keys(doc.drop_users).length > 0 )
								{
									for(var key in doc.drop_users)
									{
										temp_declare.push({player_id:doc.drop_users[key].player_id,points:doc.drop_users[key].points,username:doc.drop_users[key].username,declare_player_cards:doc.drop_users[key].declare_player_cards,status:doc.drop_users[key].status,total_user_chips:doc.drop_users[key].total_user_chips});

									}
									 last_deal_data = doc.match_declare.concat(temp_declare); 								
								}
								doc.last_deal=last_deal_data;
								doc.save(function (err,tabledoc)
								{
								});
								
								console.log('getcurrentDealWinnerInfo start');
								getcurrentDealWinnerInfo(doc,function(doc,winnerId,totalPoints)
								{
									console.log('docdocdocdocdocdocdocdocdocdocdoc start');
									console.log(doc);

									if(doc.dealTie==0)
									{
										if(doc.deals>doc.currentDeal)
										{
											
											for(var i=0;i< doc.dropNdeclareData.length;i++)
											{
												var roomName=doc._id+doc.dropNdeclareData[i].player_id;
												main.io.to(roomName).emit('declare',doc.dropNdeclareData);
											}
											
											doc.match_declare=[];
											doc.dropNdeclareData = [];
											doc.drop_users = '';
											doc.users_turn_counter = "";
											
											doc.save(function (err,tabledoc){});
											main.seatingdeal(doc._id,main.io);
											setTimeout(function ()
											{
												main.createMatchdeal(doc,main.io);	
											},9000);
										}
										else
										{
											

											getDealWinnerInfo(doc,function(doc,winnerId,winnerPoints,duplicates_winner_keys)
											{
												//console.log('duplicates_winner_keys');
												//console.log(duplicates_winner_keys);
												if(duplicates_winner_keys.length>1)
												{
													
													dctMnybeforeTiebreakerMatch(doc,winnerId,winnerPoints,duplicates_winner_keys,function(doc,winnerId,winnerPoints,duplicates_winner_keys)
													{
														beforeTiebreakerMatch(doc,winnerId,winnerPoints,duplicates_winner_keys,function(doc,winnerId,winnerPoints,duplicates_winner_keys)
														{
															
																for(var i=0;i<doc.dropNdeclareData.length;i++)
																{
																	var roomName=doc._id+doc.dropNdeclareData[i].player_id;
																	main.io.to(roomName).emit('declare',doc.dropNdeclareData);
																}
																doc.match_declare=[];
																doc.save(function (err,tabledoc){});
											
																main.seatingdeal(doc._id,main.io);
																setTimeout(function ()
																{
																	main.createMatchdeal(doc,main.io);	
																},9000);
														});	
													});
													
												}
												else
												{
													var temp_doc_declare=doc.dropNdeclareData;
													for(var i=0;i<temp_doc_declare.length;i++)
													{
														var roomName=doc._id+doc.dropNdeclareData[i].player_id;
														main.io.to(roomName).emit('declare',doc.dropNdeclareData);
														main.io.to(roomName).emit('close_game',doc.dropNdeclareData);
													}
													doc.currentDeal=0;
													doc.deal_currentMatch_userpoints="";
													doc.tableStatus="seating";
													doc.match_toss_winner="";
													doc.match_declare=[];
													doc.dropNdeclareData=[];
													doc.drop_users= '';
													doc.match_join_users=[];
													doc.users_turn_counter="";
													doc.match_player_card=[];
													doc.match_joker="";
													doc.turn_counter=0;
													doc.deal_currentMatch_userpoints={};
													doc.match_deck_open="";
													doc.match_deck_close=[];
													doc.last_deal=[];
													doc.save(function (err,tabledoc){});
												}

												
											});	
										}
									}
									else if(doc.dealTie==1)
									{
										getDealTieWinnerInfo(doc,function(doc,winnerId)
										{
											var temp_doc_declare=doc.dropNdeclareData;
											for(var i=0;i<temp_doc_declare.length;i++)
											{
												var roomName=doc._id+doc.dropNdeclareData[i].player_id;
												main.io.to(roomName).emit('declare',doc.dropNdeclareData);
												main.io.to(roomName).emit('close_game',doc.dropNdeclareData);
											}
											for(var i=0;i<doc.deal_match_watch_list.length;i++)
											{
												var roomName=doc._id+doc.deal_match_watch_list[i];
												main.io.to(roomName).emit('declare_watch',doc.dropNdeclareData);
												main.io.to(roomName).emit('close_game',doc.dropNdeclareData);
											}
											doc.currentDeal=0;
											doc.dealTie=0;
											
											doc.tableStatus="seating";
											doc.tableStatus="seating";
											doc.match_toss_winner="";
											doc.match_declare=[];
											doc.dropNdeclareData=[];
											doc.match_join_users=[];
											doc.users_turn_counter={};
											doc.match_player_card=[];
											doc.match_joker="";
											doc.turn_counter=0;
											doc.deal_currentMatch_userpoints={};
											doc.match_deck_open="";
											doc.match_deck_close=[];
											doc.save(function (err,tabledoc){});
										});	
									}
									
								});		
							}
							/*else if(doc.match_declare.length > 2)
							{
								console.log('declare is in greater then one condition');
								var declareData;
								var temp_declare=[];
								if(doc.drop_users.length == 0){
									declareData = doc.match_declare;	
								}else if(Object.keys(doc.drop_users).length > 0 )
								{
									for(var key in doc.drop_users)
									{
										temp_declare.push({player_id:doc.drop_users[key].player_id,points:doc.drop_users[key].points,username:doc.drop_users[key].username,declare_player_cards:doc.drop_users[key].declare_player_cards,status:doc.drop_users[key].status,total_user_chips:doc.drop_users[key].total_user_chips});

									}
									declareData = doc.match_declare.concat(temp_declare); 								
								}
								console.log('declareData start');
								console.log(declareData);
								for(var i=0;i< declareData.length;i++)
								{
									var roomName=doc._id+declareData[i].player_id;
									main.io.to(roomName).emit('declare',declareData);
								}
							}*/
							else
							{								
								for(var i=0;i<doc.match_join_users.length;i++)
								{
								 	if(doc.match_join_users[i]!=req.params.player_id)
								 	{
								 		console.log('declare equlas zero');
								 		var roomName=doc._id+doc.match_join_users[i];
								 		main.io.to(roomName).emit('declareNow',{data:1});
								 	}
								}

							}

		            	}); 
			            

					});
				});
			}
			
		});
	
}

/*drop from match*/
main.dropdeal =function(req,res)
{
	console.log('----------------------drop --------------------------');
	var player_id=req.params.player_id;
	var total_points = req.params.total_points;
	var points=0;
	var declare_deal_username = req.params.declare_deal_username;
	
	match.findOne({_id:req.params.match_id},{},function (err,doc)
	{
		//console.log('in drop deal 1');
			
		if(doc!=null)
		{
			//console.log('in drop deal 2');
			if(doc.users_turn_counter[player_id]<=1)
			{
					points=20;				
			}
			else
			{
					points=40;

			}
			if(doc.drop_users.length==0)
			{
				doc.drop_users={};
			}
			/*doc.drop_users[player_id]={player_id:player_id,points:parseInt(points),username:declare_deal_username,declare_player_cards:''};*/
			var temp_match_player_card=[[]];

			/*get player cards start*/
				if(typeof doc.match_player_card !='undefined' || doc.match_player_card!=null)
				{
					var players_id	=	doc.match_join_users.indexOf(player_id);
					for(group in doc.match_player_card[players_id])
					{
						if(temp_match_player_card[group]==undefined)
						{
							temp_match_player_card[group]	=	[];
						}
						if(doc.match_player_card[players_id][group]!=undefined && doc.match_player_card[players_id][group]!=null )
						{
							for(card in doc.match_player_card[players_id][group])
							{
								if(temp_match_player_card[group][card]==undefined)
								{
									temp_match_player_card[group][card]	=	[];
								}
								if(doc.match_player_card[players_id][group][card]!=undefined && doc.match_player_card[players_id][group][card]!=null)
								{
									temp_match_player_card[group][card]	={card_value:doc.match_player_card[players_id][group][card],card_face:main.getCardImagedeal(doc.match_player_card[players_id][group][card])};	
								
								}
									
							}
						}
					}
				}
			/*get player cards end*/
			if(doc.current_match_user_points.hasOwnProperty(player_id))
			{
				doc.current_match_user_points[player_id]=parseInt(doc.current_match_user_points[player_id])-points;
			}
			
			doc.drop_users[player_id]={player_id:player_id,points:parseInt(points),username:declare_deal_username,declare_player_cards:temp_match_player_card,status:'Dropped',total_user_chips: doc.current_match_user_points[player_id]};
			
			
			match.update({_id:doc._id},doc,function (err,userdoc)
			{
	            if(err)
	            {
	            	//console.log(err);
	            }
	            else
	            {
	            	for(var i=0;i<doc.match_join_users.length;i++)
					{
					 	
				 		var roomName=doc._id+doc.match_join_users[i];
				 		main.io.to(roomName).emit('dropinfo',{user_id:player_id,points:doc.current_match_user_points[player_id]});
					}
	            }
			});
			res.end();
		}
	});
}

main.getMatchdeal	=	function (res,match_id,player_id)
{

	match.findOne({_id:match_id},{},function (err,matchResult)
	{
		getConnectedUsersInfo_callback(matchResult,function(matchResult,user)
		{
			////console.log(matchResult.match_player_card[1]);
			user_model.findOne({_id:player_id},{},function (err,userProfile)
			{

				if(player_id && matchResult)
				{
					////////console.log(matchResult);
					////////console.log(matchResult);
					////////console.log(matchResult);
			
					var	final_result	=	{};
					final_result.title	=	matchResult.match_title;
					final_result.deck_close	=	matchResult.match_deck_close;
					//console.log(matchResult.match_deck_open);
					if(typeof matchResult.match_deck_open !='undefined' || matchResult.match_deck_open!=null)
					{
						if(matchResult.match_deck_open.constructor=== Array)
						{
							final_result.deck_open	=	{card_value:matchResult.match_deck_open[matchResult.match_deck_open.length-1],card_face:main.getCardImagedeal(matchResult.match_deck_open[matchResult.match_deck_open.length-1])};
							
						}
						else
						{
							final_result.deck_open	=	{card_value:matchResult.match_deck_open,card_face:main.getCardImagedeal(matchResult.match_deck_open)};
						}
					}

					if(typeof matchResult.match_deck_close !='undefined' || matchResult.match_deck_close!=null)
					{
					
						if(matchResult.match_deck_close.constructor=== Array)
						{
							final_result.deck_close	=	{card_value:matchResult.match_deck_close[matchResult.match_deck_close.length-1],card_face:main.getCardImagedeal(matchResult.match_deck_close[matchResult.match_deck_close.length-1])};
						}
						else
						{
							final_result.deck_close	=	{card_value:matchResult.match_deck_close,card_face:main.getCardImagedeal(matchResult.match_deck_close)}; 
						}
					}
			 
				
					/*
					final_result.deck_close	=	{card_value:matchResult.match_deck_close[matchResult.match_deck_close.length-1],card_face:main.getCardImage(matchResult.match_deck_close[matchResult.match_deck_close-1])};
					final_result.deck_open	=	{card_value:matchResult.match_deck_open[matchResult.match_deck_open.length-1],card_face:main.getCardImage(matchResult.match_deck_open[matchResult.match_deck_open-1])};
					*/
					
					
					final_result.deck_joker	=	matchResult.match_joker;
					final_result.match_current_player	=	matchResult.match_current_player;
					final_result.match_player_card	=	[[]];
					final_result.match_join_users	=	matchResult.match_join_users;
					final_result.table_name	=	matchResult.tableName;
					
					final_result.match_deck_open	=	[];
					final_result.match_deck_open[0]	=	[];
					
					final_result.last_deal	=matchResult.last_deal;
					final_result.dealTie	=matchResult.dealTie;
					final_result.matchFormatId	=matchResult.matchFormatId;
					final_result.decks	=matchResult.decks;
					final_result.matchMethod	=matchResult.matchMethod;
					final_result.maxPlayers	=matchResult.maxPlayers;
					final_result.deals	=matchResult.deals;
					final_result.poolType	=matchResult.poolType;
					final_result.prize	=matchResult.prize;
					final_result.entryFee	=matchResult.entryFee;
					final_result.pointValue	=matchResult.pointValue;
					final_result.current_match_user_points=matchResult.current_match_user_points;
					if(matchResult.current_match_user_points.hasOwnProperty(player_id))
					{
						final_result.user_total_chips=matchResult.current_match_user_points[player_id];
					}
					else
					{
						final_result.user_total_chips=0;
					}
					final_result.currentDeal	=matchResult.currentDeal;
					if(typeof matchResult.match_deck_open !='undefined' || matchResult.match_deck_open!=null)
					{
							
						if(matchResult.match_deck_open.constructor=== Array)
						{
							var i=0;		
							
							
							for(card in matchResult.match_deck_open)
							{
								
								final_result.match_deck_open[0][card]	={card_value:matchResult.match_deck_open[card],card_face:main.getCardImagedeal(matchResult.match_deck_open[card])};	
									
							}
						}
						else
						{
							final_result.match_deck_open[0][0]	=	{card_value:matchResult.match_deck_open,card_face:main.getCardImagedeal(matchResult.match_deck_open)}; 
						}
						//console.log('match open deck start');
						//console.log(final_result.match_deck_open[0]);
						//console.log('match open deck end');
						
						
					}





					//////console.log(player_id);
					//////console.log(matchResult.match_join_users);
					if(typeof matchResult.match_player_card !='undefined' || matchResult.match_player_card!=null)
					{
						player_id	=	matchResult.match_join_users.indexOf(player_id);


						//console.log(matchResult.match_join_users);

						for(group in matchResult.match_player_card[player_id])
						{
								
							//		//////console.log(matchResult.match_player_card[player_id][group]);
							////////console.log(group);
								
							var i=0;		
							if(!final_result.match_player_card[group])
							{
								final_result.match_player_card[group]	=	[];
							}
							for(card in matchResult.match_player_card[player_id][group])
							{
								
								final_result.match_player_card[group][card]	={card_value:matchResult.match_player_card[player_id][group][card],card_face:main.getCardImagedeal(matchResult.match_player_card[player_id][group][card])};	
									
							}
							
						
						}
					}
				}
					
				if(matchResult.drop_users.hasOwnProperty(player_id))
				{
					final_result.match_player_card=[[]];
				}  
				////console.log(final_result.match_player_card);

				if(final_result)
				{
					final_result.user=userProfile;
					final_result.allUsersList=user;
					//console.log('final_result start');
					//console.log(final_result);
					//console.log('final_result end');
					res.jsonp(final_result);
				}
				else
				{
					res.jsonp('error');
				}
			});
		});
		

		
	});
};


main.addDeckOpenCarddeal	=	function(res,match_id,player_id)
{
	match.findOne({_id:match_id  },{},function(err,doc)
	{	
		player_id=doc.match_join_users.indexOf(player_id);
		if(doc.match_current_player!=player_id)
		{
			res.jsonp(false);
			return false;
			
			
		}
        
        if(doc.match_turn_status==1)
		{
			res.jsonp(2);
			return false;
			
			
		}
		
		if(!doc.match_player_card[player_id][6])
			{
				doc.match_player_card[player_id][6]	=	[];
			}
			
		if(doc.match_deck_open.constructor=== Array)
		{ 
				var closeCard	=	doc.match_deck_open.pop();
		}
		else
		{
				var closeCard	=	doc.match_deck_open;
				doc.match_deck_open=[];
		}
		
		doc.match_last_moved_card=closeCard;
		doc.match_player_card[player_id][6].push(closeCard);
	
		var total_cards=0;
   		for(var i=0 ; i<=6;i++)
		{
				
			if (doc.match_player_card[player_id][i]!=null)
			{
			  total_cards=total_cards+doc.match_player_card[player_id][i].length;
			}
		}
			
   		if(total_cards<15)
   		{
   			match.update({_id:match_id}, { match_player_card:doc.match_player_card,match_last_moved_card:doc.match_last_moved_card,match_deck_open:doc.match_deck_open,'match_turn_status':1 }, {}, function(err)
			{
				for(var j=0; j<doc.match_join_users.length; j++){
					if(j != player_id ){
						//console.log('doc.match_join_users[j]');
						//console.log(j);
						//console.log('player_id');
						//console.log(player_id);
						//console.log('player_id end');
						//console.log('match_deck_open:doc.match_deck_open');
						//console.log(doc.match_deck_open);
						//console.log('roomName');
						//console.log(roomName);
						//console.log('doc.match_join_users[player_id]');
						//console.log(doc.match_join_users[player_id]);
						
						var roomName = match_id+doc.match_join_users[j];
						main.io.to(roomName).emit('openDeckCard',{deck:'openDeck',player_id:doc.match_join_users[player_id]});
					}
				}
			
				res.jsonp({card_value:closeCard,card_face:main.getCardImagedeal(closeCard)})
			});
   		}
   		else
   		{
   			//console.log(' in add deck open card ');
   		}


		
		
	});
};


main.addDeckCloseCarddeal	=	function(res,match_id,player_id)
{

	//////console.log(match_id);
	match.findOne({ _id:match_id  },{},function(err,doc)
	{
		//////console.log('data'+doc.match_current_player);
		//////console.log('req'+player_id);		
		player_id=doc.match_join_users.indexOf(player_id);

		if(doc.match_current_player!=player_id)
		{
			res.jsonp(false);
			return false;
			
			
		}
        
         if(doc.match_turn_status==1)
		{
			res.jsonp(2);
			return false;
			
			
		}
		//////console.log('*//////////// old');
		//////console.log(doc.match_deck_close);
		//////console.log(doc.match_player_card);
		if(!doc.match_player_card[player_id][6])
		{
			doc.match_player_card[player_id][6]	=	[];
		}
		var closeCard='';	
		if(doc.match_deck_close.constructor=== Array)
		{ 
			if(doc.match_deck_close.length==0)
			{
				doc.match_deck_close		=	doc.match_deck_open;
				doc.match_deck_open 		=	doc.match_deck_close.pop();
			}
			
			closeCard	=	doc.match_deck_close.pop();
		}
		else
		{
				closeCard	=	doc.match_deck_close;
				doc.match_deck_close=[];
		}
		//////console.log('closed card'+closeCard);

		doc.match_player_card[player_id][6].push(closeCard);
		doc.match_last_moved_card=closeCard;
	
		var total_cards=0;
   		for(var i in doc.match_player_card[player_id])
		{
				
			if (doc.match_player_card[player_id][i]!=null)
			{
			  total_cards=total_cards+doc.match_player_card[player_id][i].length;
			  
			}

		}


   		if(total_cards<15)
   		{
   			match.update({_id:match_id}, { match_player_card: doc.match_player_card,match_last_moved_card:doc.match_last_moved_card,match_deck_close:doc.match_deck_close,match_deck_open:doc.match_deck_open,'match_turn_status':1 }, {}, function(err)
			{
				for(var j=0; j<doc.match_join_users.length; j++){
					if(j != player_id ){
						
						var roomName = match_id+doc.match_join_users[j];
						main.io.to(roomName).emit('DeckCard',{deck:'close',player_id:doc.match_join_users[player_id]});
					}
				}
				//////console.log('*//////////// old');
			//////console.log(doc.match_deck_close);
			//////console.log(doc.match_player_card);
				res.jsonp({card_value:closeCard,card_face:main.getCardImagedeal(closeCard)})
			});
   		}


		 
		
	});
};




main.updatePlayerCardsdeal	=	function(res,cards,match_id,player_id,remove_card)
{
	match.findOne({ _id:match_id},{}, function (err, doc){
	//////console.log('update working');	
	//////console.log('-------------');
	//////console.log(doc.match_player_card[player]);

	var player	=	doc.match_join_users.indexOf(player_id);
	  doc.match_player_card[player]	=	cards;
	 
		if(remove_card && remove_card!='undefined')
		{
            
            
            if(remove_card.constructor===Array)
            {
                remove_card =   remove_card[0];
            }
            
			//////console.log('remove card working');
			if(doc.match_deck_open.constructor=== Array)
			{ 
				doc.match_deck_open.push(remove_card);
			}
			else
			{
				if(doc.match_deck_open!=null || doc.match_deck_open!='')
				{
					var temp_match_deck_open=doc.match_deck_open;
					doc.match_deck_open=[];
					doc.match_deck_open.push(temp_match_deck_open);
					doc.match_deck_open.push(remove_card);
				}
				else
				{
					doc.match_deck_open	=	[remove_card];
				}
				
			}
			//console.log('update doc.match_deck_open start');
			//console.log(doc.match_deck_open);
			//console.log('update doc.match_deck_open end');
			/*//console.log(doc.match_deck_open);
			//console.log(doc.match_deck_open);*/
           
            doc.match_turn_status=0;
		}

		var total_cards=0;
   		for(var i in doc.match_player_card[player])
		{
				
			if (doc.match_player_card[player][i]!=null)
			{
			  total_cards=total_cards+doc.match_player_card[player][i].length;
			  
			}

		}
		//console.log('update cards start');
		//console.log(total_cards);
		//console.log('update cards end ');

   		if(total_cards<15)
   		{
			////////console.log(doc.match_player_card);
		  	match.update({_id:match_id}, { match_player_card: doc.match_player_card,match_deck_open:doc.match_deck_open,match_turn_status:doc.match_turn_status }, {}, function(err,updatedDoc)
		  	{
				if(err)
				{
					//////console.log('not wokring'+err);
					res.jsonp(err);
				}
				else
				{
			
		            if(remove_card && remove_card!='undefined')
		            {
		                if(doc.match_current_player    ==   player)
		                {

		                	if(doc.deal_match_watch_list!=undefined || doc.deal_match_watch_list.length>0)
							{
								var current_user_id=doc.match_join_users[player];
								for(var k=0;k<doc.deal_match_watch_list.length;k++)
								{
									var watch_roomName=doc._id+doc.deal_match_watch_list[k];
									main.io.to(watch_roomName).emit('discard_current_card',{message:current_user_id,open_card:remove_card,card_face:main.getCardImagedeal(remove_card)});
								}
							} 
							if(doc.match_join_users!=undefined || doc.match_join_users.length>0)
							{
								var current_user_id=doc.match_join_users[player];
								for(var k=0;k<doc.match_join_users.length;k++)
								{
									if(k!=player)
									{
										var watch_roomName=doc._id+doc.match_join_users[k];
										main.io.to(watch_roomName).emit('discard_current_card',{message:current_user_id,open_card:remove_card,card_face:main.getCardImagedeal(remove_card)});
									}
									
								}
							} 
	                      if(main.match_counterdeal[match_id])
	                       {
	                           
	                           main.startMatchdeal(match_id);
	                       }
		                }
		            }
		            
					
					res.jsonp(updatedDoc);
					
				}
		  	});  
   		}
	  	
	 
		
	 
	});
};






main.joinMatchdeal =	function (match_id,user_id,io,res)
{
	

	match.findOne({ _id:match_id},{},function(err,doc)
	{
		if(err)
		{
			//console.log(err);

		}	
		else
		{
			if(doc.match_join_users==null)
			{
					doc.match_join_users	=	[];
					
			}
			if(doc.current_match_user_points.length==0)
			{
				doc.current_match_user_points={};
			}
			if(doc.match_waiting_users==null)
			{
					doc.match_waiting_users	=	[];

			}
			if(doc.users_turn_counter.length==0)
			{
				doc.users_turn_counter={};
			}
			
			if(doc.match_join_users.indexOf(user_id)>0)
			{
				res.send('You have already joined the game');
				return false;
			}


			var totalUsers=doc.match_join_users.length+doc.match_waiting_users.length;
			
			if(totalUsers<doc.maxPlayers)
			{
				doc.current_match_user_points[user_id]=80*doc.deals;
				//console.log('doc.current_match_user_points[user_id]');
				//console.log(user_id);
				//console.log(doc.current_match_user_points[user_id]);

				if(doc.tableStatus=="running")
				{
					doc.match_waiting_users.push(user_id);

				}
				else
				{
					doc.match_join_users.push(user_id);
					doc.users_turn_counter[user_id]=0;
				}
			}
			else
			{
				res.send('Stack Full');
				return false;
			}
			
			match.update({_id:doc._id},doc,function (err)
			{
				
				match.findOne({ _id:match_id},{},function(err,final_doc)
				{
					if(err)
					{
						//console.log(err);

					}	
					else
					{

						//////console.log('join user added');
						var game_log_new= new game_log({userId:user_id,matchId:match_id});
						game_log_new.save(function(err,doc){
							if(err)
							{
								//console.log(err);
							}

						});
						res.redirect('http://mobirummy.com/gamed?q='+match_id+'&p='+user_id);

						setTimeout(function ()
						{
							

							var user=[];
							var k=0;
							for(var k_user=0;k_user<final_doc.match_join_users.length;k_user++)
							{
								var temp_user={};
								var roomName=final_doc._id+final_doc.match_join_users[k_user];
								user_model.findOne({_id:final_doc.match_join_users[k_user]},{},function(err,user_result)
								{
									if(err)
									{

									}
									else
									{
										
										if(user_result!=null)
										{
											user[k]={};
											user[k].user_id=user_result._id;
											user[k].name=user_result.firstname;
											user[k].gender=user_result.gender;
											k++;

										}
									}
								});	
							}

							

							setTimeout(function ()
							{
								for(var k=0;k<final_doc.match_join_users.length;k++)
								{
									var roomName=final_doc._id+final_doc.match_join_users[k];
									//console.log('roomName start');
									//console.log(roomName);
									//console.log('roomName end');
									io.to(roomName).emit('allConnectedUsers',user);	
								}
							},2000);

							if(final_doc.match_join_users.length==final_doc.maxPlayers && final_doc.tableStatus=="seating")
							{
								//console.log('running');
								final_doc.tableStatus="running";
								
								match.update({_id:final_doc._id},final_doc,function (err)
								{
									if(err)
									{
										//console.log(err);
									}
									
									main.seatingdeal(final_doc._id,io);

									setTimeout(function ()
									{
										////console.log('*********************** timeout working');
										main.createMatchdeal(final_doc,io);	
										

									},5000);

								});	
							}	
						},3000);

					}
				});

									
									
			});						//////console.log(doc);
		}
	});
};



main.seatingdeal	=	function(match_id,io)
{

	

	match.findOne({ _id:match_id  },{},function(err,doc)
	{

		if(err)
		{
			return false;
		}
		else if(doc==null)
		{
			return false;
		}

		var cards=[];
		if(doc.decks==1)
		{
			cards	=['1-1','1-2','1-3','1-4','1-5','1-6','1-7','1-8','1-9','1-10','1-11','1-12','1-13',
		'2-1','2-2','2-3','2-4','2-5','2-6','2-7','2-8','2-9','2-10','2-11','2-12','2-13',
		'3-1','3-2','3-3','3-4','3-5','3-6','3-7','3-8','3-9','3-10','3-11','3-12','3-13',
		 '4-1','4-2','4-3','4-4','4-5','4-6','4-7','4-8','4-9','4-10','4-11','4-12','4-13',
		'0-0'];	
		}
		else
		{
			cards	=['1-1','1-2','1-3','1-4','1-5','1-6','1-7','1-8','1-9','1-10','1-11','1-12','1-13',
		'2-1','2-2','2-3','2-4','2-5','2-6','2-7','2-8','2-9','2-10','2-11','2-12','2-13',
		'3-1','3-2','3-3','3-4','3-5','3-6','3-7','3-8','3-9','3-10','3-11','3-12','3-13',
		 '4-1','4-2','4-3','4-4','4-5','4-6','4-7','4-8','4-9','4-10','4-11','4-12','4-13',
		'0-0','0-0',
		'1-1','1-2','1-3','1-4','1-5','1-6','1-7','1-8','1-9','1-10','1-11','1-12','1-13',
		'2-1','2-2','2-3','2-4','2-5','2-6','2-7','2-8','2-9','2-10','2-11','2-12','2-13',
		'3-1','3-2','3-3','3-4','3-5','3-6','3-7','3-8','3-9','3-10','3-11','3-12','3-13',
		 '4-1','4-2','4-3','4-4','4-5','4-6','4-7','4-8','4-9','4-10','4-11','4-12','4-13',
		'0-0'];	
		}
		

			
		var main_deck	=	shuffle(cards);



		if(doc.match_waiting_users!=null)
		{
			for(var user=0;user<doc.match_waiting_users.length;user++)
			{
				doc.match_join_users.push(doc.match_waiting_users.pop());
			}
			
		}

		var allAvailableUsers=[];
		if(doc.match_join_users!=null)
		{
			
			for(var user=0;user<doc.match_join_users.length;user++)
			{
				var roomName=doc._id+doc.match_join_users[user];
				var userConnection=findClientsSocket(roomName,io);
				//console.log('user connection ');
				//console.log(userConnection);
				if(userConnection)
				{
					//console.log('socket start');
					allAvailableUsers.push(doc.match_join_users[user]);
					//console.log('socket end');
				}

			}

			
			
			
		}
		if(allAvailableUsers.length<doc.maxPlayers)
		{
			findMeAGame_model.findOne({matchMethod:doc.matchMethod,matchFormatId:doc.matchFormatId,maxPlayers:doc.maxPlayers,waitingStatus:'waiting'},{},function(err,find_doc)
			{
				if(err)
				{
					//console.log(err);
				}
				else
				{
					if(find_doc!=null)
					{
						

						var userConnection=findClientsSocket(find_doc.userId,io);
						//console.log('findMeAGame_model start in seating');
						//console.log(find_doc.userId);
						//console.log(io.sockets.rooms);
						//console.log('findMeAGame_model end in seating');
						allAvailableUsers.push(find_doc.userId);
						

						io.to(find_doc.userId).emit('findmeagame',{matchID:doc._id,userId:find_doc.userId});
							
						if(userConnection)
						{
							
							allAvailableUsers.push(find_doc.userId);
							io.to(find_doc.userId).emit('findmeagame',{matchID:doc._id,userId:find_doc.userId});
							find_doc.waitingStatus='waiting';
						}
						else
						{
							find_doc.waitingStatus='waiting';
						}
						find_doc.save({ _id:find_doc._id},function()
						{

						});
					}
				}
			});
		}

		doc.match_join_users=unique(allAvailableUsers);
		//console.log('latest user start');
		//console.log(doc.match_join_users);
		
		//console.log('latest user end seating');
		if(doc.match_join_users.length<=1)
		{
			doc.tableStatus='seating';
		}
		
		match.update({ _id:match_id},doc,function(err,userdoc)
		{

			if(userdoc.ok==1)
			{
				if(doc.tableStatus!='seating')
				{


					doc.match_seating	=	[];
					var cards 	=	[];
					for(var k=0;k<doc.match_join_users.length;k++)
					{
						doc.match_seating.push(main_deck.pop());
						cards.push({player_id:doc.match_join_users[k],card_value:doc.match_seating[k],card_face:main.getCardImagedeal(doc.match_seating[k])});
						
					}
					////console.log(cards);
					
					for(var k=0;k<doc.match_join_users.length;k++)
					{
						//////console.log('user :'+doc.match_join_users[k]);
						for(var j=0;j<cards.length;j++)
						{
							io.to(doc.match_join_users[k]).emit('seating',cards[j]);
						}
					}
					//////console.log('old doc'+doc.match_join_users);
					var temp	=	doc.match_seating;
					for (index = 0; index < temp.length; ++index) {
			    		var val =	temp[index].split('-');
			    		//////console.log('values'+val);

			    		val 	=	parseInt(val[1]);
			    		temp[index]	=	val;	
					}
					var temp1=[];
					for(var k=0;k<temp.length;k++)
					{
						temp1.push(temp[k]);
					}

					temp1.sort(function(a, b){return b-a});
					var final_user_seat	=	[];		
					//////console.log('temp'+temp);
					//////console.log('temp1'+temp1);
					//////console.log(doc.match_seating);
					for(var k=0;k<temp1.length;k++)
					{
					 	final_user_seat.push(temp.indexOf(temp1[k]));
					}
					var temp_users	=	[];

					for(var k=0;k<temp1.length;k++)
					{
						temp_users.push(doc.match_join_users[k]);
					}

					//////console.log('user seat'+final_user_seat);

					for(var k=0;k<final_user_seat.length;k++)
					{	
						doc.match_join_users[k]	=	temp_users[final_user_seat[k]];
					}

				}
				else
				{
					for(var k=0;k<doc.match_join_users.length;k++)
					{
						var roomName=doc._id+doc.match_join_users[k];
						io.to(roomName).emit('status','please wait');
						
					}
				}
			}
			
			
			
		});

		//////console.log('new doc'+doc.match_join_users);
	});
	
};



main.createMatchdeal 	=	function(matchDetails,io)
{

	var allAvailableUsers=new Array();
	var newMatch	=	matchDetails.toObject();
	
	//cards.concat(cards)
	var cards=[];

	if(matchDetails.decks==1)
	{
		cards	=['1-1','1-2','1-3','1-4','1-5','1-6','1-7','1-8','1-9','1-10','1-11','1-12','1-13',
	'2-1','2-2','2-3','2-4','2-5','2-6','2-7','2-8','2-9','2-10','2-11','2-12','2-13',
	'3-1','3-2','3-3','3-4','3-5','3-6','3-7','3-8','3-9','3-10','3-11','3-12','3-13',
	 '4-1','4-2','4-3','4-4','4-5','4-6','4-7','4-8','4-9','4-10','4-11','4-12','4-13',
	'0-0'];	
	}
	else
	{
		cards	=['1-1','1-2','1-3','1-4','1-5','1-6','1-7','1-8','1-9','1-10','1-11','1-12','1-13',
	'2-1','2-2','2-3','2-4','2-5','2-6','2-7','2-8','2-9','2-10','2-11','2-12','2-13',
	'3-1','3-2','3-3','3-4','3-5','3-6','3-7','3-8','3-9','3-10','3-11','3-12','3-13',
	 '4-1','4-2','4-3','4-4','4-5','4-6','4-7','4-8','4-9','4-10','4-11','4-12','4-13',
	'0-0','0-0',
	'1-1','1-2','1-3','1-4','1-5','1-6','1-7','1-8','1-9','1-10','1-11','1-12','1-13',
	'2-1','2-2','2-3','2-4','2-5','2-6','2-7','2-8','2-9','2-10','2-11','2-12','2-13',
	'3-1','3-2','3-3','3-4','3-5','3-6','3-7','3-8','3-9','3-10','3-11','3-12','3-13',
	 '4-1','4-2','4-3','4-4','4-5','4-6','4-7','4-8','4-9','4-10','4-11','4-12','4-13',
	'0-0'];	
	}
			

	var main_deck	=	cards;
	shuffle(main_deck);
	delete newMatch._id;
	
	if(matchDetails.match_waiting_users!=null)
	{
		for(var user=0;user<matchDetails.match_waiting_users.length;user++)
		{
			matchDetails.match_join_users.push(matchDetails.match_waiting_users.pop());
		}
		
	}
	
	
	
	if(matchDetails.match_join_users!=null)
	{
		//console.log('old users start');
		//console.log(matchDetails.match_join_users);
		//console.log('old users end');
		for(var user=0;user<matchDetails.match_join_users.length;user++)
		{
			var roomName=matchDetails._id+matchDetails.match_join_users[user];
			var userConnection=findClientsSocket(roomName,io);
			if(userConnection)
			{
				
				allAvailableUsers.push(matchDetails.match_join_users[user]);
				
			}
			
		}
		
		//matchDetails.match_join_users=new Array();
		matchDetails.match_join_users=unique(allAvailableUsers);
		
	}
	
	if(allAvailableUsers.length<matchDetails.maxPlayers)
	{
		findMeAGame_model.findOne({matchMethod:matchDetails.matchMethod,matchFormatId:matchDetails.matchFormatId,maxPlayers:matchDetails.maxPlayers,waitingStatus:'waiting'},{},function(err,find_doc)
		{
			if(err)
			{
				//console.log(err);
			}
			else
			{
				
				if(find_doc!=null)
				{
					var userConnection=findClientsSocket(find_doc.userId,io);
					//console.log('findMeAGame_model start');
					//console.log(find_doc.userId);
					//console.log('findMeAGame_model end');
					if(userConnection)
					{
						
						allAvailableUsers.push(find_doc.userId);
						io.to(find_doc.userId).emit('findmeagame',{matchID:doc._id,userId:find_doc.userId});
						
						find_doc.waitingStatus='joined';
					}
					else
					{
						find_doc.waitingStatus='disconnected';
					}
					find_doc.save({_id:find_doc._id},function()
					{

					});
				}
			}
		});
	}

	matchDetails.match_join_users=unique(allAvailableUsers);
	//console.log('latest user start');
	//console.log(matchDetails.match_join_users);
	
	//console.log('latest user end');


	if(matchDetails.match_join_users.length!=matchDetails.maxPlayers)
	{
			
		if(matchDetails.dealTie==0)
		{
			matchDetails.tableStatus='seating';
		
			var newMatch1	=	matchDetails.toObject();
			//console.log('create match');
			
			newMatch1.match_player_card	=	[];	
			for(var k=0; k<newMatch1.match_join_users.length;k++)
			{
				newMatch1.match_player_card[k]	=	[];
				newMatch1.match_player_card[k][0]	=	[];
			}
			

			newMatch1.match_joker	=	'';
			newMatch1.match_deck_open	=	'';
			

			newMatch1.match_deck_close	=	'';
			newMatch1.match_current_player=	0;
			
			match.update({_id:matchDetails._id}, newMatch1, function(err,res)
			{
				
			});

			for(var k=0;k<matchDetails.match_join_users.length;k++)
			{
				var roomName=matchDetails._id+matchDetails.match_join_users[k];
				io.to(roomName).emit('not_enough_users',{data:1});
			}
		}


			


	}

	
	match.update({ _id:matchDetails._id},matchDetails,function(err,doc)
	{
		
		if(err)
		{

		}
		else if(doc.ok==1)
		{
			//console.log('update doc create match start');
			//console.log(doc);
			//console.log('update doc create match end');
			if(matchDetails.tableStatus=='seating')
			{
				//console.log(' in seating before ');
				for(var k=0;k<matchDetails.match_join_users.length;k++)
				{
					var roomName=matchDetails._id+matchDetails.match_join_users[k];
					io.to(roomName).emit('status','please wait');
					//console.log(roomName);
				}
				//console.log(' in seating after ');
			}
			else
			{

				


				//console.log('create match before');
				var newMatch	=	matchDetails.toObject();
				//console.log('create match');
				
				newMatch.match_player_card	=	[];
				
					
				
				getTossWinner(newMatch,matchDetails,main_deck,function(matchDetails,newMatch,begin_toss)
				{
					var temp_main_deck=main_deck;
					shuffle(temp_main_deck);
					newMatch.match_joker	=	temp_main_deck.pop();
					if(newMatch.match_joker =="0-0")
					{
						newMatch.match_joker="1-1";
					}
					shuffle(main_deck);
					for(var k=0; k<newMatch.match_join_users.length;k++)
					{
						newMatch.match_player_card[k]	=	[];
						newMatch.match_player_card[k][0]	=	[];
					}
					for(var k=0; k<newMatch.match_join_users.length;k++)
					{
						io.to(matchDetails._id+newMatch.match_join_users[k]).emit('toss_winner_info',{toss_winner:newMatch.match_toss_winner,your_card:begin_toss[k]});
					
					}
					var i= 0;
					while(newMatch.match_player_card[(newMatch.match_join_users.length-1)][0].length<13)
					{
						if(!newMatch.match_player_card[i])
						{
							newMatch.match_player_card[i]=	[[],[],[],[],[],[],[]];
							newMatch.match_player_card[i][0]=	new Array();
						}
						
						if(newMatch.match_player_card[i][0])
						{
						newMatch.match_player_card[i][0].push(main_deck.pop());
						}
						if(i==(newMatch.match_join_users.length-1))
						{
							i=0;
						}
						else
						{
							i++;
						}
						//////console.log(newMatch.match_player_card);
					
					}
					


					newMatch.match_deck_open	=	main_deck.pop();
					

					newMatch.match_deck_close	=	main_deck;
					//newMatch.match_current_player=	newMatch.match_join_users.length-1;
					
					match.update({_id:matchDetails._id}, newMatch, function(err,res)
					{
						if(err)
						{
							//////console.log(err);
							//console.log('/////////////////////');
							//console.log(err);
							//console.log('/////////////////////');
							return 'failed';
						}
						else
						{ 

							for(var k=0;k<matchDetails.match_join_users.length;k++)
							{
								var roomName=matchDetails._id+matchDetails.match_join_users[k];
								io.to(roomName).emit('reload',{data:1});
							}
							if(matchDetails.deal_match_watch_list!=undefined || matchDetails.deal_match_watch_list.length>0)
							{
								for(var k=0;k<matchDetails.deal_match_watch_list.length;k++)
								{
									var roomName=matchDetails._id+matchDetails.deal_match_watch_list[k];
									io.to(roomName).emit('reload',{data:1});
								}
							}
							
							////console.log(matchDetails.match_join_users);
							setTimeout(function(){

								main.startMatchdeal(matchDetails._id,io);
							},3000);

							
							return res;
						}
					});
				});
				

			}
		}
		

		//console.log('update declare match');
	});

	
}



main.getAllConnectedUsersdeal	=	function (match_id,data,io)
{

	match.findOne({_id:match_id},{},function (err,matchResult)
	{
		var k=0;
		for(var k_user=0;k_user<matchResult.match_join_users.length;k_user++)
		{
			var roomName=matchResult._id+matchResult.match_join_users[k_user];
			io.to(roomName).emit('chat',data)	
			//console.log('getAllConnectedUsers start');
			//console.log(data);
			//console.log('getAllConnectedUsers end');
		}	
	});
}

var shuffle 	=function(o)
{
	for(var j, x, i = o.length; i; j = Math.floor(Math.random() * i), x = o[--i], o[i] = o[j], o[j] = x);
    return o;
}
main.getCardImagedeal	=	function (name)
{
	if(!name)
	{
		return false; 
	}
	var temp	=	name.split('-');
	var suite,card;
    //	//////console.log(temp[0]);	
	if(temp[0]=='1')
	{
		suite=	'c';
	}	
	else if(temp[0]=='2')
	{
		suite=	's';
	}
	else if(temp[0]=='3')
	{
		suite=	'd';
	}
	else if(temp[0]=='4')
	{
		suite=	'h';
	}
	else
	{
		suite=	'j';
	}
	
	if(temp[1]=='11')
	{
		card=	'j';
	}	
	else if(temp[1]=='12')
	{
		card=	'q';
	}
	else if(temp[1]=='13')
	{
		card=	'k';
	}
	else 
	{
		card=	temp[1];
	}
	return suite+card;
	
}

module.exports	=	main;

function findClientsSocket(roomId, io) {
    var namespace='';
    var res = []
    , ns = io.of(namespace ||"/");    // the default namespace is "/"

    if (ns) {
        for (var id in ns.connected) {
            if(roomId) {
                var index = ns.connected[id].rooms.indexOf(roomId) ;
                if(index !== -1) {
                    res.push(ns.connected[id]);
                }
            } else {
                res.push(ns.connected[id]);
            }
        }
    }
   
    if(res.length>0)
    {
    	return 1;
    }
    else
    {
    	return 0;
    }
    
}


function deductwalletAmount (userId,walletdeductAmount)
{
	var userId=userId;
    var walletdeductAmount=walletdeductAmount;
    /*Get user info by user Id*/
    user_model.findOne({ _id:userId}, {},function (err, userDoc) {

        if(err)
        {
            //console.log(err);
            return res.send(err);
        }
        else
        {
            var userId=userDoc._id;
            var userEmail=userDoc.email;
            var firstname=userDoc.firstname;
            wallet_model.findOne({ userId:userId}, {},function (err, userDoc) {


                var amount=0;
                if(userDoc==null)
                {
                    amount=0;

                }
                else
                {
                    if(parseFloat(userDoc.amount)>=parseFloat(walletdeductAmount))
                    {
                        amount=parseFloat(walletdeductAmount);
                    }
                    else
                    {
                        
                        return 0;
                    }

                    var walletTransactionDetail    =   new walletTransactionDetail_model({userId:userId,amount:walletdeductAmount,currency:'USD',transactionType:'Debit'});
                    walletTransactionDetail.save(function (err,doc)
                    {
                        if(err)
                        {
                            //res.send({success:0,data:err});
                            return 0;
                        }
                        else
                        {
                          return 1;
                           // res.send({success:1,data:doc});
                        }
                    });
                    
                }

                
            });

        }
    });
}

function addwalletAmount(userId,transactionType,paymentMethod,currency,amount)
{
	var walletTransactionDetail    =   new walletTransactionDetail_model({userId:userId,amount:amount,currency:currency,paymentMethod:paymentMethod,transactionType:transactionType});
        walletTransactionDetail.save(function (err,doc)
        {
            if(err)
            {
                return 0;
            }
            else
            {
               return 1;
                //res.send({success:1,data:doc});
            }
        });
}
function deductUserPoint(userId,points)
{
	  
    var points=points;
    user_model.findOne({ _id:userId}, {},function (err, userDoc)
    {
    	if(err)
        {
            //console.log(err);
            return res.send(err);
        }
        else
        {
           	if(userDoc!=null)
           	{
           		
           		var userPoints=parseFloat(userDoc.userPoints)-parseFloat(points);

	           	user_model.findOneAndUpdate({ _id:userId}, {userPoints:userPoints},function (err, userDoc)
			    {
   					if(err)
   					{
   						//console.log(err);
   					}
			    });
           	}
           	
        }
    });
}

function addUserPoint(userId,points)
{
	  
    var points=points;
    user_model.findOne({ _id:userId}, {},function (err, userDoc)
    {
    	if(err)
        {
            //console.log(err);
            return res.send(err);
        }
        else
        {
           	if(userDoc!=null)
           	{
           		
           		var userPoints=parseFloat(userDoc.userPoints)+parseFloat(points);

	           	user_model.findOneAndUpdate({ _id:userId}, {userPoints:userPoints},function (err, userDoc)
			    {
   					if(err)
   					{
   						//console.log(err);
   					}
			    });
           	}
           	
        }
    });
}
/*remove duplicates value from array*/
var unique = function(arr) {
    var a = [];
    for ( i = 0; i < arr.length; i++ ) {
        var current = arr[i];
        if (a.indexOf(current) < 0) a.push(current);
    }

    arr.length = 0;
    for ( i = 0; i < a.length; i++ ) {
        arr.push( a[i] );
    }

    return arr;
}

var getWinnerInfo = function(doc,callback)
{
	var winnerPoints=0;
	var winnerId='-1';
	for(var m_declare_count=0;m_declare_count<doc.match_declare.length;m_declare_count++)
	{
		if(m_declare_count==0)
		{
			winnerPoints=doc.match_declare[m_declare_count].points;
			winnerId=doc.match_declare[m_declare_count].player_id;
		}
		else
		{
			if(winnerPoints>doc.match_declare[m_declare_count].points)
			{
				winnerPoints=doc.match_declare[m_declare_count].points;
				winnerId=doc.match_declare[m_declare_count].player_id;
			}
		}
		if(m_declare_count==(doc.match_declare.length-1))
		{
			callback(doc,winnerId,winnerPoints);
		}
	}

}

var declareGameWinner = function(doc,winnerId,winnerPoints,callback)
{
	for(var m_declare_count=0;m_declare_count<doc.match_declare.length;m_declare_count++)
	{
		if(winnerId==doc.match_declare[m_declare_count].player_id)
		{
			doc.match_declare[m_declare_count].status="win";
		}
		else
		{
			doc.match_declare[m_declare_count].status="loss";
		}
		if(m_declare_count==(doc.match_declare.length-1))
		{
			callback(doc,winnerId,winnerPoints);
		}

	}
}





function checkUserCards(previous_user,total_cards,doc,callback)
{
	var match_last_moved_card=doc.match_last_moved_card;

	if(total_cards>13)
	{
		var flag=false;
		for(var i=0 ; i<=6;i++)
		{
			var arr=doc.match_player_card[previous_user][i];
			if (doc.match_player_card[previous_user][i]!=null)
			{
			  
				//console.log(doc.match_player_card[previous_user][i].indexOf(match_last_moved_card));
				if (doc.match_player_card[previous_user][i].indexOf(match_last_moved_card)!=-1)
				{
				  // found it
				  	doc.match_player_card[previous_user][i].splice(doc.match_player_card[previous_user][i].indexOf(match_last_moved_card),1);
				  	if(doc.match_deck_open.constructor=== Array)
					{ 
						doc.match_deck_open.push(match_last_moved_card);
					}
					else
					{
						if(doc.match_deck_open!=null || doc.match_deck_open!='')
						{
							var temp_match_deck_open=doc.match_deck_open;
							doc.match_deck_open=[];
							doc.match_deck_open.push(temp_match_deck_open);
							doc.match_deck_open.push(match_last_moved_card);
						}
						

						doc.match_deck_open	=	[match_last_moved_card];
					}
					var temp_match_join_users=doc.match_join_users;
					
					match.findOneAndUpdate({_id:doc._id},{match_player_card:doc.match_player_card,match_deck_open:doc.match_deck_open},function(err,matchdoc)
					{
						
						if(err)
						{
							//////console.log(err);
						}
						else
						{ 
							
							//console.log('player id '+matchdoc.match_join_users[previous_user]);
							//console.log('previous user '+previous_user);
							//console.log('matchdoc ');
							//console.log(matchdoc.match_join_users);
							var roomName=doc._id+matchdoc.match_join_users[previous_user];   
							if(typeof doc.match_player_card[previous_user] !='undefined' || doc.match_player_card[previous_user]!=null)
							{
								var cards=[];

								for(group in doc.match_player_card[previous_user])
								{
										
									//		//////console.log(matchResult.match_player_card[player_id][group]);
									////////console.log(group);
										
									var i=0;		
									if(!cards[group])
									{
										cards[group]	=	[];
									}
									for(card in doc.match_player_card[previous_user][group])
									{
										
										cards[group][card]	={card_value:doc.match_player_card[previous_user][group][card],card_face:main.getCardImagedeal(doc.match_player_card[previous_user][group][card])};	
										
										
									}
									
								
								}
								//console.log('update card socket before');
								setTimeout(function()
								{
									//console.log('update card socket at '+roomName+' room info=>'+main.io.sockets.adapter.rooms[roomName]);
									main.io.to(roomName).emit('update_card',{cards:cards});
								},1000);
								
							}


							

						}
						
					});

					flag=true;
					callback(previous_user,doc);
				  break;
				}
			}

			if(i==6 && flag==false)
			{
				callback(previous_user,doc);
			}

		}
		
	}
	else
	{
		callback(previous_user,doc);
	}
}
function getUserTotalCards(previous_user,doc,callback)
{
	
               		
	var total_cards=0;
	for(var i=0 ; i<=6;i++)
	{
		if (doc.match_player_card[previous_user][i]!=null)
		{
		  total_cards=total_cards+doc.match_player_card[previous_user][i].length;
		}
		if(i==6)
		{
			//console.log('getUserTotalCards callback start');
			callback(previous_user,total_cards,doc);
			//console.log('getUserTotalCards callback end');
		}
	}
}
function getTossWinner(newMatch,matchDetails,main_deck,callback)
{
	var begin_toss=[];
	for(var k=0; k<newMatch.match_join_users.length;k++)
	{
		newMatch.match_player_card[k]	=	[];
		newMatch.match_player_card[k][0]	=	[];
		var splitCards = main_deck[k].split('-');
		begin_toss.push(splitCards[1]);
		
		if(k==(newMatch.match_join_users.length-1))
		{
			var winnerCardValue = Math.max.apply(Math,begin_toss);

			var temp_begin_toss=begin_toss;
			var winnerCardKey = begin_toss.indexOf(winnerCardValue.toString());
			var tossWinner=newMatch.match_join_users[winnerCardKey];
			
			
			newMatch.match_toss_winner=tossWinner;
			var temp_join_user=newMatch.match_join_users;
			//console.log('temp_join_user start');
			//console.log(temp_join_user);
			//console.log('temp_join_user end');
			newMatch.match_join_users=[];
			for(var toss_k=0;toss_k<temp_join_user.length;toss_k++)
			{
				//console.log('in for '+toss_k);
				newMatch.match_join_users.push(temp_join_user[temp_begin_toss.indexOf(Math.max.apply(Math,temp_begin_toss).toString())]);
				temp_begin_toss[temp_begin_toss.indexOf(Math.max.apply(Math,temp_begin_toss).toString())]='-1';
				//console.log(temp_begin_toss);
				//temp_begin_toss.splice(temp_begin_toss.indexOf(Math.max.apply(Math,temp_begin_toss).toString()),1);
				
				if(toss_k==(temp_join_user.length-1))
				{
					if(winnerCardKey==0)
					{
						newMatch.match_current_player=(newMatch.match_join_users.length-1);
					}
					else
					{
						newMatch.match_current_player=winnerCardKey-1;
					}

					//console.log('newMatch.match_join_users start');
					//console.log(newMatch.match_join_users);
					//console.log('newMatch.match_join_users end');
					callback(matchDetails,newMatch,begin_toss);
				}

			}


			
			
			
		}
	}
}

function getConnectedUsersInfo_callback(matchResult,callback)
{
	var user=[];
	var k=0;
	var count_user=0;
	for(var k_user=0;k_user<matchResult.match_join_users.length;k_user++)
	{
		var roomName=matchResult._id+matchResult.match_join_users[k_user];
		user_model.findOne({_id:matchResult.match_join_users[k_user]},{},function(err,user_result)
		{
			if(err)
			{

			}
			else
			{
				
				if(user_result!=null)
				{
					user[k]={};
					user[k].user_id=user_result._id;
					user[k].name=user_result.firstname;
					user[k].gender=user_result.gender;
					k++;
					

				}

			}
			
			
			if(count_user==(matchResult.match_join_users.length-1))
			{
				//console.log('getConnectedUsersInfo_callback');
				callback(matchResult,user);
			}
			count_user++;
		});	
		

		
	}
}
function getUserTotalPointsDeal(doc,player_id,declare_deal_username,points,callback)
{
	/*console.log('docdocdocdocdocdocdocdocdocdocdoc')
	console.log(doc);
	console.log('doc.deal_currentMatch_userpoints.length start');
	console.log(doc.deal_currentMatch_userpoints.length);*/
	//console.log('doc.deal_currentMatch_userpoints.length end');
	//var temp_points=points;
	if(doc.deal_currentMatch_userpoints=='')
	{
		doc.deal_currentMatch_userpoints={};
	}
	if(!doc.deal_currentMatch_userpoints.hasOwnProperty(player_id))
	{
		doc.deal_currentMatch_userpoints[player_id]=[];
	}
	

	var user_points=0;
	var i=0;
	/*get player cards start*/
		var temp_match_player_card=[[]];
		if(typeof doc.match_player_card !='undefined' || doc.match_player_card!=null)
		{
			var players_id	=	doc.match_join_users.indexOf(player_id);
			for(group in doc.match_player_card[players_id])
			{
				if(temp_match_player_card[group]==undefined)
				{
					temp_match_player_card[group]	=	[];
				}
				if(doc.match_player_card[players_id][group]!=undefined && doc.match_player_card[players_id][group]!=null )
				{
					for(card in doc.match_player_card[players_id][group])
					{
						if(temp_match_player_card[group][card]==undefined)
						{
							temp_match_player_card[group][card]	=	[];
						}
						if(doc.match_player_card[players_id][group][card]!=undefined && doc.match_player_card[players_id][group][card]!=null)
						{
							temp_match_player_card[group][card]	={card_value:doc.match_player_card[players_id][group][card],card_face:main.getCardImagedeal(doc.match_player_card[players_id][group][card])};	
						
						}
							
					}
				}

				
				
			
			}
		}
	/*get player cards end*/
	console.log('current_match_user_points start')
	console.log(doc.current_match_user_points);
	console.log('current_match_user_points end');
	console.log('doc.deal_currentMatch_userpoints[player_id].length =>'+doc.deal_currentMatch_userpoints[player_id].length);
	if(doc.deal_currentMatch_userpoints[player_id].length<=0)
	{
		console.log('in side if conditon');
		doc.deal_currentMatch_userpoints[player_id].push({points:points,total_points:parseInt(points)});
		doc.match_declare.push({player_id:player_id,points:parseInt(points),username:declare_deal_username,declare_player_cards:temp_match_player_card,total_points:parseInt(points)});
		doc.currentDeal=doc.deal_currentMatch_userpoints[player_id].length;
		callback(doc);
	}
	else
	{
		for(var points_k=0;points_k<doc.deal_currentMatch_userpoints[player_id].length;points_k++)
		{
			user_points=user_points+parseInt(doc.deal_currentMatch_userpoints[player_id][i].points);
			if(i==(doc.deal_currentMatch_userpoints[player_id].length-1))
			{
				user_points=user_points+parseInt(points);
				doc.deal_currentMatch_userpoints[player_id].push({points:points,total_points:user_points});
				doc.match_declare.push({player_id:player_id,points:points,username:declare_deal_username,declare_player_cards:temp_match_player_card});
				doc.currentDeal=doc.deal_currentMatch_userpoints[player_id].length;
				callback(doc);
				break;
			}
			i++;
		}
	}
	
	
}

function getDealWinnerInfo(doc,callback)
{
	
	var winnerPoints=0;
	var winnerId='-1';
	
	var i=0;

	//console.log('(doc.current_match_user_points)');
	//console.log(doc.current_match_user_points);
	////console.log(Object.keys(doc.current_match_user_points).length);
	for (var key in doc.current_match_user_points) {
		
		if (doc.current_match_user_points.hasOwnProperty(key)) {
			if(winnerPoints<parseInt(doc.current_match_user_points[key]))
			{
				winnerPoints=parseInt(doc.current_match_user_points[key]);
				winnerId=key;
			}
		  	
		}
		if(i==(Object.keys(doc.current_match_user_points).length-1))
		{
			
			duplicates_winner_keyFunction(doc,winnerId,doc.current_match_user_points,winnerPoints,function(doc,winnerId,winnerPoints,duplicates_winner_keys)
			{
				if(doc.matchMethod=="cash")
				{
					for(var j=0;j<doc.match_join_users.length;j++)
					{
						deductwalletAmount(doc.match_join_users[j],doc.entryFee);	
						
					}
				}
				else
				{
					for(var j=0;j<(doc.match_join_users.length-1);j++)
					{
						deductUserPoint(doc.match_join_users[j],doc.entryFee);	
						
					}
				}
				
				if(doc.matchMethod=="cash")
				{
					addwalletAmount(winnerId,'Credit','admin','USD',doc.prize);
				}
				else
				{
					addUserPoint(winnerId,doc.prize);	
				}
				

				//console.log('JSON.parse(duplicates_winner_keys)');
				
				callback(doc,winnerId,winnerPoints,duplicates_winner_keys);
			});
			

			break;
		}
		i++;
	}
}

function getDealTieWinnerInfo(doc,callback)
{
	var winnerPoints=0;
	var winnerId='-1';
	
	var i=0;

	
	for (var key in doc.current_match_user_points)
	{
		
		if (doc.current_match_user_points.hasOwnProperty(key)) {
			if(winnerPoints<=parseInt(doc.current_match_user_points[key]))
			{
				winnerPoints=parseInt(doc.current_match_user_points[key]);
				winnerId=key;
			}
		  	
		}
		if(i==(Object.keys(doc.current_match_user_points).length-1))
		{
			
			

			if(doc.matchMethod=="cash")
			{
				addwalletAmount(winnerId,'Credit','admin','USD',doc.prize);
			}
			else
			{
				addUserPoint(winnerId,doc.prize);	
			}
			
			callback(doc,winnerId);
			break;
		}
		i++;
	}	
}
 
function getcurrentDealWinnerInfo(doc,callback)
{
	console.log('inside getcurrentDealWinnerInfo');
	var winnerPoints=0;
	var winnerId='-1';
	var totalPoints=0;
	var totalDealPoints = 0;
	/*console.log('if');
	console.log('doc.match_declare start');
	console.log(doc.match_declare);
	console.log('doc.match_declare end');*/
	var dropNdeclareData = [];
	doc.dropNdeclareData = doc.match_declare;
	var temp_declare = [];
	if(doc.drop_users.length == 0){
		dropNdeclareData = doc.match_declare;	
	}else if(Object.keys(doc.drop_users).length > 0 )
	{
		for(var key in doc.drop_users)
		{
			temp_declare.push({player_id:doc.drop_users[key].player_id,points:doc.drop_users[key].points,username:doc.drop_users[key].username,declare_player_cards:doc.drop_users[key].declare_player_cards,status:doc.drop_users[key].status,total_user_chips:doc.drop_users[key].total_user_chips});

		}
		 doc.dropNdeclareData = doc.match_declare.concat(temp_declare); 								
		 console.log('doc.dropNdeclareData start');
		 console.log(doc.dropNdeclareData);
		 console.log('doc.dropNdeclareData startend');

	}
	doc.update({_id:doc._id},doc,function (err,tabledoc)
	{
	});

	console.log('dropNdeclareData=>'+doc.dropNdeclareData);

	var dropNdeclareData = doc.dropNdeclareData;
	for(var points_k=0;points_k < dropNdeclareData.length;points_k++)
	{		
		if(points_k==0)
		{
			winnerPoints=parseInt(dropNdeclareData[points_k].points);
			winnerId=dropNdeclareData[points_k].player_id;
		}
		else
		{
			if(winnerPoints>parseInt(dropNdeclareData[points_k].points))
			{
				winnerPoints=dropNdeclareData[points_k].points;
				winnerId=dropNdeclareData[points_k].player_id;
			}
		}

		totalPoints=totalPoints+parseInt(dropNdeclareData[points_k].points)
		console.log('totalPoints start');
		console.log(totalPoints);
		console.log('totalPoints end');

		if(points_k==(dropNdeclareData.length-1))
		{
			console.log('first if');
			console.log(totalPoints);
			for(var m_declare_count=0;m_declare_count<dropNdeclareData.length;m_declare_count++)
			{
				if(winnerId==dropNdeclareData[m_declare_count].player_id)
				{
					dropNdeclareData[m_declare_count].status="win";
					totalPoints=totalPoints-parseInt(dropNdeclareData[m_declare_count].points);
					doc.current_match_user_points[dropNdeclareData[m_declare_count].player_id]=parseInt(doc.current_match_user_points[dropNdeclareData[m_declare_count].player_id])+totalPoints;
					dropNdeclareData[m_declare_count].total_user_chips=doc.current_match_user_points[dropNdeclareData[m_declare_count].player_id];
				}
				else
				{
					if(dropNdeclareData[m_declare_count].status == 'Dropped'){
						doc.current_match_user_points[dropNdeclareData[m_declare_count].player_id]= parseInt(dropNdeclareData[m_declare_count].total_user_chips);
						dropNdeclareData[m_declare_count].status="Dropped";	
						dropNdeclareData[m_declare_count].total_user_chips=doc.current_match_user_points[dropNdeclareData[m_declare_count].player_id];
						console.log('in drop secton doc.current_match_user_points[dropNdeclareData[m_declare_count].player_id]')
						console.log(doc.current_match_user_points[dropNdeclareData[m_declare_count].player_id]);
						console.log('doc.current_match_user_points[dropNdeclareData[m_declare_count].player_id] end');
					}else{
						doc.current_match_user_points[dropNdeclareData[m_declare_count].player_id]=parseInt(doc.current_match_user_points[dropNdeclareData[m_declare_count].player_id])-parseInt(dropNdeclareData[m_declare_count].points);
						dropNdeclareData[m_declare_count].status="loss";
						dropNdeclareData[m_declare_count].total_user_chips=doc.current_match_user_points[dropNdeclareData[m_declare_count].player_id];
						console.log('doc.current_match_user_points[dropNdeclareData[m_declare_count].player_id]')
						console.log(doc.current_match_user_points[dropNdeclareData[m_declare_count].player_id]);
						console.log('doc.current_match_user_points[dropNdeclareData[m_declare_count].player_id] end');
					}
					
				}
				if(m_declare_count==(dropNdeclareData.length-1))
				{
					/*console.log('m_declare_count start');
					console.log(m_declare_count);
					console.log('m_declare_count end');
					console.log(totalPoints);*/
					match.update({_id:doc._id},doc,function(err)
					{

					});
					callback(doc,winnerId,totalPoints);
				}

			}
			
		}
	}
}	

function getCurrentConnectedUsersdeal(doc,callback)
{
	 var connectedUsers=0;
	for(var temp_k=0; temp_k<doc.match_join_users.length;temp_k++)
    {
    	
    	var roomname=doc._id+doc.match_join_users[temp_k];  
    	
    	var emit_status=findClientsSocket(roomname,main.io);
    	if(emit_status)
    	{
    		connectedUsers++;
    	}
    	if(temp_k==(doc.match_join_users.length-1))
    	{
    		callback(doc,connectedUsers);
    	}		
    } 
}
function duplicates_winner_keyFunction(doc,winnerId,current_match_user_points,winnerPoints,callback)
{
	var duplicates_winner_keys = [];
	//console.log('duplicates_winner_keyFunction 1');
	if(Object.keys(current_match_user_points).length>0)
	{
		var i=0;
		for (var key in current_match_user_points)
		{
		    if (winnerPoints == current_match_user_points[key]) {
		        duplicates_winner_keys.push(key);
		    }
		    //console.log('duplicates_winner_keyFunction 2');
		    if(i==Object.keys(current_match_user_points).length-1)
		    {
		    	//console.log('duplicates_winner_keyFunction 3');
		    	//console.log(winnerPoints);
		    	callback(doc,winnerId,winnerPoints,duplicates_winner_keys);
		    	break;
		    }
		    i++;
		}
	}
	else
	{
		//console.log('duplicates_winner_keyFunction 4');
		callback(doc,winnerId,winnerPoints,duplicates_winner_keys);
	}
	

}

function dctMnybeforeTiebreakerMatch(doc,winnerId,winnerPoints,duplicates_winner_keys,callback)
{
	if(doc.matchMethod=="cash")
	{
		for(var j=0;j<doc.match_join_users.length;j++)
		{
			deductwalletAmount(doc.match_join_users[j],doc.entryFee);	
			if(j==(doc.match_join_users.length-1))
			{
				callback(doc,winnerId,winnerPoints,duplicates_winner_keys);
				break;
			}
		}
	}
	else
	{
		for(var j=0;j<(doc.match_join_users.length-1);j++)
		{
			deductUserPoint(doc.match_join_users[j],doc.entryFee);	
			if(j==(doc.match_join_users.length-1))
			{
				callback(doc,winnerId,winnerPoints,duplicates_winner_keys);
				break;
			}
		}
	}
}

function beforeTiebreakerMatch(doc,winnerId,winnerPoints,duplicates_winner_keys,callback)
{
	if(duplicates_winner_keys.length>1)
	{
		
		for(var i=0; i<doc.match_join_users.length;i++)
		{
			if(duplicates_winner_keys.indexOf(doc.match_join_users[i])==-1)
			{
				doc.deal_match_watch_list.push(doc.match_join_users[i]);
			}
			if(i==(doc.match_join_users.length-1))
			{
				doc.match_join_users=duplicates_winner_keys;
				doc.dealTie=1;
				doc.save(function(err,tabledoc){});
				callback(doc,winnerId,winnerPoints,duplicates_winner_keys);
				break;
			}
		}
	}
	else
	{
		callback(doc,winnerId,winnerPoints,duplicates_winner_keys);
		
	}
	
}
				
