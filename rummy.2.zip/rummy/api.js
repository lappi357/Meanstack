
module.exports = function(router,io)
{
	require(__dirname+'/controllers/users.js')(router);
	require(__dirname+'/controllers/wallet.js')(router);
	require(__dirname+'/controllers/paypalpayment.js')(router);
	require(__dirname+'/controllers/tournaments.js')(router);
	require(__dirname+'/controllers/table.js')(router,io);
	require(__dirname+'/controllers/game.js')(router,io);
};