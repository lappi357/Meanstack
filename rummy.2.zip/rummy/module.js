var game	=	angular.module('game', ['ngCookies','ngRoute']);
var declare_timeout='';
game.controller('tableCtrl',['$http','$scope','$cookieStore','$route','$routeParams','$location',function($http,$scope,$cookieStore,$route,$routeParams,$location)
{
//	   alert(getParameterByName('q'));

   	$scope.match_id	=	getParameterByName('q');
   	$scope.player_id	=	getParameterByName('p');
   	$scope.table_name	=	'';
   	$scope.otherUser={check:false};
   	$scope.match_users1=[];
   	$scope.allUsersList=[];
   	$scope.current_user_name='';
   	$scope.current_user_gender='';
   	$scope.current_user_chips='';
   	$scope.connectedUser1_name='';
   	$scope.connectedUser2_name='';
   
   	$scope.connectedUser3_name='';
   	$scope.connectedUser4_name='';
   	$scope.connectedUser6_name='';
   	$scope.connectedUser1_gender='';
   	$scope.connectedUser2_gender='';
   	$scope.connectedUser3_gender='';
   	$scope.connectedUser4_gender='';
   	$scope.connectedUser6_gender='';
   	$scope.connectedUser1_playerid='';
   	$scope.connectedUser2_playerid='';
   	$scope.connectedUser3_playerid='';
   	$scope.connectedUser4_playerid='';
   	$scope.connectedUser6_playerid='';
   	$scope.connectedUser1_chips=0;
   	$scope.connectedUser2_chips=0;
   	$scope.connectedUser3_chips=0;
   	$scope.connectedUser4_chips=0;
   	$scope.connectedUser6_chips=0;
   	$scope.li_left_postion=0;
   	$scope.li_z_index=0;
   	$scope.isDrop = 0;
   	$scope.isDeclare = 0;
   	$scope.wrongDeclare = 0;
	$scope.declare =	function ()
	{
	 		 	if(!$scope.removeCardCheck)
	 	{
		 	jQuery('#declare_button').attr("disabled", "disabled");
		 	/*$http.jsonp('http://mobirummy.com/declare/'+$scope.match_id+'/'+$scope.player_id+'/'+$scope.total_points+'/'+$scope.current_user_name+'/'+$scope.wrongDeclare+'?callback=JSON_CALLBACK').
			  success(function(data, status, headers, config) {
			  	
			  });*/
			$http.jsonp('http://mobirummy.com/declare/'+$scope.match_id+'/'+$scope.player_id+'/'+$scope.total_points+'/'+$scope.current_user_name+'/'+$scope.wrongDeclare+'?callback=JSON_CALLBACK').
			  success(function(data, status, headers, config) {
			  	
			  });
			  clearTimeout(declare_timeout);
			  $scope.isDeclare=1;
			  $scope.declare  = 1;     
			  if($scope.isDeclare == 1 && $scope.declare  == 1 ){
			  	jQuery('#rc_drop').modal('show');
			  }
		}
		else
		{
			alert('Please discard one card first to declare the game.');
		}
	};

	$scope.drop =	function ()
	{
	 	if(!$scope.removeCardCheck)
	 	{
		 	$http.jsonp('http://mobirummy.com/dropPoints/'+$scope.match_id+'/'+$scope.player_id+'/'+$scope.current_user_name+'/'+$scope.total_points+'?callback=JSON_CALLBACK').
			  success(function(data, status, headers, config) {
			  	
			  });
			  $scope.isDrop = 1;
			  $scope.drop = 1;
		}
		else
		{
			alert('Please discard one card first to declare the game.');
		}
	};


	$scope.leave_table = function()
	{
		if (confirm("Are you sure?")) {
		   open("about:blank", '_self').close();
		    
		}
	};
    $scope.getCards	=	function()
	{

		$scope.firstname	=	'Dev';
		$scope.lastname		=	'Kishore';
		$scope.match_joker	=	8;
		$scope.player_cards	=	[[],[],[],[],[],[],[]];
		$scope.removeCardCheck	=	false;
		$scope.player_cards[1]	=	[];
		$scope.player_cards[2]	=	[];
		$scope.player_cards[3]	=	[];
		$scope.player_cards[4]	=	[];
		$scope.player_cards[5]	=	[];
		$scope.player_cards[6]	=	[];
		$scope.checkC		    =   1;
			
		

			
		$http.jsonp('http://mobirummy.com/match/'+$scope.match_id+'/'+$scope.player_id+'?callback=JSON_CALLBACK').
		success(function(data, status, headers, config) {

			if(data.match_join_users[data.match_current_player]!=data.user._id)
			{
			  	//alert('your turn');
			}

			$scope.table_name=data.table_name;
	               
			if(data.deck_open.constructor === Array)
			{
				$scope.deck_open	=	data.deck_open[data.deck_open.length-1];
			}
			else
			{
				$scope.deck_open	=	data.deck_open;
			}

			jQuery('#open_deck').attr('src','images/'+$scope.deck_open.card_face+'.png');
				
			
			$scope.match_deck_open=data.match_deck_open;
			$scope.matchFormatId	=data.matchFormatId;
			$scope.decks	=data.decks;
			$scope.matchMethod	=data.matchMethod;
			$scope.maxPlayers	=data.maxPlayers;
			$scope.deals	=data.deals;
			$scope.poolType	=data.poolType;
			$scope.prize	=data.prize;
			$scope.entryFee	=data.entryFee;
			$scope.pointValue	=data.pointValue;
			
			$scope.deck_joker =   data.deck_joker;
	        var match_joker =   data.deck_joker.split('-');
	            
	        $scope.match_joker  =   match_joker[1];
	        jQuery('#joker_card').attr('src','images/s'+$scope.match_joker+'.png');
		    if(match_joker[1]==13)
	        {
	            $scope.match_joker_face =   'sk';
	        }
	        else if(match_joker[1]==12)
	        {
	            $scope.match_joker_face =   'sq';
	        }
	        else if(match_joker[1]==11)
	        {
	            $scope.match_joker_face =   'sj';
	        }
	        else{
	        	$scope.match_joker_face =   's'+match_joker[1];
	        }
	                    //////console.log($scope.deck_open);
				
				
			if(data.deck_close.constructor === Array)
			{
				$scope.deck_close	=	data.deck_close[data.deck_close.length-1];
			}
			$scope.player_cards	=	data.match_player_card;
			
			if($scope.player_cards[0].length>0)
			{
				$scope.declareFlag = true;
			}
			else
			{
				$scope.declareFlag =false
			}
			//console.log($scope.player_cards);
	        ////console.log(data.match_player_card[0]);
			for(var i=0;i<7;i++)
			{
				if(!$scope.player_cards[i])
				{
					$scope.player_cards[i]=[];
				}
			}
			$scope.arrangeCard();	
			$scope.validate();
			$scope.allUsersList=data.allUsersList;
			$scope.user	=	data.user;
			$scope.current_user_name='';
			$scope.current_user_chips='';
   			$scope.current_user_gender='';
   			$scope.userListWTcrtUser=[];
   			$scope.current_user_key=-1;
			$(data.allUsersList).each(function (key,val)
			{
				//console.log('data.allUsersList start');
				//console.log(data.allUsersList);
				//console.log('data.allUsersList end');
			 	if(val!=null)
			 	{
			 		if(val.user_id==$scope.player_id)
				 	{
				 		
				 		$scope.current_user_name=val.name;
	   					$scope.current_user_gender=val.gender;
	   					$scope.current_user_chips=val.userPoints;
	   					//console.log('key end');
	   					//console.log(val.userPoints);
	   					//console.log('key end');
	   					$scope.current_user_key=key;
	   					
			  		}
			  		
			  		
			 	}
			 	
			});
			var i=0;
			var last_seat=5;
			var last_seat_user_key=-1;

			$(data.allUsersList).each(function (key,val)
			{
			 	if(val!=null)
			 	{
			 		if($scope.current_user_key==key)
				 	{
				 		//console.log($scope.current_user_key);
				 		i++;
				 		last_seat=5;
	   					
			  		}
			  			
			 	}
			 	
			});

			var j=0;
			
			$(data.allUsersList).each(function (key,val)
			{
			 	if(val!=null)
			 	{
			 		//console.log(key);
			 		if($scope.current_user_key<=key )
				 	{
				 		if($scope.current_user_key!=key )
					 	{
					 		
			  				if(last_seat_user_key!=key)
			  				{
			  					if(last_seat==6)
				  				{
				  					$scope.connectedUser3_name=val.name;
				  					$scope.connectedUser3_gender=val.gender;
				  					$scope.connectedUser3_playerid=val.user_id;
				  					$scope.connectedUser3_chips=val.userPoints;
					  				
					  				last_seat=3;
					  				
				  				}
				  				else if(last_seat==3)
				  				{
				  					$scope.connectedUser2_name=val.name;
				  					$scope.connectedUser2_gender=val.gender;
				  					$scope.connectedUser2_playerid=val.user_id;
				  					$scope.connectedUser2_chips=val.userPoints;
					  				
					  				last_seat=2;
					  				
				  				}
				  				else if(last_seat==2)
				  				{
				  					$scope.connectedUser1_name=val.name;
				  					$scope.connectedUser1_gender=val.gender;
				  					$scope.connectedUser1_playerid=val.user_id;
				  					$scope.connectedUser1_chips=val.userPoints;
					  				
					  				last_seat=1;
					  				
				  				}
				  				else if(last_seat==1)
				  				{
				  					$scope.connectedUser4_name=val.name;
				  					$scope.connectedUser4_gender=val.gender;
				  					$scope.connectedUser4_playerid=val.user_id;
					  				$scope.connectedUser4_chips=val.userPoints;
					  				last_seat=4;
					  				
				  				}
				  				else if(last_seat==5)
				  				{
				  					$scope.connectedUser6_name=val.name;
				  					$scope.connectedUser6_gender=val.gender;
				  					$scope.connectedUser6_playerid=val.user_id;
				  					$scope.connectedUser6_chips=val.userPoints;
					  				
					  				last_seat=6;
					  				
				  				}
			  				}
				  				
		   					
				  		}
				  	}

				  	
			  		
			 	}
			 	
			});

			$(data.allUsersList).each(function (key,val)
			{
			 	if(val!=null)
			 	{
			 		
			 		if($scope.current_user_key<=key )
				 	{
				  	}
				  	else
				  	{
				  		/*if(j==0)
				  		{
				  			$scope.connectedUser4_name=val.name;
		  					$scope.connectedUser4_gender=val.gender;
		  					$scope.connectedUser4_playerid=val.user_id;
			  				
				  		}
				  		else if(j==1)
				  		{
				  			$scope.connectedUser1_name=val.name;
		  					$scope.connectedUser1_gender=val.gender;
		  					$scope.connectedUser1_playerid=val.user_id;
			  				
				  		}
				  		else if(j==2)
				  		{
				  			$scope.connectedUser2_name=val.name;
		  					$scope.connectedUser2_gender=val.gender;
		  					$scope.connectedUser2_playerid=val.user_id;
			  				
				  		}
				  		else if(j==3)
				  		{
				  			$scope.connectedUser3_name=val.name;
		  					$scope.connectedUser3_gender=val.gender;
		  					$scope.connectedUser3_playerid=val.user_id;
			  				
				  		}
				  		else if(j==4)
				  		{
				  			$scope.connectedUser6_name=val.name;
		  					$scope.connectedUser6_gender=val.gender;
		  					$scope.connectedUser6_playerid=val.user_id;
			  				
				  		}*/


				  		if(last_seat==6)
		  				{
		  					$scope.connectedUser3_name=val.name;
		  					$scope.connectedUser3_gender=val.gender;
		  					$scope.connectedUser3_playerid=val.user_id
		  					$scope.connectedUser3_chips=val.userPoints;			  				
			  				last_seat=3;
			  				
		  				}
		  				else if(last_seat==3)
		  				{
		  					$scope.connectedUser2_name=val.name;
		  					$scope.connectedUser2_gender=val.gender;
		  					$scope.connectedUser2_playerid=val.user_id;
		  					$scope.connectedUser2_chips=val.userPoints;
			  				
			  				last_seat=2;
			  				
		  				}
		  				else if(last_seat==2)
		  				{
		  					$scope.connectedUser1_name=val.name;
		  					$scope.connectedUser1_gender=val.gender;
		  					$scope.connectedUser1_playerid=val.user_id;
		  					$scope.connectedUser1_chips=val.userPoints;
			  				
			  				last_seat=1;
			  				
		  				}
		  				else if(last_seat==1)
		  				{
		  					$scope.connectedUser4_name=val.name;
		  					$scope.connectedUser4_gender=val.gender;
		  					$scope.connectedUser4_playerid=val.user_id;
		  					$scope.connectedUser4_chips=val.userPoints;
			  				
			  				last_seat=4;
			  				
		  				}
		  				else if(last_seat==5)
		  				{
		  					$scope.connectedUser6_name=val.name;
		  					$scope.connectedUser6_gender=val.gender;
		  					$scope.connectedUser6_playerid=val.user_id;
		  					$scope.connectedUser6_chips=val.userPoints;
			  				
			  				last_seat=6;
			  				
		  				}

				  		j++;
				  	}
				  	
			  		
			 	}
			 	
			});
			////console.log('--------------------');
			 
			////console.log( $scope.user);
			////console.log('--------------------');
			 
			////console.log(data.match_join_users);
			$(data.match_join_users).each(function (key,val)
			{
			 	
			 	if(val!=$scope.player_id)
			 	{

			 	 	$http.jsonp('http://mobirummy.com/getUserInfo/'+val+'?callback=JSON_CALLBACK').
			  			success(function(data, status, headers, config) {
			  				
			  					$scope.otherUser	=	data;
			  					
			  					$scope.checkUser	=	1;
			  					
			  			});
		  		}
			});


			$scope.current_user_name=data.user.firstname;
   			$scope.current_user_gender=data.user.gender;
   			$scope.current_user_chips=data.user.userPoints;


			setTimeout(function ()
			{
				if(jQuery('.connectedSortable').length>1)
				{
					$('.connectedSortable').addClass('card_in');
				}
				else
				{
					$('.connectedSortable').addClass('main_card');
				}
				// this callback will be called asynchronously
				// when the response is available
		  	},20);
		});
 
		 
		  //////console.log('working');
		  //////console.log($scope.player_cards);
	};

 	$scope.getCards();

	$scope.addDeckCloseCard	= 	function ()
	{
		$scope.isDrop = 1;
		var check_cards =0;
	

		$($scope.player_cards).each(function (key,val)
		{

			$(val).each(function (key,card)
			{
				//console.log('card start');
				//console.log(card);
				//console.log('card end');
				if(card.card_value!='')
				{
					
					check_cards++;
				}
			});


		});	
		
		if(check_cards>13)
		{
			alert('Please Play fairly');
			return false;
		}
		
		
		$http.jsonp('http://mobirummy.com/addDeckCloseCard/'+$scope.match_id+'/'+$scope.player_id+'?callback=JSON_CALLBACK').success(function(data, status, headers, config) {
		  	if(!data)
		  	{
				alert('Please wait for your turn');
				return false;
		  	}
            if(data==2)
	        {
	            alert('Please play fairly');
	            return false;
	        }


	         var check=1;
			for(var key=6; key>=0;key--)
			{
				if(check==1)
				{
					
					//if(this.length>0)
					if($('ul#sortable6 li').length > 0)
					{
							var abc = $scope.player_cards[key].push(data);							
							if(abc){
							 
							 var liPos =  $('ul#sortable6 li').last().position();
							
							 $('.close_deck_animate').show();
							$('.close_deck_animate').animate({"top" : liPos.top+130, "left" : liPos.left-5},'slow'); 
						//$('.openDeckAnimation').animate({"top" : liPos.top, "left" : liPos.left},'slow'); 
							}	

							setTimeout(function(){
								$('.close_deck_animate').hide();
								$('.close_deck_animate').animate({"top" :"5px", "left" : "240px"},'slow'); 	
							},2000)	;	
							$('.close_deck_animate').show();				
							check=0;
					}
					else if($('ul#sortable6 li').length == 0)
					{
						
						var abc = $scope.player_cards[key].push(data);
						if(abc){
							$('.close_deck_animate').show();
							//$('ul#sortable6').last().css("border","4px solid green");
							 var pos = $('ul#sortable6').last().position();
							 $('.close_deck_animate').animate({"top" : pos.top+105, "left" : pos.left+520},'slow');
						}
						
						 setTimeout(function(){
								$('.close_deck_animate').hide();
								$('.close_deck_animate').animate({"top" :"5px", "left" : "240px"},'slow'); 	
							},2000)	;	
							$('.close_deck_animate').show();	
						check=0;

					}
				}
			}


		  	/*
			var check=1;
			for(var key=6; key>=0;key--)
			{
				if(check==1)
				{
					if(this.length==0)
					{
						$scope.player_cards[key].push(data);
						check=0;
						alert('asd');
						////console.log(data);
					}
				}
			}
			*/
			//$scope.player_cards[6].push(data);
			$scope.removeCardCheck	=	true;
		});		
		
	};

	$scope.setCardScope	=	function ()
	{
		var group_counter	=0;
		 
		$($('.connectedSortable')).each(function()
		{	
			
			var new_group	=	[];
			$($(this).find('li')).each(function()
			{
				//////console.log($(this).find('card').val());
				new_group.push({card_value:$(this).find('input[name="card"]').val(),card_face:$(this).find('input[name="card"]').attr('rel')});	
				
				
			});
			$scope.player_cards[group_counter]=new_group;
				
				//////console.log($scope.player_cards[6]);
			group_counter++;
		});
	
	
	};
	$scope.joinMatch	=	function ()
	{

		$http.jsonp('http://mobirummy.com/joinMatch/'+$scope.match_id+'/'+$scope.player_id+'?callback=JSON_CALLBACK').
		  success(function(data, status, headers, config) {
			if(!data)
			{
				alert('Please wait for your turn');
				return false;
			}
	        if(data==2)
	        {
	            alert('Please play fairly');
	            return false;
	        }
                
		  
			var check=1;
			for(var key=6; key>=0;key--)
			{
				if(check==1)
				{
					if(this.length==0)
					{
						$scope.player_cards[key].push(data);
						check=0;
					}
				}
			}
			if(check==1)
			{

				$scope.player_cards[6].push($scope.deck_close);
			}
			$scope.removeCardCheck	=	true;
		});		

	};


	$scope.addOpenDeckCard	= 	function ()
	{
		var dataValue = $('#openDeckAnimate').attr('data-value');
		if(dataValue == $scope.mainJoker || $scope.mainJoker == 0 || dataValue == 0){
			alert('You can not take joker card from open deck');
			return false;
		}
		$scope.isDrop = 1;
		var check_cards =0;
		
		
		$($scope.player_cards).each(function (key,val)
		{

			$(val).each(function (key,card)
			{
				if(card.card_value!='')
				{
					check_cards++;
				}
			});
		});	

		if(check_cards>13)
		{
			alert('Please Play fairly');
			return false;
		}
		
        
		$http.jsonp('http://mobirummy.com/addDeckOpenCard/'+$scope.match_id+'/'+$scope.player_id+'?callback=JSON_CALLBACK').
		  success(function(data, status, headers, config) {
		  	if(!data)
		  	{
				alert('Please wait for your turn');
				return false;
		  	}
	        if(data==2)
	        {
	            alert('Please play fairly');
	            return false;
	        }
                
		  
			var check=1;
				for(var key=6; key>=0;key--)
			{
				if(check==1)
				{
					
					//if(this.length>0)
					if($('ul#sortable6 li').length > 0)
					{
						
						
							var abc = $scope.player_cards[key].push(data);							
							if(abc){
							 
							 var liPos =  $('ul#sortable6 li').last().position();
							
							$('.openDeckAnimation').show();
							$('.openDeckAnimation').animate({"top" : liPos.top+130, "left" : liPos.left-5},'slow'); 
						//$('.openDeckAnimation').animate({"top" : liPos.top, "left" : liPos.left},'slow'); 
							}	

							setTimeout(function(){
								$('.openDeckAnimation').hide();
								$('.openDeckAnimation').animate({"top" :"5px", "left" : "327px"},'slow'); 	
							},2000)	;	
							$('.openDeckAnimation').show();				
							check=0;
					}
					else if($('ul#sortable6 li').length == 0)
					{
						
						var abc = $scope.player_cards[key].push(data);
						if(abc){
							$('.openDeckAnimation').show();
							//$('ul#sortable6').last().css("border","4px solid green");
							var pos = $('ul#sortable6').last().position();
							 $('.openDeckAnimation').animate({"top" : pos.top+105, "left" : pos.left+520},'slow');
						}
						
						 setTimeout(function(){
								$('.openDeckAnimation').hide();
								$('.openDeckAnimation').animate({"top" :"5px", "left" : "327px"},'slow'); 	
							},2000)	;	
							$('.openDeckAnimation').show();	
						check=0;

					}
				}
			}
			/*for(var key=6; key>=0;key--)
			{
				if(check==1)
				{
					if(this.length==0)
					{
						$scope.player_cards[key].push(data);
						check=0;
					}
				}
			}*/
		
			$scope.removeCardCheck	=	true;
		});		
	};
	
	
	$scope.turnCheck	=	function()
	{
		return true;
	}
	$scope.removeCardCheckCall	=	function ()
	{
		if($scope.removeCardCheck)
		{
			return true;
		}
		else
		{
			return false;
		}
		
	};
  
  
  	$scope.removeCard	=	function ()
  	{
	    if($("input[name='card']:checked").length!=1)
	    {
	        alert('Please play fairly');
	        return false;
	    }
      	//$scope.isDrop = 0;
		var card	=	$("input[name='card']:checked").attr('temp');	
		var card_face	=	$("input[name='card']:checked").attr('rel');
	    var card_number=card.split('-');
	   
	    if($scope.match_joker==card_number[1] || card_number[1]==0 )
	    {
	    	//alert("You can not remove joker card");
	    	//return false;
	    }

	     var attrVal = $("input[name='card']:checked").attr('rel');
		if(attrVal == card_face){
		//jQuery('.playercard'+card_face).show();
		jQuery('.playercard123').css('display', 'block');  
		jQuery('.playercard123').animate({"top" : "5px","left" : "327px"},"slow");
		jQuery('.playercard123').delay(3000).fadeOut(500);
		}

		$("input[name='card']:checked").parents('li').remove();
		$scope.deck_open	=	{card_value:card,card_face:card_face};
	     jQuery('#open_deck').attr('src','images/'+card_face+'.png');
		$scope.arrangeCard();
		$scope.setCardScope();
		$scope.updateCard(card);
		$scope.removeCardCheck	=	false;
    
 	};
 	$scope.newGroup	=function()
  	{
	
		var check=1;
		var element_group;
		var positions	=	[];
		positions[0]	=	[];
		positions[1]	=	[];
		positions[2]	=	[];
		positions[3]	=	[];
		positions[4]	=	[];
		positions[5]	=	[];
		positions[6]	=	[];
		/*positions[7]	=	[];*/
		
		$($scope.player_cards).each(function(key,val)
		{
			if(check==1)
			{
				if(this.length==0)
				{
					
					var group	=	key;
					$($("input[name='card']:checked")).each(function()
					{
					
						$scope.player_cards[group].push({card_value:$(this).val(),card_face:$(this).attr('rel')});
						element_group	=	$(this).parents('ul').attr('rel');
						positions[element_group].push($(this).parents('li').index());
						$(this).parents('li').remove();
						
						var index =$(this).val();
						$($scope.player_cards).each(function(key,val)
						{
							
							if(element_group==key)
							{
								$(val).each(function (key,card)
								{
									if(card.card_value==index)
									{
										
										$scope.player_cards[element_group].splice(key,1);
									}
								});
							}
							
							
						});
						
					//	$scope.player_cards[element_group].splice(index, 1);
						
						//delete $scope.player_cards(key);
					});
					check=0;	

				}
				
			}
	        jQuery('.player_card').removeClass('select_card');
		});
	
	
		$(positions).each(function(key,val)
		{
			var element	=key;	
			val.sort(function(a, b){return b-a});
			$(val).each(function(key,card_val)
			{
				////console.log(element);
				////console.log((card_val-2));
				////console.log($scope.player_cards[element][(card_val)])
						////console.log($scope.player_cards[element].splice((card_val),1));
				
			});

		});




		$("input[name='card']").prop('checked',false);
		$scope.arrangeCard();
		$scope.updateCard();
		
  	}
  
  
  	$scope.arrangeCard	=	function()
  	{
	

  		setTimeout(function()
		{
		 	if(jQuery('.connectedSortable').length>1)
			{
				$('.connectedSortable').addClass('card_in');
			}
			else
			{
				$('.connectedSortable').addClass('main_card');
			}
			$( "#sortable0,#sortable1, #sortable2,#sortable3,#sortable4,#sortable5,#sortable6,#sortable7" ).sortable({
			connectWith: ".connectedSortable",
			stop:function(event,ui)
			{
					$scope.setCardScope();
					$scope.updateCard();
					$scope.arrangeCard();	
				
			}
			}).disableSelection();
			if(jQuery('.connectedSortable').length>1)
			{
				$('.connectedSortable').addClass('card_in');
			}
			else
			{
				$('.connectedSortable').addClass('main_card');
			}	
		},500);
	
  	};
  
  
	$scope.changeCard	=function()
	{
		$scope.player_cards[0]	=	[{card_value:2,card_face:'images/krummy6.png'},{card_value:2,card_face:'images/krummy6.png'},{card_value:2,card_face:'h3'}];
		$scope.player_cards[1]	=	[{card_value:2,card_face:'images/krummy6.png'},{card_value:2,card_face:'images/krummy6.png'},{card_value:2,card_face:'h3'}];
			
	};

 	$scope.validate	=	function ()
	{	
		var pure_counter	=	0;
     	var total_points   =   0;
		$($scope.player_cards).each(function(key,val)
		{
			var group=key;

			if(val.length>0)
			{
				var temp_suite	=	[];
				var temp_cards	=	[];
			
				$(val).each(function(card_key,card)
				{
					
					if(card.card_value)
					{
						var card	=	card.card_value.split('-');
						temp_suite.push(card[0]);
						temp_cards.push(parseInt(card[1]));
					}	
				});
			     
				        
				if(temp_suite.length>2)
				{
                    var pure_check	=	true;
                    var trail_check	=	true;
                    var sequence_check	=	true;
                    var first_life   =   true;
                    var second_life  =   true;
                    var trail   =   true;
                    /*check for first life start*/
                    $(temp_suite).each(function(card_key,card_val)
					{
                            
						if(card_val!=temp_suite[0])
						{
						
							first_life=false;
							
						}
						
						
					});
                    var  first_suite_cards    = [];  
                    $(temp_cards).each(function(asd,card_val){
                        first_suite_cards.push(card_val);
                    });
                    first_suite_cards.sort(function(a, b){return a-b});
							//////console.log(temp_cards);
					var counter_check='';
                             
                    if(parseInt(first_suite_cards[first_suite_cards.length-1])==13)
                    {
                        
                        $(first_suite_cards).each(function(card_key,val)
                        {

                            if(val!=1 && counter_check=='')
                            {
                                    
                                counter_check=parseInt(val);
                            }
                            
                            if(counter_check!='')
                            {
                               
                                if(counter_check!=parseInt(val))
                                {
                                    first_life=false;
                                }
                                counter_check++;

                            } 
					
                        });
                                
                    }
                    else
                    {          
                    
                    
                        $(first_suite_cards).each(function(card_key,val)
                        {

                            if(card_key==0)
                            {

                                counter_check=parseInt(val);
                                

                            }
                            else
                            {

                                counter_check++;
                                    
                                
                                if(counter_check!=parseInt(val))
                                {
                                	
                                    if($.inArray(1,first_suite_cards)!=-1)
                                    {
                                    	var temp_first_suite_cards=[];
                                    	$(first_suite_cards).each(function(card_key,card_val)
                    					{
                    						if(card_val==1)
                    						{
                    							temp_first_suite_cards.push(14);
                    						}
                    						else
                    						{
                    							temp_first_suite_cards.push(card_val);
                    						}
                    						
						                    
                    					});
                    					temp_first_suite_cards.sort(function(a, b){return a-b});
										
										var temp_counter_check='';


										$(temp_first_suite_cards).each(function(card_key,val)
				                        {

				                            if(card_key==0)
				                            {

				                                temp_counter_check=parseInt(val);
				                                

				                            }
				                            else
				                            {

				                                temp_counter_check++;
				                                    
				                                
				                                    if(temp_counter_check!=parseInt(val))
				                                    {
				                                    
				                                        first_life=false;    
				                                    }
				                                    


				                            }

				                        });


                                    	
                                    }
                                    else
                                    {
                                    	first_life=false;
                                    }
                                    
                                }
                                    


                            }

                        });
                    }
                    
					 /*check for first life ends*/
                    
                                    
                    /*check for second life sarts*/
                    
                    var second_life_suite   =   temp_suite;
                    var second_life_cards   =   temp_cards;
                    var jokers=0;
                    var positions   =   [];
                    $(second_life_cards).each(function(card_key,val)
                    {
                       
                        if(val==$scope.match_joker || val==0)
                        {

                            positions.push(card_key);
                            jokers++;
                           
                        }
                       
                          
                    });
                            
                    positions.sort(function(a, b){return b-a});
                            
                    $(positions).each(function(card_key,val)
                    {
                               
                        second_life_suite.splice(val,1);
                        second_life_cards.splice(val,1);        
                                
                    });
                                
                    $(second_life_suite).each(function(suite_key,suite_val)
					{
						if(this!=temp_suite[0])
						{
                           
							second_life=false;
							
						}
					});
                            
                    var counter_check='';
                    second_life_cards.sort(function(a, b){return a-b});
                    var joker_check=0;


					if(second_life_cards[second_life_cards.length-1]==13 || $scope.match_joker==13 || (jokers>0 &&second_life_cards[second_life_cards.length-2]==12))
                    {
                        
                        $(second_life_cards).each(function(card_key,val)
                        {
						
                   	
                            if(val!=1 && counter_check=='')
                            {
                                    
                                counter_check=parseInt(val);
                            }
                            
                            if(counter_check!='')
                            {
                                
                               
                            	
                                    if(counter_check!=parseInt(val))
                                    {
                                        
                                        
                                        joker_check =   joker_check+(parseInt(val)-counter_check);
                                    }
                                 counter_check++;

                            }


                            
					
                         });
                        
                    }
                    else
                    {          
                    
                    	
                        $(second_life_cards).each(function(card_key,val)
                        {
                        
                            if(card_key==0)
                            {

                                counter_check=parseInt(val);


                            }
                            else
                            {
								counter_check++;
                                
                        
                                if(counter_check!=parseInt(val))
                                {
                                 
                                   	if(jokers>0 && parseInt(val)>counter_check)
                                   	{
                                       
                                     	joker_check =   joker_check+(parseInt(val)-counter_check);
                                     	/*Added by Rashmi Sharma on 31-08-2015*/
                                    	counter_check++;
                                   	}
                                    else
                                    {
                                    	
										var arr_status=$.inArray(1,second_life_cards);
										
                                    	
                                    	if($.inArray(1,second_life_cards)!=-1)
	                                    {
	                                    	var temp_second_life_cards=[];
	                                    	$(second_life_cards).each(function(card_key,card_val)
	                    					{
	                    						if(card_val==1)
	                    						{
	                    							temp_second_life_cards.push(14);
	                    						}
	                    						else
	                    						{
	                    							temp_second_life_cards.push(card_val);
	                    						}
	                    						
							                    
	                    					});

	                    					temp_second_life_cards.sort(function(a, b){return a-b});
											
											//console.log('second_life_cards start');
											//console.log(temp_second_life_cards);
											//console.log('second_life_cards end');
											var temp_counter_check='';

											$(temp_second_life_cards).each(function(card_key,val)
					                        {
					                        
					                            if(card_key==0)
					                            {

					                                temp_counter_check=parseInt(val);


					                            }
					                            else
					                            {
													temp_counter_check++;
					                                
					                        
					                                if(temp_counter_check!=parseInt(val))
					                                {
					                                 
					                                   	if(jokers>0 && parseInt(val)>temp_counter_check)
					                                   	{
					                                       
					                                     	joker_check =   joker_check+(parseInt(val)-temp_counter_check);
					                                     	/*Added by Rashmi Sharma on 31-08-2015*/
					                                    	temp_counter_check++;
					                                   	}
					                                    else
					                                    {
						                                   
						                                    second_life=false;
					                                    }
					                                        
					                                }
					                            }

					                        });
											


	                                    	
	                                    }
	                                    else
	                                    {
	                                    	second_life=false;
	                                    }

                                        
                                    }
                                        
                                }
                            }

                        });
                    }
                            
                          
                    if(joker_check!=jokers && joker_check>0)
                    {
                        
                    	/*Added by Rashmi Sharma on 31-08-2015*/
                        if(joker_check<jokers)
                        {

                        }
                        else
                        {

                        	
                        	
                        	if($.inArray(1,second_life_cards)!=-1)
                            {
                            	var temp_second_life_cards=[];
                            	$(second_life_cards).each(function(card_key,card_val)
            					{
            						if(card_val==1)
            						{
            							temp_second_life_cards.push(14);
            						}
            						else
            						{
            							temp_second_life_cards.push(card_val);
            						}
            						
				                    
            					});

            					temp_second_life_cards.sort(function(a, b){return a-b});
								
								//console.log('temp second_life_cards start 1 ');
								//console.log(temp_second_life_cards);
								//console.log('temp second_life_cards end 1');
								var temp_counter_check='';

								$(temp_second_life_cards).each(function(card_key,val)
		                        {
		                        
		                            if(card_key==0)
		                            {

		                                temp_counter_check=parseInt(val);


		                            }
		                            else
		                            {
										temp_counter_check++;
		                                
		                        
		                                if(temp_counter_check!=parseInt(val))
		                                {
		                                 
		                                   	if(jokers>0 && parseInt(val)>temp_counter_check)
		                                   	{
		                                       
		                                     	joker_check =   joker_check+(parseInt(val)-temp_counter_check);
		                                     	/*Added by Rashmi Sharma on 31-08-2015*/
		                                    	temp_counter_check++;
		                                   	}
		                                    else
		                                    {
			                                   
			                                    second_life=false;
		                                    }
		                                        
		                                }
		                            }

		                        });
								


                            	
                            }
                            else
                            {
                            	second_life=false;
                            }

                        }
                        
                        
                    }
                               
                     /*check for second life ends*/
                    
                    
                    
                    /*trail starts*/
                    var trail_suite   =   temp_suite;
                    var trail_cards   =   temp_cards;
                    jokers=0;
                     positions   =   [];
                     
                    $(trail_cards).each(function(card_key,val)
                    {
                        if(val==$scope.match_joker || val==0)
                        {
                               
                            positions.push(card_key);
                            jokers++;
                           
                        }
                       
                          
                    });
                            
                            
                    positions.sort(function(a, b){return b-a});
                    
                    $(positions).each(function(card_key,val)
                    {
                       
                        trail_cards.splice(val,1);
                        trail_suite.splice(val,1);    
                    });
                    var trail_suite_check_array  =   [];
                             
                    $(trail_suite).each(function(suite_key,suite_val)
					{
                                      
                       if(trail_suite_check_array.indexOf(suite_val)<0)
                       {
                           trail_suite_check_array.push(suite_val);
                       }
                       else
                       {
                           
                            trail=false;
                           
                       }
						
					});
                            
                            
                            
                    $(temp_cards).each(function(suite_key,suite_val)
					{
						if(suite_val!=temp_cards[0])
						{
                           
							if(jokers<1)
                            {
                                trail=false;
                            }
                            else
                            {
                               
                               jokers--;
                               
                               
                            }
							
						}
					});
                            
                             /*trail starts*/             
                            
				}
                else
                {
                    second_life=false;
                    trail=false;
                    first_life=false;
                }
						
                if(first_life)
                {
                        
                    pure_counter++;
                }
                       
                if(second_life || first_life || trail)
				{ 
					$scope.player_cards[key].valid	=	true;
				}
				else
				{
                              
					$scope.player_cards[key].valid	=	false;
                    $(temp_cards).each(function(suite_key,suite_val)
					{
                        if($scope.match_joker==parseInt(suite_val))
                        {
				          total_points    +=   0;
                        }
                         else if (parseInt(suite_val) >9 || parseInt(suite_val)==1)
                         {
                                total_points    +=10;
                         }
                         else
                         {
                                total_points +=parseInt(suite_val);
                         }
                                
                         
                    });
                }
            
			}
				
		
		});
	    if(total_points>80)
	    {
	        total_points=80;
	    }
     	$scope.total_points    =   total_points;
		if(pure_counter>0)
		{
	           
			$scope.can_declare	=	true;
		}
		else
		{
			$scope.can_declare	=	false;
		}

	}; 
  
  
  
  
	$scope.setOpenCard	=	function (card)
	{
		$scope.deck_open	=	card;
		
	};
    
	$scope.sortCards	=	function (card)
	{
	    
	    var final_cards    =    [[],[],[],[],[],[],[]];
	    $($scope.player_cards).each(function()
	    {
	        
			$(this).each(function(key,val)
			{
	            ////console.log(val.card_value);
	            var splited   =   val.card_value.split('-');
	            if(splited[0]==1)
	            {
	                final_cards[0].push(val);
	            }
	            else if (splited[0]==2)
	            {
	                final_cards[1].push(val);
	            }
	            else if (splited[0]==3)
	            {
	                final_cards[2].push(val);
	            }
	             else if (splited[0]==4)
	            {
	                final_cards[3].push(val);
	            }
	            else if (splited[0]==0)
	            {
	                final_cards[4].push(val);
	            }
	    
	    	});    
	    });
	    $scope.player_cards =   final_cards; 
	    $scope.arrangeCard();	
		$scope.validate();
	};
  
  	$scope.updateCard =	function (card)
  	{
	
		var final_cards	=	[];
	
		$($scope.player_cards).each(function(key,val)
		{
			var group	=	this;
			var temp_suite	=	[];
			var temp_cards	=	[];
			$(this).each(function()
			{
				
				if(!final_cards[key])
				{
					final_cards[key]	=	[];
				}
				
				final_cards[key].push(this.card_value);	
				
			});
		});
	
		//console.log(final_cards);
		var url	=	'http://mobirummy.com/updatePlayerCards/'+$scope.match_id+'/'+$scope.player_id+'/'+JSON.stringify(final_cards)+'/'+card+'?callback=JSON_CALLBACK';
		$http.jsonp(url).success(function(data, status, headers, config)
		{
       
			if(card)
			{
			 	$('#player_countdown2').remove();
			 	$('#player_countdown1').remove();
				$( "#player_div2 img" ).after( '<div id="player_countdown2"></div>');
	
		       /* $("#player_countdown2").countdown360({
			        radius      : 40,
			        seconds     : 80, 
			        fontColor   : 'transparent',
			        strokeStyle : '#ffc100',
			        fillStyle:'transparent',
			        autostart   : false,
			        onComplete  : function () { 


			        }
			    }).start();*/

			//	reset_timer();

			}
  				//alert('updated');
  
  
		    // this callback will be called asynchronously
		    // when the response is available
		});
  
 		$scope.validate();
  
  	};

  
}]);

